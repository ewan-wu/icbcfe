#!/bin/sh
echo "####################################################"
echo "#Use as :                                          #"
echo "# topgetunl.sh [\"6403 6107\"] [etc/cpg.ini]         #"
echo "#                                                  #"
echo "####################################################"
echo ""

#dbfile
if [[ ! $2 ]]
then
    dbfile=${HOME}/etc/cpg.ini
else
    dbfile=${HOME}/$2
fi

echo "full path =: $dbfile"
if [[ ! -f $dbfile ]]
then
    echo="file no exit [$dbfile] !!"
    exit
fi


#plug.dbtype=1
#plug.dbencpwd=0
#plug.dbconnect=db2inst2/huateng@cnaps2
#plug.dbkey=A196D45DDC276852F6278440A854107A63661AFAD8398D26

#dbtype_str
dbtype=`grep "plug.dbtype" ${dbfile}|grep -v "#"|awk 'BEGIN{FS="[==]"}{print $2}'|sed 's/ //g'`
#echo "dbtype =: $dbtype"
if [[ $dbtype = "0" ]]
then
    dbtype_str="oracle"
elif [[ $dbtype = "1" ]]
then
    dbtype_str="db2"
else
    echo "dbtype [$dbtype] no support"
    exit
fi
echo "dbtype    =: $dbtype - $dbtype_str"

#dbconnect
dbconnect=`grep "plug.dbconnect" ${dbfile}|grep -v "#" |awk 'BEGIN{FS="[==]"}{print $2}'|sed 's/ //g'`
echo "dbconnect =: $dbconnect"

#dbencpwd
dbencpwd=`grep "plug.dbencpwd" ${dbfile}|grep -v "#" |awk 'BEGIN{FS="[==]"}{print $2}'|sed 's/ //g'`
echo "dbencpwd  =: $dbencpwd"
#keytype
if [[ $dbencpwd = "1" ]]
then
   dbencpwd_str="-U 3des -K $dbkey"
elif [[ $dbencpwd = "2" ]]
then
   dbencpwd_str="-U aes -K $dbkey"
else
    dbencpwd_str=""
fi

#dbkey
dbkeyflag=`grep "plug.dbkey" ${dbfile}|grep -v "#" |wc -l`
if [[ $dbkeyflag = "0" ]]
then 
    dbkey="A196D45DDC276852F6278440A854107A63661AFAD8398D26"
else
    dbkey=`grep "plug.dbkey" ${dbfile}|grep -v #|awk 'BEGIN{FS="[=/=]"}{print $2}'|sed 's/ //g'`
fi

if [[ $dbencpwd = "1" ]] || [[ $dbencpwd = "2" ]]
then
    echo "dbencpwd  =: $dbencpwd_str"
    echo "dbkey     =: $dbkey"
fi

#sql
if [[ $1 ]]
then
    sql_str_0=`echo $1|sed "s/ /\',\'/g"`
    sql_str_end="where svr_id in ('$sql_str_0')"
else
    sql_str_end=""
fi
sql_str_star="select * from cp2_msqdef "
sql_str="$sql_str_star $sql_str_end"
    echo "sql_str   =: $sql_str"

echo ""
echo `dbexp -t ${dbtype_str}  -c ${dbconnect} ${dbencpwd_str} -s "${sql_str}" msgquedef.unl`

mv msgquedef.unl .unl

echo `sed '1d' .unl |sed 's/"//g'  > msgquedef.unl `

rm -f .unl