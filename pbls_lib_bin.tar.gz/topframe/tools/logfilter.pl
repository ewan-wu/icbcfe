#!/usr/bin/perl
use strict;
use File::Basename;
use Getopt::Std;

our $opt_b;	#begin
our $opt_e;	#end
our $opt_f;	#file
our $opt_l;	#level
our $opt_p;	#pid
our $opt_F;	#func
our $opt_s;	#session
our $opt_m;	#mod

our $opt_M;	#mod list

our $opt_o;	#output line no
our $opt_h;	#help

my %mod;

main();

sub main()
{
	getopts("b:e:f:l:p:F:s:m:Moh");

	if ($opt_m or $opt_M) {
		modload();
	}

	if ($opt_M) {
		modout();
		exit 0;
	}

	if ($opt_h or @ARGV < 1) {
		usage();
		exit 1;
	}

	for (my $i = 0; $i < @ARGV; $i++) {
		filter($ARGV[$i]);
	}
}

sub usage()
{
	print(STDERR "Usage: ".fileparse($0)." [options] <logfile> ...\n");
	print(STDERR "       -b begin time (yyyymmddHHMMSS)\n");
	print(STDERR "       -e end time (yyyymmddHHMMSS)\n");
	print(STDERR "       -f file\n");
	print(STDERR "       -l level\n");
	print(STDERR "       -p pid\n");
	print(STDERR "       -F function\n");
	print(STDERR "       -s session\n");
	print(STDERR "       -m module\n");
}

sub filter()
{
	my ($Log) = @_;

	if ($Log eq "-") {
		*LOG = *STDIN;
	} else {
		open(LOG, $Log)
			or die(fileparse($0).": open <$Log> error, $!\n");
	}

	my $Flag;
	my @Args;
	my $Out = not ($opt_b or $opt_e or $opt_f or $opt_l or $opt_p or $opt_F or
	               $opt_s or $opt_m);
	my $i = 0;

	while (<LOG>) {
		$i++;
		($Flag, @Args) = parse($_);

		if ($Flag) {
			$Out = isout($i, @Args);
		}

		print $_ if ($Out);
	}

	close(LOG) if ($Log ne "-");
}

sub parse()
{
	my ($Line) = @_;

	if ($_ =~ /^\[([^\]]*)\]\[([^\]]*):([^\]]*)\]\[([^\]]*)\]\[([^\]]*)\]\[([^\]]*)\]\[([^\]]*)\]/) {
		return (1, $1, $2, $3, $4, $5, $6, $7, $mod{$2});
	} elsif ($_ =~ /^\[([^\]]*)\]\[([^\]]*):([^\]]*)\]\[([^\]]*)\]\[([^\]]*)\]\[([^\]]*)\]/) {
		return (1, $1, $2, $3, $4, $5, $6, -1, $mod{$2});
	}

	return 0;
}

sub isout()
{
	my ($Num, $Time, $File, $Line, $Pid, $Level, $Func, $Session, $Mod) = @_;

	return 0 if ($opt_b and $Time lt todate($opt_b, 0));	#begin
	return 0 if ($opt_e and $Time gt todate($opt_e, 1));	#end

	return 0 if ($opt_f and $File    !~ /^($opt_f)/);	#file
	return 0 if ($opt_p and $Pid     !~ /^($opt_p)/);	#pid
	return 0 if ($opt_l and $Level   !~ /^($opt_l)/);	#level
	return 0 if ($opt_F and $Func    !~ /^($opt_F)/);	#func

	return 0 if ($opt_s and $Session == $opt_s);	#session

	if ($opt_m eq "none") {	#mod
		return 0 if ($Mod)
	} elsif ($opt_m eq "all") {
		return 0 if (!$Mod)
	} elsif ($opt_m) {
		return 0 if ($Mod !~ /\/($opt_m)\//);
	}

	return 1;
}

sub todate()
{
	my ($date, $flag) = @_;

	if (length($date) >= 14) {
		$date =~ s/(....)(..)(..)(..)(..)(..).*/$1-$2-$3 $4:$5:$6/;
	} elsif (length($date) >= 12) {
		$date =~ s/(....)(..)(..)(..)(..).*/$1-$2-$3 $4:$5:99/ if ($flag);
		$date =~ s/(....)(..)(..)(..)(..).*/$1-$2-$3 $4:$5/ if (not $flag);
	} elsif (length($date) >= 10) {
		$date =~ s/(....)(..)(..)(..)(..).*/$1-$2-$3 $4:99:99/ if ($flag);
		$date =~ s/(....)(..)(..)(..).*/$1-$2-$3 $4/ if (not $flag);
	} elsif (length($date) >= 8) {
		$date =~ s/(....)(..)(..)(..)(..).*/$1-$2-$3 99:99:99/ if ($flag);
		$date =~ s/(....)(..)(..).*/$1-$2-$3/ if (not $flag);
	} elsif (length($date) >= 6) {
		$date =~ s/(....)(..)(..)(..)(..).*/$1-$2-99 99:99:99/ if ($flag);
		$date =~ s/(....)(..).*/$1-$2/ if (not $flag);
	} else {
		$date =~ s/(....)(..)(..)(..)(..).*/$1-99-99 99:99:99/ if ($flag);
		$date =~ s/(....).*/$1/ if (not $flag);
	}

	return $date;
}

sub modload()
{
	open(MOD, "$ENV{TOPFRAME_HOME}/tools/modlist") or return;

	my $File;
	my $Mod;

	while (<MOD>) {
		chomp($_);
		($File, $Mod) = split(",", $_);
		$mod{$File} = $Mod;
	}

	close(MOD);
}

sub modout()
{
	my %modr = reverse(%mod);
	print("mods: ".join(" ", keys(%modr))."\n");
}
