#!/bin/sh
# 

if [ "$#" -lt 4 ]; then
   echo 'Usage: sqltest.sh <dbtype> <connectstr> <sqlfilelist> <testlog> <testparamsdir>'
   exit 1
fi

if [ ! -f ${3} ]; then
   echo "sqlfilelist[${3}] not exists."
   exit 1
fi

get_args()
{
    sqlparam=''
    num=1

    while [ $num -le ${1} ]
    do
        old="$sqlparam 1"
        sqlparam="$old"
        num=`expr $num + 1`
    done

    echo $sqlparam
}

sqllist=`cat ${3}`

for sqlfile in $sqllist
do
   echo "----------------------------------------------[${sqlfile}]----------------------------------------"
   if [ ! -f "${sqlfile}" ]; then
       echo "sqlfile[${sqlfile}] not exists."
       continue;
   fi

   sqltext=`sed -e 's/\^//g' "$sqlfile" | sed -e 's///g' |awk '{printf("%s ",$0)}'` 

   paramcnt=`dbtest -t "$1" -c "$2" "${sqltext}"|grep iNeed|awk '{print substr($3,7,2)+0}'`
   if [ -z "${paramcnt}" ]; then
        dbtest -t "$1" -c "$2" "${sqltext}"|grep -v COLUMN 
   else 
        sqlparams=`get_args $paramcnt`
        dbtest -t "$1" -c "$2" "${sqltext}" ${sqlparams} |grep -v COLUMN
   fi
   
done

