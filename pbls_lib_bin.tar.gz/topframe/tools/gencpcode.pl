#!/usr/bin/perl -w
#
# memcpy �������ɹ���
#
use strict;

#ȫ�ֱ�������

#
&main();

#
sub main()
{
    my $Argc = @ARGV;
    my $Line;
    my $Len;
    my $WdName;
    my @StructLines;
    my @CodeLines;
    my $i = 0;
    my $j = 0;
    
    if ($Argc != 5) {
        printf("Usage: gencpcode.pl <structfile> <codefile> <param1> <param2> <lineno>\n");
        exit;
    }
    
    open(STRUCTFILE, $ARGV[0])||die("open file error!:".$ARGV[0]."\n");
    open(CODEFILE, $ARGV[1])||die("open file error!:".$ARGV[1]."\n");

    @StructLines = <STRUCTFILE>;
    @CodeLines = <CODEFILE>;
    
    close(STRUCTFILE);
    close(CODEFILE);
    
    open(OUTCODEFILE, ">".$ARGV[1])||die("open file error!:".$ARGV[1]."\n");
    
    for($i = 0; $i < @CodeLines; $i++) {
        print OUTCODEFILE ($CodeLines[$i]);
        if($ARGV[4] == $i) {
            for($j = 0; $j < @StructLines; $j++) {
                
                $WdName =  $StructLines[$j];
                $Len =  $StructLines[$j];
                
                $WdName =~ s/\[.*$//g;
                $WdName =~ s/;//g;
                $WdName =~ s/\n//g;
                $WdName =~ s/\s+//g;
                
                $Len =~ s/^.*\[//g;
                $Len =~ s/\].*$//g;
                $Len =~ s/\n//g;
                
                print($WdName);
                if($WdName =~ /^s+/) {
                    printf OUTCODEFILE ("    memcpy(%-30s, %-30s, %-20s);\n", $ARGV[2]."$WdName", $ARGV[3]."$WdName", "$Len");
                } else  {
                    printf OUTCODEFILE ("    %s = %s ;\n", $ARGV[2]."$WdName", $ARGV[3]."$WdName");
                }
            }
        }
    }
   
}
#################END#######################
