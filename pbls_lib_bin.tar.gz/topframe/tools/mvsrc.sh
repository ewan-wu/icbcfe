#!/bin/sh
OLD=$1
NEW=`echo $OLD | sed 's/\/src\//\/srcraw\//' | sed 's/o$/c/'`
mkdir -p `dirname $NEW`
mv -f $OLD $NEW
