#!/usr/bin/perl -w
use strict;
use File::Basename;
use Getopt::Std;

our $opt_o;

&main();

sub main()
{
	getopts("o");

	if (@ARGV < 1) {
		print(STDERR "Usage: ".fileparse($0)." [-o] <sqlfile>\n");
		exit 1;
	}

	my $i = 0;
	for ($i = 0; $i < @ARGV; $i++) {
		gencsv($ARGV[0]);
	}
}

sub gencsv()
{
	my ($SqlFile) = @_;

	open(SQLFILE, $SqlFile)
		or die(fileparse($0).": open <$SqlFile> error, $!\n");

	my $Line;
	my @Lines;
	my @Words;

	@Lines = <SQLFILE>;
	$Line = join(" ", @Lines);
	$Line = uc($Line);
	$Line =~ s/--.*//g;
	$Line =~ s/COMMENT.*//g;
	$Line =~ s/\n|\)|\(|\{|\}|,|\t|\;/ /g;
	$Line =~ s/\*\//\*\/\n/g;
	$Line =~ s/\/\*.*//g;
	$Line =~ s/\s+/ /g;
	$Line =~ s/ NULL | NOT NULL / /g;
	$Line =~ s/^.*?CREATE/CREATE/g;

	@Words = split(/\s+/, $Line);

	close(SQLFILE);

	my $Table;
	my @Col;
	my %ColKey;
	my %ColType;
	my %ColLen;

	my $Status = 0;
	my $i;

	for ($i = 0; $i < @Words; $i++) {

		if ($Status == 0) {
			if ($Words[$i++] ne "CREATE") {
				die("syntax error at the begining\n");
			}

			if ($Words[$i++] ne "TABLE") {
				die("syntax error at create\n");
			}

			$Table = $Words[$i];

			$Status = 1;
			next;
		}

		if ($Status == 1 && $Words[$i] eq "PRIMARY") {
			$i++;
			if($Words[$i++] ne "KEY") {
				die("syntax error at primary\n");
			}

			my $j;

			for ($j = 0; $j < @Col; $j++) {
				$ColKey{$Col[$j]} = 'N';
			}

			for ( ; $i < @Words; $i++) {
				$ColKey{$Words[$i]} = 'Y';
			}

			last;
		}

		if ($Status == 1) {
			my $Cnt = @Col;

			$Col[$Cnt] = $Words[$i++];
			$ColType{$Col[$Cnt]} = $Words[$i];

			if (argcnt($ColType{$Col[$Cnt]}) == 0) {
				$ColLen{$Col[$Cnt]} = 0;

			} else {
				$i++;
				$ColLen{$Col[$Cnt]} = $Words[$i];
			}
		}
	}

	my $CsvFile = lc($Table).".csv";

	if ($opt_o) {
		*CSVFILE = *STDOUT;

	} else {
		open(CSVFILE, ">", $CsvFile)
			or die(fileparse($0).": open <$CsvFile> error, $!\n");
	}

	my $ColName;
	foreach $ColName (@Col) {
		print(CSVFILE  $ColName  . "\t" . $ColKey{$ColName} . "\t" .
		      $ColType{$ColName} . "\t" . $ColLen{$ColName} . "\n");
	}

	if (not $opt_o) {
		close(CSVFILE);
		print(STDERR "generate[$CsvFile]\n");
	}
}

sub argcnt()
{
	my ($Type) = @_;

	if ($Type eq "NUMBER" || $Type eq "DECIMAL" || $Type eq "FLOAT" ||
	    $Type eq "CHAR"   || $Type eq "VARCHAR" || $Type eq "VARCHAR2") {
		return 1;

	} else {
		return 0;
	}
}
