#!/bin/ksh 
#����÷�: unload.sh -u scbora/scbora -f \| hvrmtrcv.unl "select * from hvrmtrcv where status='3'"

thisname=`basename $0`

usage(){
	echo
	echo "Oracle�������ж��  v1.5"
	echo "========================="
	echo
	echo "Usage:"
	echo "	$thisname [-u usr/passwd] [-f keyword] [-i [-w linesize]] | [-h] [OutFile] <\"SqlStatement\"|TableName>" 
	echo
	echo "Parameter:"
	echo "	-u  ָ���û�/���� (Ĭ��:$DBUSER/$DBPASSWD)"
	echo "	-f  ָ����ָ��� (Ĭ��:'^\')"
	echo "	-i  ֱ��ִ��SQL (Ĭ��:��load��ʽת����ִ��)"
	echo "	-w  ָ������п��� (���-iʹ�� Ĭ��:$linesize)"
	echo "	-h  ����ֶ��� (�ų�-i���� Ĭ��:�����)"
	echo "	__  (Ĭ�ϵ�����ļ�TableName.unl)"
	echo
	echo "Example:"
	echo "	$thisname psjzd.unl \"select fieldname,mycomment from psjzd\""
	echo "	$thisname -u test/mima psjzd.unl \"select * from psjzd\""
	echo "	$thisname -iw 20 pjgcs_stru.unl \"desc pjgcs\""
	echo "	$thisname pfzgj.unl pfzgj"
	echo "	$thisname pfzgj"
	echo
	exit 1
}


# ��������

ouid="$DBUSER/$DBPASSWD"
tran=yes
linesize=3000
header=no
keyword=''

while getopts :u:f:hiw: OPTION
do
	case $OPTION in
		u) ouid=$OPTARG ;;
		f) keyword=$OPTARG ;;
		i) tran=no ;;
		w) linesize=$OPTARG ;;
		h) header=yes ;;
		?) usage ;;
	esac
done

shift `expr $OPTIND - 1`

if [ $# -eq 1 ]; then
	fout=$1.unl
	sqls="select * from $1"
elif [ $# -eq 2 ]; then
	fout=$1
	echo "$2" | wc -w | read n
	if [ $n -eq 1 ]; then
		sqls="select * from $2"
	else
		sqls="$2"
	fi
else
	usage
fi

ftmp="$fout.$$"
>$ftmp
if [ $? -ne 0 ]; then
	exit 1
fi


# SQL������ת��
#----------------------------------------

if [ "$tran" = "yes" ]; then
    sqls2=`echo "$sqls" |
	tr '\n' ' ' |
	awk '{
		printf $1
		for(i=2;i<=NF;i++){
			t=i-1
			if(substr($t,length($t),1)=="," || substr($i,1,1)==",") printf "%s",$i
			else printf " %s",$i
		}
		print ""
	}'`
	echo "$sqls2" > unload.tmp
	read select field from table  where <unload.tmp 
	echo $select $from | tr "[:upper:]" "[:lower:]" | read select from

	if [ "$select" != "select" -o "$from" != "from" ]; then
		echo "SQLת��ʧ��!" >&2
		exit 1
	fi

	if [ "$field" != "*" ]; then
		echo "$field" |
		awk -F',' '{
			for(i=1;i<=NF;i++) fld=fld""sprintf("%s||%c%s%c||",$i,39,"'$keyword'",39)
		}
		END{ print substr(fld,1,length(fld)-2) }' 
	else
		sqlplus -S $ouid <<-!!! | 
			desc $table
			exit
		!!!
		awk '{
			if(NR>2 && NF>1)fld=fld""sprintf("%s||%c%s%c||",$1,39,"'$keyword'",39);
		}
		END{ print substr(fld,1,length(fld)-2) }' 
	fi>unload.tmp
	read fields<unload.tmp
    \rm -f unload.tmp 
	sqls="select $fields from $table $where"

	if [ "$header" = "yes" ]; then
		echo "$table" > $fout
		echo "$fields" | sed 's/||//g' | tr -d "\'" >> $fout
	else
		> $fout
	fi
fi


# ж������
sqlplus -S $ouid <<-!!! >/dev/null
	set colsep '$keyword';
	set heading off;
	set feedback off;
	set pagesize 0;
	set echo off;
	set verify off;
	set linesize $linesize;
	set trimspool on;
	spool $ftmp;
	$sqls;
	spool off;
!!!


if [ $? -ne 0 ]; then
	echo "Error: oracle <$ouid> connect fail." >&2
	\rm -f $ftmp
	exit 1
fi


if [ ! -s "$ftmp" ]; then
	echo "No data unload." >&2
	\rm -f $ftmp
	exit 2
fi


head -30 $ftmp |
grep "^ERROR at line " |
read err
if [ -n "$err" ]; then
	cat $ftmp >&2
	\rm -f $ftmp
	exit 2
fi


if [ "$tran" = "yes" ]; then
	if [ "$header" = "yes" ]; then
		cat $ftmp >> $fout
		\rm $ftmp
	else
		mv $ftmp $fout
	fi
	exit 0
fi


# �ָ����滻��ȥ��β�ո�
awk '
BEGIN{ FS="'$keyword'" }
{
	for(i=1;i<=NF;i++){
		l=length($i);
		for(t=1;t<=l;t++) if(substr($i,t,1)!=" ") break;
		for(k=l;k>=t;k--) if(substr($i,k,1)!=" ") break;
		printf("%s",substr($i,t,k-t+1));
		printf("%s","'$keyword'");
	}
	print ""
}
' $ftmp >> $fout

\rm -f $ftmp
