#!/bin/sh

BAKDIR="../"TOPFrame.`date +%Y%m%d`.$$

if [ ! -d ${TOPFRAME_HOME} ]; then
   echo "TOPFrame not install."
   exit 1
fi

echo "stop all app ..."
${TOPFRAME_HOME}/sbin/top_pget -k top_app

echo "bakup dir ${BAKDIR}"
mkdir ./${BAKDIR}

echo "start backup ..."
mv ${TOPFRAME_HOME}/bin ./${BAKDIR}/
mv ${TOPFRAME_HOME}/sbin ./${BAKDIR}/
mv ${TOPFRAME_HOME}/db ./${BAKDIR}/
mv ${TOPFRAME_HOME}/include ./${BAKDIR}/
mv ${TOPFRAME_HOME}/lib ./${BAKDIR}/
mv ${TOPFRAME_HOME}/mak ./${BAKDIR}/
mv ${TOPFRAME_HOME}/tools ./${BAKDIR}/
mkdir ./${BAKDIR}/etc
mv ${TOPFRAME_HOME}/etc/topframe.ini ./${BAKDIR}/etc/
mv ${TOPFRAME_HOME}/etc/plugs.ini ./${BAKDIR}/etc/

echo "start update ..."
cp -r ../bin ${TOPFRAME_HOME}/
cp -r ../sbin ${TOPFRAME_HOME}/
cp -r ../db ${TOPFRAME_HOME}/
cp -r ../include ${TOPFRAME_HOME}/
cp -r ../lib ${TOPFRAME_HOME}/
cp -r ../mak ${TOPFRAME_HOME}/
cp -r ../tools ${TOPFRAME_HOME}/
cp ../etc/topframe.ini ${TOPFRAME_HOME}/etc/
cp ../etc/plugs.ini ${TOPFRAME_HOME}/etc/

mv ./topframe_upd.sh ./topframe_upd.sh.bak

echo "update end ."
