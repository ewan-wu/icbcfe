#!/bin/sh
if [ "$#" -lt 1 ]; then
	echo 'Usage: top_bunlde <pkgfile>'
	exit 1
fi

bunlefile=`basename "$1" '.tar.gz'`'.bundle'
echo "setup pkgfile: ${bunlefile}"
cat ${TOPFRAME_HOME}/tools/top_setup.sh "$1" > ${bunlefile}
echo "end ..."
