#!/bin/sh
while [ $# -gt 0 ]; do
	VER=`strings "$1" | grep '\^__VERSION_ID__\^' | sed 's/\^__VERSION_ID__\^=//'`
	if [ -z "$VER" ]; then
		echo "$1	Version[None]"
	else
		echo "$1	$VER"
	fi
	shift
done
