#!/usr/bin/perl -w
#
# Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.
# All Rights Reserved. 
# 
# create plug mod codeskel.
#
# FileName: pugcodeskel.pl
# Author: Xilin.Gao
# 
# History:
#   2010-08-31 Xilin.Gao Create.
#
use strict;

################Global Variables###################

################Global Functions###################

&main();

##
sub main()
{
    my $iArgc = @ARGV;
    my $codeskel_cmd;
    
    if($iArgc != 4) {
        print("Usage: plugcodeskel.pl <in point> <modname> <author> <desc>\n");
        exit;
    }
    
    $codeskel_cmd = "codeskel.pl '".$ARGV[1]."' '".$ARGV[2]."' '".$ARGV[3]."'";
    
    print($codeskel_cmd."\n");
    system($codeskel_cmd);
    
    &CreateSrcFile();
    &CreateHdrFile();
    
}

################Local Functions###################
sub CreateSrcFile()
{
    my $sSrcFile;
    my $i = 0;
    my @Lines;
    
    $sSrcFile = $ARGV[1].".c";
    open(CFILE, "<".$sSrcFile) or die("open $sSrcFile error.\n");
    @Lines = <CFILE>;
    close(CFILE);
    
    open(CFILE, ">".$sSrcFile) or die("open $sSrcFile error.\n");
    
    for($i = 0; $i < @Lines; $i++) {
        print CFILE ($Lines[$i]);
        if($i == 26) {
            print CFILE ("\n#define _LOGPRINT f_ptRTCoreCtx->pfnLogPrint\n");
        }
        
        if($i == 29) {
            print CFILE ('static int InitEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData);'    ."\n");
            print CFILE ('static int OnRunEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData);'   ."\n");
            print CFILE ('static int ExitEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData);'    ."\n");
            print CFILE ('static int DefaultEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData);' ."\n");
        }
        
        if($i == 31) {
            print CFILE ('static T_RTCORE_CONTEXT *f_ptRTCoreCtx = NULL; '."\n");
            print CFILE ('static T_PLUG_MGR_PLUG_VAR *f_ptPlugVar = NULL;'."\n");
        }
        
        if($i == 33) {
            print CFILE ('/*----------------------------------*/'."\n");
            print CFILE ('/*�¼�ӳ��*/                          '."\n");
            print CFILE ('/*----------------------------------*/'."\n");
            print CFILE ('EVENTMAP_PLUG_MGR_BEGIN'."\n");
            print CFILE ('EVENTMAP_PLUG_MGR_HANDLER(EVENT_PLUG_MGR_PLUG_INIT, InitEventHandler)'."\n");
            print CFILE ('EVENTMAP_PLUG_MGR_HANDLER(EVENT_PLUG_MGR_PROC_RUN, OnRunEventHandler)'."\n");
            print CFILE ('EVENTMAP_PLUG_MGR_HANDLER(EVENT_PLUG_MGR_PROC_EXIT, ExitEventHandler)'."\n");
            print CFILE ('EVENTMAP_PLUG_MGR_HANDLER_DEFAULT(DefaultEventHandler)'."\n");
            print CFILE ('EVENTMAP_PLUG_MGR_END'."\n\n");
            print CFILE ('/*�������غ���*/'."\n");
            print CFILE ('int '.$ARGV[0].'(T_PLUG_MGR_PLUG_VAR *ptPlugVar) '."\n");
            print CFILE ('{'."\n");
            print CFILE ('    ptPlugVar->pfnEventHdl = NAME_PLUG_MGR_EVENTHANLER;'."\n");
            print CFILE ('    f_ptPlugVar = ptPlugVar;'."\n");
            print CFILE ('    f_ptRTCoreCtx = ptPlugVar->ptRTCoreCtx;'."\n\n");
            print CFILE ('    return ERR_PLUG_MGR_OK;'."\n");
            print CFILE ('}'."\n");
        }
        
        if($i == 35) {
            print CFILE ('int InitEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData)'."\n");
            print CFILE ('{'."\n");
            print CFILE ('    return ERR_EVENT_MGR_OK;'."\n");
            print CFILE ('}'."\n\n");
            print CFILE ('int OnRunEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData)'."\n");
            print CFILE ('{'."\n");
            print CFILE ('    return ERR_EVENT_MGR_OK;'."\n");
            print CFILE ('}'."\n\n");
            print CFILE ('int ExitEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData)'."\n");
            print CFILE ('{'."\n");
            print CFILE ('    return ERR_EVENT_MGR_OK;'."\n");
            print CFILE ('}'."\n\n");
            print CFILE ('int DefaultEventHandler(int iPlugId, int iEventId, void *pInData, void *pOutData)'."\n");
            print CFILE ('{'."\n");
            print CFILE ('    return ERR_EVENT_MGR_OK;'."\n");
            print CFILE ('}'."\n\n");
        }
        
    }
    
    close(CFILE);
    
}

sub CreateHdrFile()
{
    my $sHdrFile;
    my $i = 0;
    my @Lines;
    
    $sHdrFile = $ARGV[1].".h";
    open(HFILE, "<".$sHdrFile) or die("open $sHdrFile error");
    @Lines = <HFILE>;
    close(HFILE);
    
    open(HFILE, ">".$sHdrFile) or die("open $sHdrFile error");
    for($i = 0; $i < @Lines; $i++) {
        print HFILE ($Lines[$i]);
        if($i == 21) {
            print HFILE ('#include "plug_mgr.h"'."\n");
        }
        
        
    }
    close(HFILE);
}

#######################END#####################
