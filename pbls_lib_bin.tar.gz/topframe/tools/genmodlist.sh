#!/bin/sh

TOP=`echo $TOPFRAME_HOME | sed 's/\//:/g'`
for MOD in `find $TOPFRAME_HOME -name "*.*c" | sort`; do
	FILE=`basename $MOD`
	MOD=`dirname $MOD | sed 's/\//:/g' | sed 's/'"$TOP"'//' | sed 's/:/\//g' | sed 's/$/\//g'`
	echo $FILE,$MOD
done | tee $TOPFRAME_HOME/tools/modlist
