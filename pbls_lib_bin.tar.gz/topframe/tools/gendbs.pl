#!/usr/bin/perl -w
#
# dbsvr��������
#
use strict;

#ȫ�ֱ�������
my @g_WdList;
my %g_WdTypeTable;
my %g_WdLenTable;
my %g_WdVarTable;
my %g_WdVarTypeTable;
my @g_KeyList;


#
&main();

#
sub main()
{
	my $Argc = @ARGV;
	if ($Argc != 3) {
		printf("Usage: gendbs.pl <modulename> <tablename> <dbincl header filename>\n");
		exit;
	}

	if(!$ENV{'SQLPATH'}) {
		print("SQLPATH environment variable not set\n");
		exit;
	}

	#system("clear");
	print("\n\n");
	print("*==========================================*\n");
	print("* DATABASE Service Routine Generation Tool *\n");
	print("*==========================================*\n");
	print("\n\n");
	print('This tool needs $SQLPATH environment variable'."\n");
	print("to locate the home directory\n");
	printf("The input file '%s.sql' must resides in %s/%s/.\n", $ARGV[1], $ENV{'SQLPATH'}, $ARGV[0]);
	print("And there must be table index in this file\n");
	print("\n\n");
	print("The result includes 3 files in current directory:\n\n");
	print("	 [modulename]_[tablename].wd  -- DBS routine working structure\n");
	print("	 dbsvr_[tablename].pc         -- DBS routine source code\n");
	print("	 [tablename]_HVAR.h           -- DBS variables declare\n");

	my $SqlFile = $ENV{'SQLPATH'}."/".$ARGV[0]."/".$ARGV[1].".sql";
	print("--------------------------------------------\n");
	print("gen ".$ARGV[1].".sql .\n");
	&GenWd($SqlFile);
	print("create ".lc($ARGV[0])."_".lc($ARGV[1]).".wd .\n");
	&GenWdFile();
	print("create ".uc($ARGV[1])."_HVAR.h .\n");
	&GenHvarFile();
	print("create "."dbsvr_".lc($ARGV[1]).".pc .\n");
	&GenDbs();
	print("\n".lc($ARGV[1])." dbs create success...\n\n");
}

#����sql�ļ�,������sql���ṹ
sub GenWd()
{
	my ($SqlFile) = @_;
	my $Line;
	my @Lines;
	my @Words;
	my $Word;
	my $Status = 0;

	open(SQLFILE, $SqlFile)||die("open file error!:".$SqlFile."\n");

	@Lines = <SQLFILE>;
	$Line = join(" ", @Lines);
	$Line = lc($Line);
	$Line =~ s/--.*//g;
	$Line =~ s/comment.*//g;
	$Line =~ s/\n|\)|\(|\{|\}|,|\t|\;/ /g;
	$Line =~ s/\*\//\*\/\n/g;
	$Line =~ s/\/\*.*//g;
	$Line =~ s/\s+/ /g;
	$Line =~ s/ null | not null / /g;
	$Line =~ s/^.*?create/create/g;

	@Words = split(/\s+/, $Line);
	my $i = 0;

	for($i = 0; $i < @Words; $i++) {
		if($Status == 0) {
			if($Words[$i] ne "create") {
				print("syntax error at the begining\n");
				exit;
			}

			$i++;
			if($Words[$i] ne "table") {
				print("syntax error at create\n");
				exit;
			}

			$i++;
			if($Words[$i] ne lc($ARGV[1])) {
				printf("syntax error input[%s] table name in sql file[%s]\n", lc($ARGV[1]), $Words[$i]);
				exit;
			}

			$Status = 1;
			next;
		}

		if($Status == 1 && $Words[$i] eq "primary") {
			$i++;
			if($Words[$i] ne "key") {
				print("primary key syntax error\n");
				exit;
			}
			$i++;
			my $Cnt;
			for($Cnt = 0; $i < @Words; $i++, $Cnt++) {
				$g_KeyList[$Cnt] = $Words[$i];
			}

			last;
		}

		if($Status == 1) {
			my $WdCnt = @g_WdList;
			my $WdName = $Words[$i];
			$g_WdList[$WdCnt] = $WdName;
			$i++;
			my $wdType = $Words[$i];
			my $wdLen;

			if($wdType eq "integer" || $wdType eq "serial"
				|| $wdType eq "int" || $wdType eq "smallint") {
				$g_WdTypeTable{$WdName} = $wdType;
				$g_WdVarTypeTable{$WdName} = "int";
				$g_WdVarTable{$WdName} = "i".&PraseVarName($WdName);

				next;
			}

			if($wdType eq "number" || $wdType eq "decimal") {
				$wdLen = $Words[$i];
				$g_WdTypeTable{$WdName} = $wdType;

				$i++;
				$wdLen = $Words[$i];

				if ($wdLen < 10) {
					$g_WdVarTypeTable{$WdName} = "int";
					$g_WdVarTable{$WdName} = "i".&PraseVarName($WdName);
				} else {
					$g_WdVarTypeTable{$WdName} = "double";
					$g_WdVarTable{$WdName} = "d".&PraseVarName($WdName);
				}

				next;
			}

			if($wdType eq "float") {
				$g_WdTypeTable{$WdName} = $wdType;
				$g_WdVarTypeTable{$WdName} = "double";
				$g_WdVarTable{$WdName} = "d".&PraseVarName($WdName);

				$i++;
				next;
			}

			if($wdType eq "char") {
				$g_WdTypeTable{$WdName} = $wdType;
				$i++;
				$wdLen = $Words[$i];

				$g_WdLenTable{$WdName} = $wdLen;

				$g_WdVarTable{$WdName} = "s".&PraseVarName($WdName);
				$g_WdVarTypeTable{$WdName} = "char";

				next;
			}

			if($wdType eq "varchar" || $wdType eq "varchar2") {
				$g_WdTypeTable{$WdName} = $wdType;
				$i++;
				$wdLen = $Words[$i];

				$g_WdLenTable{$WdName} = $wdLen;

				$g_WdVarTable{$WdName} = "s".&PraseVarName($WdName);
				$g_WdVarTypeTable{$WdName} = "varchar";

				next;
			}

			die("error type:".$wdType);

		}

	}

	close(SQLFILE);
}

#����wd �ļ�
sub GenWdFile()
{
	my $WdFile;
	my $WdName;

	$WdFile = lc($ARGV[0])."_".lc($ARGV[1]).".wd";
	open(WDFILE, ">".$WdFile)||die("open file error!:".$WdFile."\n");

	print WDFILE ("typedef struct TABLE_".uc($ARGV[1])."\n{\n");
	foreach $WdName (@g_WdList) {
		my $Type = $g_WdVarTypeTable{$WdName};
		if ($Type eq "char" || $Type eq "varchar") {
			print WDFILE ("\tchar\t".$g_WdVarTable{$WdName}."[".($g_WdLenTable{$WdName}+1)."];\n");
			next;
		}

		if ($Type eq "int") {
			print WDFILE ("\tint\t\t".$g_WdVarTable{$WdName}.";\n");
			next;
		}

		if ($Type eq "double") {
			print WDFILE ("\tdouble\t".$g_WdVarTable{$WdName}.";\n");
			next;
		}
	}

	print WDFILE ("}T_".uc($ARGV[1]).";\n");
	close(WDFILE);
}

#����hvar�ļ�
sub GenHvarFile()
{
	my $HvarFile;
	my $WdName;

	$HvarFile = uc($ARGV[1])."_HVAR.h";
	open(HVARFILE, ">".$HvarFile)||die("open file error!:".$HvarFile."\n");

	print HVARFILE ("#ifndef __".uc($ARGV[1])."_H\n");
	print HVARFILE ("#define __".uc($ARGV[1])."_H\n");
	print HVARFILE ("EXEC SQL begin declare section;\n");
	foreach $WdName (@g_WdList) {
		my $Type = $g_WdVarTypeTable{$WdName};
		if ($Type eq "char") {
			print HVARFILE ("\tstatic char\t\tH_".uc($ARGV[1])."_".uc($WdName)."[".($g_WdLenTable{$WdName}+1)."];\n");
			next;
		}

		if ($Type eq "varchar") {
			print HVARFILE ("\tstatic varchar\tH_".uc($ARGV[1])."_".uc($WdName)."[".($g_WdLenTable{$WdName}+1)."];\n");
			next;
		}

		if ($Type eq "int") {
			print HVARFILE ("\tstatic int\t\tH_".uc($ARGV[1])."_".uc($WdName).";\n");
			next;
		}

		if ($Type eq "double") {
			print HVARFILE ("\tstatic double\tH_".uc($ARGV[1])."_".uc($WdName).";\n");
			next;
		}
	}
	print HVARFILE ("EXEC SQL end declare section;\n");
	print HVARFILE ("#endif\n");
	close(HVARFILE);
}

#����pc�ļ�
sub GenDbs()
{
	my $DbsFile;
	my $WdName;

	$DbsFile = "dbsvr_".lc($ARGV[1]).".pc";
	open(DBSFILE, ">".$DbsFile)||die("open file error!:".$DbsFile."\n");

	print DBSFILE ("/*************************************/\n");
	print DBSFILE ("/* Copywrite (c) 2009                */\n");
	print DBSFILE ("/* Huateng Software System Co. Ltd.  */\n");
	print DBSFILE ("/*************************************/\n");
	print DBSFILE ("#include <stdio.h>\n");
	print DBSFILE ("#include <stdlib.h>\n");
	print DBSFILE ("#include <string.h>\n");
	print DBSFILE ("EXEC SQL INCLUDE sqlca;\n");
	print DBSFILE ("EXEC SQL INCLUDE sqlda;\n");
	print DBSFILE ("EXEC SQL BEGIN DECLARE SECTION;\n");
	print DBSFILE ( "EXEC SQL INCLUDE \"".lc($ARGV[0])."_wd.h\";\n");
	print DBSFILE ( "EXEC SQL INCLUDE \"".$ARGV[2]."\";\n");
	print DBSFILE ( "static T_".uc($ARGV[1])."\tsd_".lc($ARGV[1]).";\n");
	print DBSFILE ("EXEC SQL END DECLARE SECTION;\n");
	print DBSFILE ( "static T_".uc($ARGV[1])."\tsv_".lc($ARGV[1]).";\n");
	print DBSFILE ("EXEC SQL INCLUDE \"".uc($ARGV[1])."_HVAR.h\";\n");
	print DBSFILE ("#define str2var(v,s)						\\\n");
	print DBSFILE ("do {										\\\n");
	print DBSFILE ("	memset(&(v), 0, sizeof(v));				\\\n");
	print DBSFILE ("	memcpy((v).arr, (s), sizeof(s) - 1);	\\\n");
	print DBSFILE ("	(v).len = strlen((char *)(v).arr);		\\\n");
	print DBSFILE ("} while(0)\n");
	print DBSFILE ("#define var2str(s,v)					\\\n");
	print DBSFILE ("do {									\\\n");
	print DBSFILE ("	memcpy((s), (v).arr, (v).len);		\\\n");
	print DBSFILE ("	(s)[(v).len] = '\\0';				\\\n");
	print DBSFILE ("} while(0)\n");
	print DBSFILE ("static void dbs".uc($ARGV[1])."wd2hv(void);\n");
	print DBSFILE ("static void dbs".uc($ARGV[1])."hv2wd(void);\n");
	print DBSFILE ("/*************************************************************************/\n");
	print DBSFILE ("/*      input : DBS_FUNC  the batch dbs func                             */\n");
	print DBSFILE ("/*      return : the sqlca.sqlcode                                       */\n");
	print DBSFILE ("/*                             DBS_FIND                                  */\n");
	print DBSFILE ("/*                             DBS_LOCK                                  */\n");
	print DBSFILE ("/*                             DBS_UPDATE                                */\n");
	print DBSFILE ("/*                             DBS_INSERT                                */\n");
	print DBSFILE ("/*                             DBS_DELETE                                */\n");
	print DBSFILE ("/*                             DBS_CLOSE                                 */\n");
	print DBSFILE ("/*                             CUR_ALLOPEN                               */\n");
	print DBSFILE ("/*                             CUR_ALLFETCH                              */\n");
	print DBSFILE ("/*                             CUR_ALLCLOSE                              */\n");
	print DBSFILE ("/*************************************************************************/\n");

	#####################

	print DBSFILE ("int dbs".uc($ARGV[1])."(int ifunc, T_".uc($ARGV[1])." *LtpWd".uc($ARGV[1]).")\n");
	print DBSFILE ("{\n");
	print DBSFILE ("\tsqlca.sqlcode = 0;\n");
	print DBSFILE ("\tmemcpy(&sd_".lc($ARGV[1])." , LtpWd".uc($ARGV[1])." ,sizeof(sd_".lc($ARGV[1])."));\n");
	print DBSFILE ("\tdbs".uc($ARGV[1])."wd2hv();\n");
	print DBSFILE ("\tswitch(ifunc) \n\t{\n");

	#DBS_FIND
	print DBSFILE ("\tcase DBS_FIND : \n");
	print DBSFILE ("\t\tEXEC SQL select \n");
	my $i;
	for ($i = 0; $i < @g_WdList; $i++) {
		if($i == @g_WdList -1) {
			print DBSFILE ("\t\t\t".uc($g_WdList[$i])."\n");
		} else {
			print DBSFILE ("\t\t\t".uc($g_WdList[$i]).",\n");
		}
	}
	print DBSFILE ("\t\tinto \n");
	for ($i = 0; $i < @g_WdList; $i++) {
		$WdName = $g_WdList[$i];
		if($i == @g_WdList -1) {
			print DBSFILE ("\t\t\t:H_".uc($ARGV[1])."_".uc($WdName)."\n");
		} else {
			print DBSFILE ("\t\t\t:H_".uc($ARGV[1])."_".uc($WdName).",\n");
		}
	}
	print DBSFILE ("\t\tfrom ".lc($ARGV[1])."\n");
	print DBSFILE ("\t\twhere\n");

	for ($i = 0; $i < @g_KeyList; $i++) {
		$WdName = $g_KeyList[$i];
		if($i == @g_KeyList -1) {
			print DBSFILE ("\t\t\t".uc($WdName)." = :H_".uc($ARGV[1])."_".uc($WdName)." ;\n");
		} else {
			print DBSFILE ("\t\t\t".uc($WdName)." = :H_".uc($ARGV[1])."_".uc($WdName)." and\n");
		}
	}

	print DBSFILE ("\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != DB_NULL))\n\t\t\treturn(sqlca.sqlcode);\n");
	print DBSFILE ("\t\tdbs".uc($ARGV[1])."hv2wd();\n");
	print DBSFILE ("\t\tmemcpy(LtpWd".uc($ARGV[1]).", &sd_".lc($ARGV[1]).", sizeof(sd_".lc($ARGV[1])."));\n");
	print DBSFILE ("\t\treturn(0);\n");

	#DBS_LOCK
	print DBSFILE ("\tcase DBS_LOCK   :\n");
	print DBSFILE ("\tcase DBS_UPDATE :\n");
	print DBSFILE ("\tcase DBS_DELETE :\n");
	print DBSFILE ("\tif (ifunc == DBS_LOCK)\n");
	print DBSFILE ("\t{\n");
	print DBSFILE ("\t\tif (\n");
	for ($i = 0; $i < @g_KeyList; $i++) {
		$WdName = $g_KeyList[$i];
		if($g_WdVarTypeTable{$WdName} eq "char" || $g_WdVarTypeTable{$WdName} eq "varchar") {

			if($i == @g_KeyList -1) {
				print DBSFILE ("\t\tstrcmp(sv_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}." , sd_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}.") == 0 \n");
			} else {
				print DBSFILE ("\t\tstrcmp(sv_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}." , sd_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}.") == 0 &&\n");
			}
		} else {
			if($i == @g_KeyList -1) {
				print DBSFILE ("\t\t\tsv_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}." == sd_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}."\n");
			} else {
				print DBSFILE ("\t\t\tsv_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}." == sd_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}."&&\n ");
			}
		}
	}

	print DBSFILE ("\t\t)\n");
	print DBSFILE ("\t\t{\n");
	print DBSFILE ("\t\t\tmemcpy(LtpWd".uc($ARGV[1])." , &sv_".lc($ARGV[1])." , sizeof(sv_".lc($ARGV[1])."));\n");
	print DBSFILE ("\t\t\treturn(0);\n");
	print DBSFILE ("\t\t}\n");

	print DBSFILE ("\t\tEXEC SQL declare ".lc($ARGV[1])."_cur cursor for select\n");
	for ($i = 0; $i < @g_WdList; $i++) {
		if($i == @g_WdList -1) {
			print DBSFILE ("\t\t\t".uc($g_WdList[$i])."\n");
		} else {
			print DBSFILE ("\t\t\t".uc($g_WdList[$i]).",\n");
		}
	}

	print DBSFILE ("\t\tfrom ".lc($ARGV[1])."\n");
	print DBSFILE ("\t\twhere\n");
	for ($i = 0; $i < @g_KeyList; $i++) {
		$WdName = $g_KeyList[$i];
		if($i == @g_KeyList -1) {
			print DBSFILE ("\t\t\t".uc($WdName)." = :H_".uc($ARGV[1])."_".uc($WdName)." for update;\n");
		} else {
			print DBSFILE ("\t\t\t".uc($WdName)." = :H_".uc($ARGV[1])."_".uc($WdName)." and\n");
		}
	}
	print DBSFILE ("\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != DB_NULL))\n\t\t\treturn(sqlca.sqlcode);\n");
	print DBSFILE ("\t\tEXEC SQL open ".lc($ARGV[1])."_cur;\n");
	print DBSFILE ("\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != DB_NULL))\n\t\t\treturn(sqlca.sqlcode);\n");
	print DBSFILE ("\t\tEXEC SQL fetch ".lc($ARGV[1])."_cur into\n");
	for ($i = 0; $i < @g_WdList; $i++) {
		$WdName = $g_WdList[$i];
		if($i == @g_WdList -1) {
			print DBSFILE ("\t\t\t:H_".uc($ARGV[1])."_".uc($WdName).";\n");
		} else {
			print DBSFILE ("\t\t\t:H_".uc($ARGV[1])."_".uc($WdName).",\n");
		}
	}

	print DBSFILE ("\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != DB_NULL)) {\n");
	print DBSFILE ("\t\t\tmemset(&sv_".lc($ARGV[1]).", 0, sizeof(sv_".lc($ARGV[1])."));\n");
	print DBSFILE ("\t\t\treturn(sqlca.sqlcode);}\n");
	print DBSFILE ("\t\tdbs".uc($ARGV[1])."hv2wd();\n");
	print DBSFILE ("\t\tmemcpy(LtpWd".uc($ARGV[1])." , &sd_".lc($ARGV[1])." , sizeof(sd_".lc($ARGV[1])."));\n");
	print DBSFILE ("\t\tmemcpy(&sv_".lc($ARGV[1]).", &sd_".lc($ARGV[1]).", sizeof(sv_".lc($ARGV[1])."));\n");
	print DBSFILE ("\t\treturn(0);\n");
	print DBSFILE ("\t}\n\telse\n\t{\n");
	print DBSFILE ("\t\tif(\n");
	for ($i = 0; $i < @g_KeyList; $i++) {
		$WdName = $g_KeyList[$i];
		if($g_WdVarTypeTable{$WdName} eq "char" || $g_WdVarTypeTable{$WdName} eq "varchar") {

			if($i == @g_KeyList -1) {
				print DBSFILE ("\t\tstrcmp(sv_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}." , sd_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}.") != 0\n");
			} else {
				print DBSFILE ("\t\tstrcmp(sv_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}." , sd_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}.") != 0 ||\n");
			}
		} else {
			if($i == @g_KeyList -1) {
				print DBSFILE ("\t\t\tsv_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}." != sd_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}."\n");
			} else {
				print DBSFILE ("\t\t\tsv_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}." != sd_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}." ||\n ");
			}
		}
	 }
	print DBSFILE ("\t\t)\n\t\treturn(544);\n");

	#DBS_UPDATE
	print DBSFILE ("\t\tif (ifunc == DBS_UPDATE)\n\t\t{\n");
	my $KeyCnt = @g_KeyList;
	my $WdCnt = @g_WdList;
	if ($KeyCnt == $WdCnt) {
		print DBSFILE ("\t\treturn(545);\n");
	} else {
		my $IsFirst = 1;
		print DBSFILE ("\t\tEXEC SQL update ".lc($ARGV[1])." set \n");

		for ($i = 0; $i < @g_WdList; $i++) {
			$WdName = $g_WdList[$i];
			my $IsKey = 0;
			my $Wd;
			foreach $Wd (@g_KeyList) {
				if ($Wd eq $WdName) {
					$IsKey = 1;
					last;
				}
			}

			if($IsKey) {
				next;
			}

			if ($IsFirst) {
				$IsFirst = 0;
				print DBSFILE ("\t\t\t".uc($WdName)." = :H_".uc($ARGV[1])."_".uc($WdName));
			} else {
				print DBSFILE (",\n\t\t\t".uc($WdName)." = :H_".uc($ARGV[1])."_".uc($WdName));
			}
		}
		print DBSFILE ("\n");
		print DBSFILE ("\t\twhere current of ".lc($ARGV[1])."_cur;\n");
		#print DBSFILE ("\t\tmemset(&sv_".lc($ARGV[1]).", 0, sizeof(sv_".lc($ARGV[1])."));\n");
		print DBSFILE ("\t\treturn(sqlca.sqlcode);\n");
	}

	#DBS_DELETE
	print DBSFILE ("\t\t}\n\t\telse\n\t\t{\n");
	print DBSFILE ("\t\tEXEC SQL delete from ".lc($ARGV[1])." where current of ".lc($ARGV[1])."_cur ;\n");
	print DBSFILE ("\t\treturn(sqlca.sqlcode);\n");
	print DBSFILE ("\t\t}\n");
	print DBSFILE ("\t}\n");

	#DBS_INSERT
	print DBSFILE ("\tcase DBS_INSERT :\n");
	print DBSFILE ("\t\tEXEC SQL insert into ".lc($ARGV[1])." (\n");
	for ($i = 0; $i < @g_WdList; $i++) {

		if($i == @g_WdList -1) {
			print DBSFILE ("\t\t\t".uc($g_WdList[$i])."\n");
		} else {
			print DBSFILE ("\t\t\t".uc($g_WdList[$i]).",\n");
		}
	}
	print DBSFILE ("\t\t) values (\n");
	for ($i = 0; $i < @g_WdList; $i++) {
		$WdName = $g_WdList[$i];
		if($i == @g_WdList -1) {
			print DBSFILE ("\t\t\t:H_".uc($ARGV[1])."_".uc($WdName).");\n");
		} else {
			print DBSFILE ("\t\t\t:H_".uc($ARGV[1])."_".uc($WdName).",\n");
		}
	}
	print DBSFILE ("\t\treturn(sqlca.sqlcode);\n");

	#DBS_CLOSE
	print DBSFILE ("\tcase DBS_CLOSE :\n");
	print DBSFILE ("\t\tEXEC SQL close ".lc($ARGV[1])."_cur;\n");
	print DBSFILE ("\t\tmemset(&sv_".lc($ARGV[1]).", '\\0', sizeof(sv_".lc($ARGV[1])."));\n");
	print DBSFILE ("\t\treturn(0);\n");

	#CUR_ALLOPEN
	print DBSFILE ("\tcase CUR_ALLOPEN :\n");

	print DBSFILE ("\t\tEXEC SQL declare all_".lc($ARGV[1])."_cur cursor for select\n");
	for ($i = 0; $i < @g_WdList; $i++) {
		if($i == @g_WdList -1) {
			print DBSFILE ("\t\t\t".uc($g_WdList[$i])."\n");
		} else {
			print DBSFILE ("\t\t\t".uc($g_WdList[$i]).",\n");
		}
	}
	print DBSFILE ("\t\tfrom ".lc($ARGV[1])."\n");
	print DBSFILE ("\t\torder by\n");
	for ($i = 0; $i < @g_KeyList; $i++) {
		$WdName = $g_KeyList[$i];
		if($i == @g_KeyList -1) {
			print DBSFILE ("\t\t\t".uc($WdName).";\n");
		} else {
			print DBSFILE ("\t\t\t".uc($WdName).",\n");
		}
	}
	print DBSFILE ("\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != DB_NULL))\n\t\t\treturn(sqlca.sqlcode);\n");

	print DBSFILE ("\t\tEXEC SQL open all_".lc($ARGV[1])."_cur;\n");
	print DBSFILE ("\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != DB_NULL))\n\t\t\treturn(sqlca.sqlcode);\n");

	print DBSFILE ("\t\treturn(0);\n");

	#CUR_ALLFETCH
	print DBSFILE ("\tcase CUR_ALLFETCH :\n");

	print DBSFILE ("\t\tEXEC SQL fetch all_".lc($ARGV[1])."_cur into\n");
	for ($i = 0; $i < @g_WdList; $i++) {
		$WdName = $g_WdList[$i];
		if($i == @g_WdList -1) {
			print DBSFILE ("\t\t\t:H_".uc($ARGV[1])."_".uc($WdName).";\n");
		} else {
			print DBSFILE ("\t\t\t:H_".uc($ARGV[1])."_".uc($WdName).",\n");
		}
	}
	print DBSFILE ("\t\tif ((sqlca.sqlcode) && (sqlca.sqlcode != DB_NULL))\n\t\t\treturn(sqlca.sqlcode);\n");

	print DBSFILE ("\t\tdbs".uc($ARGV[1])."hv2wd();\n");
	print DBSFILE ("\t\tmemcpy(LtpWd".uc($ARGV[1])." , &sd_".lc($ARGV[1])." , sizeof(sd_".lc($ARGV[1])."));\n");
	print DBSFILE ("\t\treturn(0);\n");

	#CUR_ALLCLOSE
	print DBSFILE ("\tcase CUR_ALLCLOSE :\n");
	print DBSFILE ("\t\tEXEC SQL close all_".lc($ARGV[1])."_cur;\n");
	print DBSFILE ("\t\treturn(0);\n");

	#default
	print DBSFILE ("\tdefault :\n\t\treturn(543);\n");
	print DBSFILE ("\t}\n");
	print DBSFILE ("}\n");

	#wd2hv
	print DBSFILE ("static void dbs".uc($ARGV[1])."wd2hv(void)\n{\n");
	for ($i = 0; $i < @g_WdList; $i++) {
		$WdName = $g_WdList[$i];
		if($g_WdVarTypeTable{$WdName} eq "char") {
			print DBSFILE ("\tstrcpy(H_".uc($ARGV[1])."_".uc($WdName).", sd_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}.");\n");
			next;
		}

		if($g_WdVarTypeTable{$WdName} eq "varchar") {
			print DBSFILE ("\tstr2var(H_".uc($ARGV[1])."_".uc($WdName).", sd_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}.");\n");
			next;
		}

		print DBSFILE ("\tH_".uc($ARGV[1])."_".uc($WdName)." = sd_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}.";\n");
	}
	print DBSFILE ("}\n");

	#hv2wd
	print DBSFILE ("static void dbs".uc($ARGV[1])."hv2wd(void)\n{\n");
	for ($i = 0; $i < @g_WdList; $i++) {
		$WdName = $g_WdList[$i];
		if($g_WdVarTypeTable{$WdName} eq "char") {
			print DBSFILE ("\tstrcpy(sd_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}.", H_".uc($ARGV[1])."_".uc($WdName).");\n");
			next;
		}

		if($g_WdVarTypeTable{$WdName} eq "varchar") {
			print DBSFILE ("\tvar2str(sd_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}.", H_".uc($ARGV[1])."_".uc($WdName).");\n");
			next;
		}

		print DBSFILE ("\tsd_".lc($ARGV[1]).".".$g_WdVarTable{$WdName}." = H_".uc($ARGV[1])."_".uc($WdName).";\n");
	}
	print DBSFILE ("}\n");

	close(DBSFILE);
}

#���ɱ�����
sub PraseVarName()
{
	my ($WdName) = @_;
	my @Words;
	my $VarName;
	my $Word;

	@Words = split(/_/, $WdName);
	foreach $Word (@Words) {
		$VarName = $VarName.ucfirst($Word);
	}

	return $VarName;
}
#################END#######################
