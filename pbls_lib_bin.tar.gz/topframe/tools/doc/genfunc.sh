#!/bin/sh

PATH="`dirname $0`:$PATH"

usage()
{
	echo "Usage: $0 [-c connstr] mod func"
	exit 1
}

CONNSTR="$DBUSER/$DBPASS@$ORACLE_SID"

while getopts c: OPTION; do
	case $OPTION in
		c) CONNSTR=$OPTARG ;;
		?) usage ;;
	esac
done
shift `expr $OPTIND - 1`

if [ $# -lt 2 ]; then
	usage
fi

MOD=$1
FUN=$2

TMP=genfunc.$$.tmp

SQL="
select param_name \"������\",
       type       \"����\",
       remarks    \"˵��\"
  from tf_fun_params
 where mod_name = '$MOD'
   and fun_name = '$FUN'
 order by idx
"
sql2html.sh -c $CONNSTR -n "$SQL" > $TMP

N=`wc -l $TMP | cut -d' ' -f1`
if [ "$N" != "0" ]; then
	genhtml.sh -e -b '����˵��'
	cat $TMP
fi

genhtml.sh -t
rm -f $TMP
