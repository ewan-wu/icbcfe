#!/bin/sh

PATH="`dirname $0`:$PATH"

usage()
{
	echo "Usage: $0 [-c connstr]"
	exit 1
}

CONNSTR="$DBUSER/$DBPASS@$ORACLE_SID"

while getopts c: OPTION; do
	case $OPTION in
		c) CONNSTR=$OPTARG ;;
		?) usage ;;
	esac
done

linkit()
{
	echo "'<a href=\"$1' || $2 || '.html\">' || $2 || '</a>'"
}

genmod()
{
	TMP=modlist.$$.tmp

	MOD_NAME=`linkit mods/ mod_name`
	SQL="
select $MOD_NAME \"�����\",
       lib_name  \"����\",
       remarks   \"˵��\"
  from tf_mod
 where mod_name in (select mod_name from tf_fun)
 order by mod_name
"
	sql2html.sh -c $CONNSTR -t "����б�" "$SQL" > mods.html
	echo "generate [mods.html]"

	mkdir mods > /dev/null 2>&1

	sql2list.sh -c $CONNSTR \
		"select distinct mod_name from tf_fun order by mod_name" > $TMP

	while read MOD; do
		FUN_NAME=`linkit "${MOD}_" fun_name`
		SQL="
select $FUN_NAME   \"������\",
       declaration \"����\",
       remarks     \"˵��\"
  from tf_fun
 where mod_name = '$MOD'
"
		sql2html.sh -c $CONNSTR -t "���[$MOD]: �����б�" "$SQL" > mods/$MOD.html
		echo "generate [mods/$MOD.html]"
	done < $TMP

	rm -f $TMP

	sql2htmls.sh -c $CONNSTR -t "����˵��" -p "mods/" -e "genfunc.sh -c \\\"$CONNSTR\\\"" "
   set define off;
select     mod_name   ,
       nvl(fun_name   , '&nbsp;') \"������\",
       nvl(head_file  , '&nbsp;') \"ͷ�ļ�\",
       nvl(declaration, '&nbsp;') \"����\",
       nvl(remarks    , '&nbsp;') \"˵��\",
       nvl(ret_remarks, '&nbsp;') \"����ֵ\",
       nvl(usage      , '&nbsp;') \"�÷�\"
  from tf_fun
 order by mod_name, fun_name"
}

genplus()
{
	PLUG_NAME=`linkit plugs/ plug_name`
	SQL="
select $PLUG_NAME \"�����\",
       full_name  \"ȫ��\",
       version    \"�汾\",
       remarks    \"˵��\"
  from tf_plug
 order by plug_name
"
	sql2html.sh -c $CONNSTR -t "����б�" "$SQL" > plugs.html
	echo "generate [plugs.html]"

	mkdir plugs > /dev/null 2>&1

	sql2htmls.sh -c $CONNSTR -t "���˵��" -p "plugs/" -e "genplug.sh -c \\\"$CONNSTR\\\"" "
   set define off;
select     '',
       nvl(plug_name  , '&nbsp;') \"�����\",
       nvl(full_name  , '&nbsp;') \"ȫ��\",
       nvl(version    , '&nbsp;') \"�汾\",
       nvl(remarks    , '&nbsp;') \"˵��\",
       nvl(mod_name   , '&nbsp;') \"�����\",
       nvl(load_fun   , '&nbsp;') \"���غ���\",
       nvl(object     , '&nbsp;') \"������\",
       nvl(lib_name   , '&nbsp;') \"����\"
  from tf_plug
 order by plug_name"
}

genmod
genplus
