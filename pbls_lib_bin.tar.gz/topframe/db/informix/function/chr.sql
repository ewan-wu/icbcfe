/* mkdir -p $INFORMIXDIR/extend/topframe
 * cp $TOPFRAME_HOME/lib/libdbs_informix_func.so $INFORMIXDIR/extend/topframe/
 */
drop function chr;
create function chr(integer) returning char(1)
	with (not variant, parallelizable)
	external name '$INFORMIXDIR/extend/topframe/libdbs_informix_func.so(chr)'
	language c
end function;
