/* mkdir -p $INFORMIXDIR/extend/topframe
 * cp $TOPFRAME_HOME/lib/libdbs_informix_func.so $INFORMIXDIR/extend/topframe/
 */
drop function top_num2str;
create function top_num2str(num float, dot integer) returning varchar(32)
	with (not variant, parallelizable)
	external name '$INFORMIXDIR/extend/topframe/libdbs_informix_func.so(top_num2str)'
	language c
end function;
