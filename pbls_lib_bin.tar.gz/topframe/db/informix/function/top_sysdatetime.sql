drop function top_sysdatetime;
create function top_sysdatetime() returning char(14)
	return to_char(current, '%Y%m%d%H%M%S');
end function;
