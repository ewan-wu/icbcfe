drop function rtrim;
create function rtrim(str lvarchar) returning lvarchar
	with (not variant)
	define i integer;
	if str is null then
		let str = '';
	end if;
	if (length(str) > 0) then
		for i in (length(str) to 1 step -1)
			if substr(str, i, 1) != ' ' then
				exit for;
			end if;
		end for;
		return substr(str, 1, i);
	else
		return '';
	end if;
end function;
