drop function ltrim;
create function ltrim(str lvarchar) returning lvarchar
	with (not variant)
	define i integer;
	if str is null then
		let str = '';
	end if;
	for i in (1 to length(str))
		if substr(str, i, 1) != ' ' then
			exit for;
		end if;
	end for;
	return substr(str, i);
end function;
