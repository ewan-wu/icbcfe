drop function top_systime;
create function top_systime() returning char(6)
	return to_char(current, '%H%M%S');
end function;
