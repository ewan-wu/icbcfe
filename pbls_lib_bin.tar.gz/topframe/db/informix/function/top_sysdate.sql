drop function top_sysdate;
create function top_sysdate() returning char(8)
	return to_char(current, '%Y%m%d');
end function;
