drop function top_concat;
create function top_concat(str1 lvarchar, str2 lvarchar) returning lvarchar
	with (not variant)
	return str1 || str2;
end function;
