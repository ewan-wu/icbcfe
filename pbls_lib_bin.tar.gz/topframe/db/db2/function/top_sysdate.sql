create or replace function top_sysdate return varchar is
begin
	return to_char(sysdate, 'YYYYMMDD');
end top_sysdate;
