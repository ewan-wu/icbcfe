create or replace function top_systime return varchar is
begin
	return to_char(sysdate, 'HH24MISS');
end top_systime;
