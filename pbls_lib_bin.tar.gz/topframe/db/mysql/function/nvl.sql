drop function nvl;
create function nvl(v varchar(4000), d varchar(4000)) returns varchar(4000)
	return if(v, v, d);
