drop function top_num2str;
create function top_num2str(num decimal(32, 8), dot integer) returns varchar(32)
begin
	declare i int default 0;
	if dot is null then
		set dot = 0;
	end if;
	while i < dot do
		set num = num / 10;
		set i = i + 1;
	end while;
	return replace(format(num, dot), ',', '');
end
