drop function top_sysdatetime;
create function top_sysdatetime() returns char(14)
	return date_format(now(), '%Y%m%d%H%i%s');
