drop function chr;
create function chr(i integer) returns char(1)
	return char(i);
