drop table CRON;
create table CRON (
    APP             VARCHAR(255) NOT NULL,       /* Ӧ�ó����� */                   
    IDX             NUMBER(8) NOT NULL,          /* ��� */                      
    MIN             VARCHAR(255),       /* ���� */                      
    HOUR            VARCHAR(255),       /* Сʱ */                      
    DAY             VARCHAR(255),       /* �� */                       
    MONTH           VARCHAR(255),       /* �� */                       
    WEEK            VARCHAR(255),       /* ���� */                      
    COMMAND         VARCHAR(255),       /* ��ע */                      
    STATUS          CHAR(1),            /* ״̬ */                      
    PRIMARY KEY(APP, IDX)
);
comment on column CRON.APP is 'Ӧ�ó�����';
comment on column CRON.IDX is '���';
comment on column CRON.MIN is '����';
comment on column CRON.HOUR is 'Сʱ';
comment on column CRON.DAY is '��';
comment on column CRON.MONTH is '��';
comment on column CRON.WEEK is '����';
comment on column CRON.COMMAND is '��ע';
comment on column CRON.STATUS is '״̬';


