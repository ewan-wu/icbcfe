#!/bin/sh
gentabdef.pl mods_tabs.def 
tflist=`ls tf*.def`
for tffile in $tflist
do
  echo $tffile
  gensql.sh $tffile
done

gentabdef.pl fault.def
flist=`ls fault*.def`
for tffile in $flist
do
  echo $tffile
  gensql.sh $tffile
done
