drop table TOSVR;
create table TOSVR (
    TO_KEY          VARCHAR(64) NOT NULL,                    
    TO_INFO         VARCHAR(4000),                    
    TO_TIME         NUMBER(16)             
);
alter table TOSVR add constraint PK_TOSVR primary key(TO_KEY);



