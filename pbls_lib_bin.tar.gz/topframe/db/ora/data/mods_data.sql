insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_flowprocessor', 'FP_AddMod', 'int FP_AddMod(char *psModFile, int iOptions); ', 'flowprocessor.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_flowprocessor', 'FP_Run', 'int FP_Run(char *psKey, int iOptions); ', 'flowprocessor.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_flowprocessor', 'FP_GetErrors', 'int FP_GetErrors(char *psError); ', 'flowprocessor.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglbmsgrpt', 'msgRpt', 'int msgRpt(int nLevel, char *psFileName, int nLine, const char *psFunction, int nErrno, char *psBuf, ...) __MSGRPT_GNUC_EXT__; ', 'msg_rpt.h', 'int', null, 7, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglbmsgrpt', 'msgSetSvrId', 'int msgSetSvrId(int *pnMsgSvrId); ', 'msg_rpt.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgrpt_svrid', 'MSG_SetSvrId', 'int MSG_SetSvrId(int *pnMsgSvrId); ', 'msg_report_svrid.h', 'int', 'ret=0: success  ret<0: error', 1, 'Set msgsvr''s svrid', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgrpt_svrid', 'MSG_GetSvrId', 'int MSG_GetSvrId(void); ', 'msg_report_svrid.h', 'int', 'ret=0: success  ret<0: error', 0, 'Get msgsvr''s svrid', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReport', 'int msgReport(char *sType, char *sFile, int iLine, char *sFunc, int iErrno,char *sTitle, char *sFmt, ...);', 'msgsvr_api.h', null, 'ret=0: success  ret<0: error', 1, 'Report message', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReportV', 'int msgReportV(char *sType, char *sFile, int iLine, char *sFunc, int iErrno, char *sTitle, char *sFmt, va_list vaArgs); ', 'msgsvr_api.h', 'int', 'ret=0: success  ret<0: error', 8, 'Report message', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgSend', 'int msgSend(T_MSGSVR_INFO *ptMsg); ', 'msgsvr_api.h', 'int', 'ret=0: success  ret<0: error', 1, 'Send message to msgsvr', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc_helper', 'POC_Helper_Init', 'int POC_Helper_Init(T_POC_HELPER_OPTS *ptOpts); ', 'poc_helper.h', 'int', 'ret=0: success  ret<0: error', 1, 'Initialize POC Helper', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc_helper', 'POC_Helper_ExcSqlById', 'int POC_Helper_ExcSqlById(const char *sSqlId); ', 'poc_helper.h', 'int', 'ret=0: success  ret<0: error', 1, 'Execute SQL by id', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc_helper', 'POC_Helper_ExcSql', 'int POC_Helper_ExcSqlById(const char *sSqlId); ', 'poc_helper.h', 'int', 'ret=0: success  ret<0: error', 1, 'Execute SQL', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc_helper', 'POC_Helper_ExcSqlOpen', 'int POC_Helper_ExcSqlOpen(const char *sSql); ', 'poc_helper.h', 'int', 'ret=0: success  ret<0: error', 1, 'Open SQL', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc_helper', 'POC_Helper_ExcSqlFetch', 'int POC_Helper_ExcSqlFetch(void); ', 'poc_helper.h', 'int', 'ret=0: success  ret<0: error', 0, 'Fetch data from the opend SQL', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc_helper', 'POC_Helper_ExcSqlClose', 'int POC_Helper_ExcSqlClose(void); ', 'poc_helper.h', 'int', 'ret=0: success  ret<0: error', 0, 'Close SQL', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc_helper', 'POC_Helper_SqlCode', 'int POC_Helper_SqlCode(void); ', 'poc_helper.h', 'int', 'ret=0: success  ret<0: error', 0, 'Get sqlcode', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc_helper', 'POC_Helper_CheckValue', 'int POC_Helper_CheckValue(const char *sTag); ', 'poc_helper.h', 'int', 'ret=0: success  ret<0: error', 1, 'Check Value', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_CreateCtx', 'int POC_CreateCtx(T_POC_CRTCTX_OPTS *ptCrtCtxOpts); ', 'poc_itf.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ReleaseCtx', 'int POC_ReleaseCtx(int iOptions); ', 'poc_itf.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_AddDataSource', 'int POC_AddDataSource(T_POC_DATASOURCE *ptDataSource, int iOptions); ', 'poc_itf.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_DelDataSource', 'int POC_DelDataSource(char *psDataSource, int iOptions); ', 'poc_itf.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_BeginSession', 'int POC_BeginSession(int iId, int iOptions); ', 'poc_itf.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_EndSession', 'int POC_EndSession(int iId, int iOptions); ', 'poc_itf.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_RegObject', 'int POC_RegObject(T_POC_OBJECT_HANDLE hObjHdl, char *psName, char *psType, int iScope, int iOptions); ', 'poc_itf.h', 'int', null, 5, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_UnRegObject', 'int POC_UnRegObject(char *psName, int iOptions); ', 'poc_itf.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetObjectHdl', 'int POC_GetObjectHdl(char *psName, T_POC_OBJECT_HANDLE *phObjHdl); ', 'poc_itf.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ObjectNew', 'int POC_ObjectNew(char *psType, int iScope, char *psObjName, char *psInitParams, int iOptions); ', 'poc_itf.h', 'int', null, 5, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ObjectDel', 'int POC_ObjectDel( char *psName, int iOptions); ', 'poc_itf.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetValueS', 'int POC_GetValueS(const char *psTag, char *psVar, int iLen); ', 'poc_object.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetValueInt32', 'int POC_GetValueInt32(const char *psTag); ', 'poc_object.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetValueInt64', 'T_POC_INT64 POC_GetValueInt64(const char *psTag); ', 'poc_object.h', 'T_POC_INT64', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetValueDouble', 'double POC_GetValueDouble(const char *psTag); ', 'poc_object.h', 'double', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetValue', 'int POC_GetValueS(const char *psTag, char *psVar, int iLen); ', 'poc_object.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValueS', 'int POC_SetValueS(const char *psTag, const char *psVar, int iLen); ', 'poc_object.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValueInt32', 'int POC_SetValueInt32(const char *psTag, int iValue); ', 'poc_object.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValueInt64', 'int POC_SetValueInt64(const char *psTag, T_POC_INT64 lValue); ', 'poc_object.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValueDouble', 'int POC_SetValueDouble(const char *psTag, double dValue); ', 'poc_object.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValue', 'int POC_SetValueS(const char *psTag, const char *psVar, int iLen); ', 'poc_object.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ArrayGetValue', 'T_POC_VALUE * POC_ArrayGetValue(const char *psTag, int iPos, T_POC_VALUE *ptVar); ', 'poc_object.h', 'T_POC_VALUE*', 'tag ֵ', 3, '��ȡtagֵ������ӿڡ�', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ArraySetValue', 'int POC_ArraySetValue(const char *psTag, int iPos, T_POC_VALUE *ptVar); ', 'poc_object.h', 'int', '�ɹ�����0,ʧ�ܷ��� < 0', 3, '����tagֵ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ArrayCount', 'int POC_ArrayCount(const char *psTag); ', 'poc_object.h', 'int', '��¼��', 1, '��ȡ�����м�¼��', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ObjectCtl', 'int POC_ObjectCtl( char *psTag, char *psValues, int iOptions); ', 'poc_itf.h', 'int', '���ݾ����������', 3, '����ͨ�ò�������', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_ibm', 'ipcMsgQIbmMqCreateCtx', 'int ipcMsgQIbmMqCreateCtx(T_IPC_MSGQ_CTX *_ptMsgQCtx); ', 'ipc_msgque_ibm.h', 'int', '�ɹ�Ϊ0��ʧ��<0', 1, '�����ӿڻ���', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_ibm', 'ipcMsgQIbmMqInit', 'int ipcMsgQIbmMqInit(int iSvrid); ', 'ipc_msgque_ibm.h', 'int', '�ɹ�0��ʧ��<0', 1, '��ʼ��', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_ibm', 'ipcMsgQIbmMqPut', 'int ipcMsgQIbmMqPut(void *_pBuf, int iBufLen, T_IPC_MSGQ_MD *ptIpcMqMD); ', 'ipc_msgque_ibm.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 0, '������Ϣ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_ibm', 'ipcMsgQIbmMqFinalize', 'int ipcMsgQIbmMqFinalize(void); ', 'ipc_msgque_ibm.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 0, '�ͷ���Դ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_ibm', 'ipcMsgQIbmMqCfm', 'int ipcMsgQIbmMqCfm(int iFlg, int iOption); ', 'ipc_msgque_ibm.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 2, 'ȷ����Ϣ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_sysv', 'ipcMsgQSysVMqInit', 'int ipcMsgQSysVMqInit(int iSvrid); ', 'ipc_msgque_sysv.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 1, '��ʼ��', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_sysv', 'ipcMsgQSysVMqPut', 'int ipcMsgQSysVMqPut(void *_pBuf, int iBufLen, T_IPC_MSGQ_MD *ptIpcMqMD); ', 'ipc_msgque_sysv.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 0, '������Ϣ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_sysv', 'ipcMsgQSysVMqFinalize', 'int ipcMsgQSysVMqFinalize(void); ', 'ipc_msgque_sysv.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 0, '�ͷŻ���', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_sysv', 'ipcMsgQSysVMqCfm', 'int ipcMsgQSysVMqCfm(int iFlg, int iOption); ', 'ipc_msgque_sysv.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 2, 'ȷ����Ϣ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_topmq', 'ipcMsgQTopMqInit', 'int ipcMsgQTopMqInit(int iSvrid); ', 'ipc_msgque_topmq.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 1, '��ʼ��', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_topmq', 'ipcMsgQTopMqPut', 'int ipcMsgQTopMqPut(void *_pBuf, int iBufLen, T_IPC_MSGQ_MD *ptIpcMqMD); ', 'ipc_msgque_topmq.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 0, '������Ϣ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_topmq', 'ipcMsgQTopMqFinalize', 'int ipcMsgQTopMqFinalize(void); ', 'ipc_msgque_topmq.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 0, '�ͷ���Դ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_topmq', 'ipcMsgQTopMqCfm', 'int ipcMsgQTopMqCfm(int iFlg, int iOption); ', 'ipc_msgque_topmq.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 2, 'ȷ����Ϣ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQAddItf', 'int ipcMsgQAddItf(int iMsgQType, T_IPC_MSGQ_ITF *_ptMsgQItf); ', 'ipc_msgqueue.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 2, '���ӽӿ�', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comQueueInit', 'int comQueueInit(int iSvrid, T_COM_INITOPTION *ptComInitOption); ', 'com_queue.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴com_queue.h�еĶ���', 2, '��ʼ��', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comMsgSend', 'int comMsgSend(char *pBuf, int iBufLen, T_COM_MD *ptComMD); ', 'com_queue.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴com_queue.h�еĶ���', 3, '������Ϣ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comUMsgSend', 'int comUMsgSend(char *pBuf, int iBufLen, int iDestSvrId, T_COM_MD *ptComMD); ', 'com_queue.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴com_queue.h�еĶ���', 4, '��չ������Ϣ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comMsgRecv', 'int comMsgRecv(char *pBuf, int *piBufLen, T_COM_MD *ptComMD); ', 'com_queue.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴com_queue.h�еĶ���', 3, '������Ϣ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comUMsgRecv', 'int comUMsgRecv(char *pBuf, int *piBufLen, int *piSrcSvrId, T_COM_MD *ptComMD); ', 'com_queue.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴com_queue.h�еĶ���', 4, '��չ������Ϣ����������ָ��Դ��', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comQueueFinalize', 'int comQueueFinalize(int iSvrid); ', 'com_queue.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴com_queue.h�еĶ���', 1, '�ͷ���Դ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBegin', 'int dbsBegin(void); ', 'top_dbs.h', 'int', '�ɹ�0��ʧ��<0 ', 0, '��ʼ����', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindArray', 'int dbsBindArray(char *asArray[], int iCnt); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindArrayX', 'int dbsBindArrayX(T_TOP_DBS_STMT hStmt, char *asArray[], int iCnt); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindCount', 'int dbsBindCount(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindCountX', 'int dbsBindCountX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindName', 'char *dbsBindName(int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindNameX', 'char *dbsBindNameX(T_TOP_DBS_STMT hStmt, int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindNull', 'int dbsBindNull(int iCol); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindNullX', 'int dbsBindNullX(T_TOP_DBS_STMT hStmt, int iCol); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindSepValues', 'int dbsBindSepValues(char sSep, const char *sBuf, int iLen); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindSepValuesX', 'int dbsBindSepValuesX(T_TOP_DBS_STMT hStmt, char sSep, const char *sBuf, int iLen); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindString', 'int dbsBindString(int iCol, const char *sStr, int iLen); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindStringX', 'int dbsBindStringX(T_TOP_DBS_STMT hStmt, int iCol, const char *sStr, int iLen); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsClose', 'int dbsClose(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsCloseX', 'int dbsCloseX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnBuffer', 'int dbsColumnBuffer(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnBufferX', 'int dbsColumnBufferX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnChar', 'int dbsColumnChar(int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnCharX', 'int dbsColumnCharX(T_TOP_DBS_STMT hStmt, int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnChars', 'int dbsColumnChars(char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnCharsX', 'int dbsColumnCharsX(T_TOP_DBS_STMT hStmt, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnCount', 'int dbsColumnCount(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnCountX', 'int dbsColumnCountX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnLength', 'int dbsColumnLength(int iCol); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnLengthX', 'int dbsColumnLengthX(T_TOP_DBS_STMT hStmt, int iCol); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnName', 'char *dbsColumnName(int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnNameX', 'char *dbsColumnNameX(T_TOP_DBS_STMT hStmt, int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnString', 'int dbsColumnString(int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnStringX', 'int dbsColumnStringX(T_TOP_DBS_STMT hStmt, int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnStrings', 'int dbsColumnStrings(char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnStringsX', 'int dbsColumnStringsX(T_TOP_DBS_STMT hStmt, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsCommit', 'int dbsCommit(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsConnect', 'int dbsConnect(char *sConnStr); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsDisconnect', 'int dbsDisconnect(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsErrStr', 'char *dbsErrStr(void); ', 'top_dbs.h', 'char*', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsExecStmtX', 'int dbsExecStmtX(char *psSql, char * psBindVars[], int iBindCnt, char * psColVars[], int iColCnt); ', 'top_dbs.h', 'int', null, 5, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsExecute', 'int dbsExecute(const char *sSql); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
commit;
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsFetch', 'int dbsFetch(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsFetchX', 'int dbsFetchX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetErrInfo', 'char *dbsGetErrInfo(char *sBuf, int iBufLen); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetField', 'const char *dbsGetField(int iCol, int *piLen); ', 'top_dbs.h', 'const char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetFieldX', 'const char *dbsGetFieldX(T_TOP_DBS_STMT hStmt, int iCol, int *piLen); ', 'top_dbs.h', 'const char*', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetInd', 'int dbsGetInd(int iCol); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetIndX', 'int dbsGetIndX(T_TOP_DBS_STMT hStmt, int iCol); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetLastSql', 'char *dbsGetLastSql(char *sBuf, int iBufLen); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsLastSql', 'char *dbsLastSql(void); ', 'top_dbs.h', 'char*', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsOpen', 'int dbsOpen(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsOpenX', 'int dbsOpenX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsOperInit', 'int dbsOperInit(int iMaxVarNum, int iMaxNameLen); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsOperSetNumberLen', 'int dbsOperSetNumberLen(int nLen); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsOperSetNumberLenX', 'int dbsOperSetNumberLenX(T_TOP_DBS_STMT hStmt, int nLen); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsPrepare', 'int dbsPrepare(const char *sSql); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsPrepareX', 'int dbsPrepareX(const char *sSql, T_TOP_DBS_STMT *phStmt); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsRollback', 'int dbsRollback(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsSetCfgFile', 'int dbsSetCfgFile(char *psCfgFile, char *psCfgSection); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsSqlCode', 'int dbsSqlCode(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsSqlcaRestore', 'int dbsSqlcaRestore(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsSqlcaSave', 'int dbsSqlcaSave(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBegin', 'int dbsBegin(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindArray', 'int dbsBindArray(char *asArray[], int iCnt); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindArrayX', 'int dbsBindArrayX(T_TOP_DBS_STMT hStmt, char *asArray[], int iCnt); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindCount', 'int dbsBindCount(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindCountX', 'int dbsBindCountX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindName', 'char *dbsBindName(int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindNameX', 'char *dbsBindNameX(T_TOP_DBS_STMT hStmt, int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindNull', 'int dbsBindNull(int iCol); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindNullX', 'int dbsBindNullX(T_TOP_DBS_STMT hStmt, int iCol); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindSepValues', 'int dbsBindSepValues(char sSep, const char *sBuf, int iLen); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindSepValuesX', 'int dbsBindSepValuesX(T_TOP_DBS_STMT hStmt, char sSep, const char *sBuf, int iLen); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comQueueInit', 'int comQueueInit(int iSvrid, T_COM_INITOPTION *ptComInitOption); ', 'com_queue.h', 'int', null, 2, null, 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comMsgSend', 'int comMsgSend(char *pBuf, int iBufLen, T_COM_MD *ptComMD); ', 'com_queue.h', 'int', null, 3, null, 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comUMsgSend', 'int comUMsgSend(char *pBuf, int iBufLen, int iDestSvrId, T_COM_MD *ptComMD); ', 'com_queue.h', 'int', null, 4, null, 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comMsgRecv', 'int comMsgRecv(char *pBuf, int *piBufLen, T_COM_MD *ptComMD); ', 'com_queue.h', 'int', null, 3, null, 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comUMsgRecv', 'int comUMsgRecv(char *pBuf, int *piBufLen, int *piSrcSvrId, T_COM_MD *ptComMD); ', 'com_queue.h', 'int', null, 4, null, 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comQueueFinalize', 'int comQueueFinalize(int iSvrid); ', 'com_queue.h', 'int', null, 1, null, 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcore_ctx', 'RTCoreGetCtx', 'T_RTCORE_CONTEXT * RTCoreGetCtx(void); ', 'core_ctx.h', 'T_RTCORE_CONTEXT*', '����ָ��', 0, '��ȡӦ�����л���', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', 'cvtWrapConvert', 'int cvtWrapConvert(char *sInFmt, char *sInBuf, int iInBufLen, char *sOutFmt, char **psOutBuf, int *piOutBufLen); ', 'cvt_wrap.h', 'int', 'ret=0: success  ret<0: error', 6, 'Convert data format', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', 'cvtWrapFree', 'int cvtWrapFree(void); ', 'cvt_wrap.h', 'int', 'ret=0: success  ret<0: error', 0, 'Release resources', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', 'cvtWrapOnce', 'int cvtWrapOnce(char *sInFmt, char *sInBuf, int iInBufLen, char *sOutFmt, char *sOutBuf, int *piOutBufLen); ', 'cvt_wrap.h', 'int', 'ret=0: success  ret<0: error', 6, 'Convert data format', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBegin', 'int dbsBegin(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindArray', 'int dbsBindArray(char *asArray[], int iCnt); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindArrayX', 'int dbsBindArrayX(T_TOP_DBS_STMT hStmt, char *asArray[], int iCnt); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindCount', 'int dbsBindCount(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindCountX', 'int dbsBindCountX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindName', 'char *dbsBindName(int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindNameX', 'char *dbsBindNameX(T_TOP_DBS_STMT hStmt, int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindNull', 'int dbsBindNull(int iCol); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindNullX', 'int dbsBindNullX(T_TOP_DBS_STMT hStmt, int iCol); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindSepValues', 'int dbsBindSepValues(char sSep, const char *sBuf, int iLen); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindSepValuesX', 'int dbsBindSepValuesX(T_TOP_DBS_STMT hStmt, char sSep, const char *sBuf, int iLen); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindString', 'int dbsBindString(int iCol, const char *sStr, int iLen); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindStringX', 'int dbsBindStringX(T_TOP_DBS_STMT hStmt, int iCol, const char *sStr, int iLen); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsClose', 'int dbsClose(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsCloseX', 'int dbsCloseX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnBuffer', 'int dbsColumnBuffer(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnBufferX', 'int dbsColumnBufferX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnChar', 'int dbsColumnChar(int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnCharX', 'int dbsColumnCharX(T_TOP_DBS_STMT hStmt, int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnChars', 'int dbsColumnChars(char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnCharsX', 'int dbsColumnCharsX(T_TOP_DBS_STMT hStmt, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnCount', 'int dbsColumnCount(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnCountX', 'int dbsColumnCountX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnLength', 'int dbsColumnLength(int iCol); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnLengthX', 'int dbsColumnLengthX(T_TOP_DBS_STMT hStmt, int iCol); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnName', 'char *dbsColumnName(int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnNameX', 'char *dbsColumnNameX(T_TOP_DBS_STMT hStmt, int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnString', 'int dbsColumnString(int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnStringX', 'int dbsColumnStringX(T_TOP_DBS_STMT hStmt, int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnStrings', 'int dbsColumnStrings(char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnStringsX', 'int dbsColumnStringsX(T_TOP_DBS_STMT hStmt, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsCommit', 'int dbsCommit(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsConnect', 'int dbsConnect(char *sConnStr); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsDisconnect', 'int dbsDisconnect(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsErrStr', 'char *dbsErrStr(void); ', 'top_dbs.h', 'char*', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsExecStmtX', 'int dbsExecStmtX(char *psSql, char * psBindVars[], int iBindCnt, char * psColVars[], int iColCnt); ', 'top_dbs.h', 'int', null, 5, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsExecute', 'int dbsExecute(const char *sSql); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsFetch', 'int dbsFetch(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsFetchX', 'int dbsFetchX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetErrInfo', 'char *dbsGetErrInfo(char *sBuf, int iBufLen); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetField', 'const char *dbsGetField(int iCol, int *piLen); ', 'top_dbs.h', 'const char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetFieldX', 'const char *dbsGetFieldX(T_TOP_DBS_STMT hStmt, int iCol, int *piLen); ', 'top_dbs.h', 'const char*', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetInd', 'int dbsGetInd(int iCol); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetIndX', 'int dbsGetIndX(T_TOP_DBS_STMT hStmt, int iCol); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetLastSql', 'char *dbsGetLastSql(char *sBuf, int iBufLen); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsLastSql', 'char *dbsLastSql(void); ', 'top_dbs.h', 'char*', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsOpen', 'int dbsOpen(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsOpenX', 'int dbsOpenX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsOperInit', 'int dbsOperInit(int iMaxVarNum, int iMaxNameLen); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsOperSetNumberLen', 'int dbsOperSetNumberLen(int nLen); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsOperSetNumberLenX', 'int dbsOperSetNumberLenX(T_TOP_DBS_STMT hStmt, int nLen); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsPrepare', 'int dbsPrepare(const char *sSql); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsPrepareX', 'int dbsPrepareX(const char *sSql, T_TOP_DBS_STMT *phStmt); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsRollback', 'int dbsRollback(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsSetCfgFile', 'int dbsSetCfgFile(char *psCfgFile, char *psCfgSection); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsSqlCode', 'int dbsSqlCode(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsSqlcaRestore', 'int dbsSqlcaRestore(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsSqlcaSave', 'int dbsSqlcaSave(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
commit;
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindString', 'int dbsBindString(int iCol, const char *sStr, int iLen); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindStringX', 'int dbsBindStringX(T_TOP_DBS_STMT hStmt, int iCol, const char *sStr, int iLen); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsClose', 'int dbsClose(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsCloseX', 'int dbsCloseX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnBuffer', 'int dbsColumnBuffer(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnBufferX', 'int dbsColumnBufferX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnChar', 'int dbsColumnChar(int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnCharX', 'int dbsColumnCharX(T_TOP_DBS_STMT hStmt, int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnChars', 'int dbsColumnChars(char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnCharsX', 'int dbsColumnCharsX(T_TOP_DBS_STMT hStmt, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnCount', 'int dbsColumnCount(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnCountX', 'int dbsColumnCountX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnLength', 'int dbsColumnLength(int iCol); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnLengthX', 'int dbsColumnLengthX(T_TOP_DBS_STMT hStmt, int iCol); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnName', 'char *dbsColumnName(int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnNameX', 'char *dbsColumnNameX(T_TOP_DBS_STMT hStmt, int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnString', 'int dbsColumnString(int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnStringX', 'int dbsColumnStringX(T_TOP_DBS_STMT hStmt, int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnStrings', 'int dbsColumnStrings(char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnStringsX', 'int dbsColumnStringsX(T_TOP_DBS_STMT hStmt, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsCommit', 'int dbsCommit(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsConnect', 'int dbsConnect(char *sConnStr); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsDisconnect', 'int dbsDisconnect(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsErrStr', 'char *dbsErrStr(void); ', 'top_dbs.h', 'char*', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsExecStmtX', 'int dbsExecStmtX(char *psSql, char * psBindVars[], int iBindCnt, char * psColVars[], int iColCnt); ', 'top_dbs.h', 'int', null, 5, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsExecute', 'int dbsExecute(const char *sSql); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsFetch', 'int dbsFetch(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsFetchX', 'int dbsFetchX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetErrInfo', 'char *dbsGetErrInfo(char *sBuf, int iBufLen); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetField', 'const char *dbsGetField(int iCol, int *piLen); ', 'top_dbs.h', 'const char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetFieldX', 'const char *dbsGetFieldX(T_TOP_DBS_STMT hStmt, int iCol, int *piLen); ', 'top_dbs.h', 'const char*', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetInd', 'int dbsGetInd(int iCol); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetIndX', 'int dbsGetIndX(T_TOP_DBS_STMT hStmt, int iCol); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetLastSql', 'char *dbsGetLastSql(char *sBuf, int iBufLen); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsLastSql', 'char *dbsLastSql(void); ', 'top_dbs.h', 'char*', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsOpen', 'int dbsOpen(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsOpenX', 'int dbsOpenX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsOperInit', 'int dbsOperInit(int iMaxVarNum, int iMaxNameLen); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsOperSetNumberLen', 'int dbsOperSetNumberLen(int nLen); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsOperSetNumberLenX', 'int dbsOperSetNumberLenX(T_TOP_DBS_STMT hStmt, int nLen); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsPrepare', 'int dbsPrepare(const char *sSql); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsPrepareX', 'int dbsPrepareX(const char *sSql, T_TOP_DBS_STMT *phStmt); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsRollback', 'int dbsRollback(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsSetCfgFile', 'int dbsSetCfgFile(char *psCfgFile, char *psCfgSection); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsSqlCode', 'int dbsSqlCode(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsSqlcaRestore', 'int dbsSqlcaRestore(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsSqlcaSave', 'int dbsSqlcaSave(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBegin', 'int dbsBegin(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindArray', 'int dbsBindArray(char *asArray[], int iCnt); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindArrayX', 'int dbsBindArrayX(T_TOP_DBS_STMT hStmt, char *asArray[], int iCnt); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindCount', 'int dbsBindCount(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindCountX', 'int dbsBindCountX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindName', 'char *dbsBindName(int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindNameX', 'char *dbsBindNameX(T_TOP_DBS_STMT hStmt, int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindNull', 'int dbsBindNull(int iCol); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindNullX', 'int dbsBindNullX(T_TOP_DBS_STMT hStmt, int iCol); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindSepValues', 'int dbsBindSepValues(char sSep, const char *sBuf, int iLen); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindSepValuesX', 'int dbsBindSepValuesX(T_TOP_DBS_STMT hStmt, char sSep, const char *sBuf, int iLen); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindString', 'int dbsBindString(int iCol, const char *sStr, int iLen); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindStringX', 'int dbsBindStringX(T_TOP_DBS_STMT hStmt, int iCol, const char *sStr, int iLen); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsClose', 'int dbsClose(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsCloseX', 'int dbsCloseX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnBuffer', 'int dbsColumnBuffer(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnBufferX', 'int dbsColumnBufferX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnChar', 'int dbsColumnChar(int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnCharX', 'int dbsColumnCharX(T_TOP_DBS_STMT hStmt, int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnChars', 'int dbsColumnChars(char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnCharsX', 'int dbsColumnCharsX(T_TOP_DBS_STMT hStmt, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnCount', 'int dbsColumnCount(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnCountX', 'int dbsColumnCountX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnLength', 'int dbsColumnLength(int iCol); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnLengthX', 'int dbsColumnLengthX(T_TOP_DBS_STMT hStmt, int iCol); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnName', 'char *dbsColumnName(int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnNameX', 'char *dbsColumnNameX(T_TOP_DBS_STMT hStmt, int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnString', 'int dbsColumnString(int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnStringX', 'int dbsColumnStringX(T_TOP_DBS_STMT hStmt, int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnStrings', 'int dbsColumnStrings(char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnStringsX', 'int dbsColumnStringsX(T_TOP_DBS_STMT hStmt, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsCommit', 'int dbsCommit(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsConnect', 'int dbsConnect(char *sConnStr); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsDisconnect', 'int dbsDisconnect(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsErrStr', 'char *dbsErrStr(void); ', 'top_dbs.h', 'char*', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsExecStmtX', 'int dbsExecStmtX(char *psSql, char * psBindVars[], int iBindCnt, char * psColVars[], int iColCnt); ', 'top_dbs.h', 'int', null, 5, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsExecute', 'int dbsExecute(const char *sSql); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsFetch', 'int dbsFetch(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsFetchX', 'int dbsFetchX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetErrInfo', 'char *dbsGetErrInfo(char *sBuf, int iBufLen); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetField', 'const char *dbsGetField(int iCol, int *piLen); ', 'top_dbs.h', 'const char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetFieldX', 'const char *dbsGetFieldX(T_TOP_DBS_STMT hStmt, int iCol, int *piLen); ', 'top_dbs.h', 'const char*', null, 3, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetInd', 'int dbsGetInd(int iCol); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetIndX', 'int dbsGetIndX(T_TOP_DBS_STMT hStmt, int iCol); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetLastSql', 'char *dbsGetLastSql(char *sBuf, int iBufLen); ', 'top_dbs.h', 'char*', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsLastSql', 'char *dbsLastSql(void); ', 'top_dbs.h', 'char*', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsOpen', 'int dbsOpen(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsOpenX', 'int dbsOpenX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsOperInit', 'int dbsOperInit(int iMaxVarNum, int iMaxNameLen); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsOperSetNumberLen', 'int dbsOperSetNumberLen(int nLen); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsOperSetNumberLenX', 'int dbsOperSetNumberLenX(T_TOP_DBS_STMT hStmt, int nLen); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsPrepare', 'int dbsPrepare(const char *sSql); ', 'top_dbs.h', 'int', null, 1, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsPrepareX', 'int dbsPrepareX(const char *sSql, T_TOP_DBS_STMT *phStmt); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
commit;
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsRollback', 'int dbsRollback(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsSetCfgFile', 'int dbsSetCfgFile(char *psCfgFile, char *psCfgSection); ', 'top_dbs.h', 'int', null, 2, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsSqlCode', 'int dbsSqlCode(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsSqlcaRestore', 'int dbsSqlcaRestore(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsSqlcaSave', 'int dbsSqlcaSave(void); ', 'top_dbs.h', 'int', null, 0, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfault_ipc_hook', 'hookMsgQCreateCtx', 'int hookMsgQCreateCtx(T_IPC_MSGQ_CTX *_ptMsgQCtx); ', 'fault_ipc_hook.h', 'int', '�ɹ� 0�� ʧ�� < 0', 1, '�ݴ����ӻ�������', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfault_ipc_hook', 'hookMsgQInit', 'int hookMsgQInit(int iSvrid); ', 'fault_ipc_hook.h', 'int', '�ɹ� 0�� ʧ�� < 0', 1, '��ʼ��', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfault_ipc_hook', 'hookMsgQPut', 'int hookMsgQPut(void *_pBuf, int iBufLen, T_IPC_MSGQ_MD *ptIpcMqMD); ', 'fault_ipc_hook.h', 'int', '�ɹ� 0�� ʧ�� < 0', 0, '����ʱ������Ϣ��Ŀǰ�����κ�����', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfault_ipc_hook', 'hookMsgQCfm', 'int hookMsgQCfm(int iFlg, int iOption); ', 'fault_ipc_hook.h', 'int', '�ɹ� 0�� ʧ�� < 0', 2, '��Ϣȷ�Ͻ׶δ���', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfault_ipc_hook', 'hookMsgQFinalize', 'int hookMsgQFinalize(void); ', 'fault_ipc_hook.h', 'int', '�ɹ� 0�� ʧ�� < 0', 0, '�����ͷ�', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfunction_plug_ctl', 'plugAddInterface', ' int plugAddInterface(int nVersion, char *psName, fncSetDefault fpSetDefault); ', 'plug_ctl.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfunction_plug_ctl', 'plugAddPlug', ' int plugAddPlug(int nVersion, char *psInterfaceName, char *psName, void *ptData); ', 'plug_ctl.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfunction_plug_ctl', 'plugInitInterface', ' int plugInitInterface(char *psFile, char *psSecation); ', 'plug_ctl.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperTransaction', 'int BIZ_HelperTransaction(char *psCond); ', 'biz_helper.h', 'int', '�ɹ� 0�� ʧ�� < 0', 1, '������', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSendMsg', 'int BIZ_HelperSendMsg(char *psBuf, char *psLen, char *psAcc, char *psCond); ', 'biz_helper.h', 'int', '�ɹ� 0�� ʧ�� < 0', 4, '������Ϣ�������������е���', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSetValue', 'int BIZ_HelperSetValue(char *psTag, char *psValue, char *psLen); ', 'biz_helper.h', 'int', '�ɹ� 0�� ʧ�� < 0', 3, '���̸�������������tagֵ', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSetValue2', 'int BIZ_HelperSetValue2(char *psBuf, char *psPos, char *psLen, char *psTag); ', 'biz_helper.h', 'int', '�ɹ� 0�� ʧ�� < 0', 4, '���̸�����������buf��ָ��λ�õ�ֵ�����õ�ָ��tag', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperCvtGenOutMsg', 'int BIZ_HelperCvtGenOutMsg(char *psTag, char *psArgs); ', 'biz_helper.h', 'int', '�ɹ� 0�� ʧ�� < 0', 2, '���������Ϣ', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperCvtInit', 'int BIZ_HelperCvtInit(char *psTag, char *psArgs); ', 'biz_helper.h', 'int', '�ɹ� 0�� ʧ�� < 0', 2, '��ʽ������', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperTotaSetting', 'int BIZ_HelperTotaSetting(char *psInMsg, char *psOutMsg, char *psTag, char *psCond); ', 'biz_helper.h', 'int', 'ret=0: success  ret<0: error', 4, 'Set TOTA data structure', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperLoadSysPara', 'int BIZ_HelperLoadSysPara(char *sTable); ', 'biz_helper.h', 'int', 'ret=0: success  ret<0: error', 1, 'Load Table SYSPARA to POC', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperLocTranInit', 'int BIZ_HelperLocTranInit(char *psInMsg); ', 'biz_helper.h', 'int', '�ɹ� 0�� ʧ�� < 0', 1, '��ʼ��locswt���񻷾�', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperCvtLoad', 'int BIZ_HelperCvtLoad(char *psArgs); ', 'biz_helper.h', 'int', '�ɹ� 0�� ʧ�� < 0', 1, '�������м��ظ�ʽת������Դ', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_PocHelperInit', 'int BIZ_PocHelperInit(char *psSqlTable, char *psChkTable); ', 'biz_helper.h', 'int', 'ret=0: success  ret<0: error', 2, 'Initialize POC Helper', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'locStdSetErrTable', 'int locStdSetErrTable(char *sTable); ', 'biz_helper.h', 'int', 'ret=0: success  ret<0: error', 1, 'Set STD error message table', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'locStdErrTrace', 'int locStdErrTrace(char *sErrCode); ', 'biz_helper.h', 'int', 'ret=0: success  ret<0: error', 1, 'Trace STD error with error code', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'locStdErr', 'int locStdErr(void);', 'biz_helper.h', 'int', 'ret=0: success  ret<0: error', 0, 'Trace STD error with POC tag "var.errcode"', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'locCustSetErrTable', 'int locCustSetErrTable(char *sTable); ', 'biz_helper.h', 'int', 'ret=0: success  ret<0: error', 1, 'Set CUST error message table', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'locCustErrTrace', 'int locCustErrTrace(char *sErrCode); ', 'biz_helper.h', 'int', 'ret=0: success  ret<0: error', 1, 'Trace CUST error with error code', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'locCustErr', 'int locCustErr(void);', 'biz_helper.h', 'int', 'ret=0: success  ret<0: error', 0, 'Trace CUST error with POC tag "var.errcode"', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_CreateCtx', 'T_DLM_CTX_HANDLE DLM_CreateCtx(T_DLM_CRTCTX_OPTS *ptCrtCtxOpts); ', 'dllmgr_itf.h', 'T_DLM_CTX_HANDLE', '�ɹ������������ʧ�ܣ� NULL', 1, '������̬���������', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_AddLib', 'int DLM_AddLib(T_DLM_CTX_HANDLE hCtx, char *psLibName, char *psLibPath, int iOptions); ', 'dllmgr_itf.h', 'int', '�ɹ� 0�� ʧ�� < 0', 4, '���ӿ�', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_DelLib', 'int DLM_DelLib(T_DLM_CTX_HANDLE hCtx, char *psLibName, int iOptions); ', 'dllmgr_itf.h', 'int', '�ɹ� 0�� ʧ�� < 0', 3, 'ɾ��һ����', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_GetFun', 'void * DLM_GetFun(T_DLM_CTX_HANDLE hCtx, char *psNameSpace, char *psFunName, int iOptions); ', 'dllmgr_itf.h', 'void*', '�ɹ�������ָ�� ʧ�ܣ�NULL', 4, '��ȡ����ָ��', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_AddFun', 'int DLM_AddFun(T_DLM_CTX_HANDLE hCtx, char *psLibName, char *psNameSpace, char *psFunName, int iOptions); ', 'dllmgr_itf.h', 'int', '�ɹ� 0�� ʧ�� < 0', 5, '���Ӻ���', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_GetErrors', 'int DLM_GetErrors(T_DLM_CTX_HANDLE hCtx, char *psError); ', 'dllmgr_itf.h', 'int', '0', 2, '��ȡ������Ϣ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_SetAsDefaultCtx', 'int DLM_SetAsDefaultCtx(T_DLM_CTX_HANDLE hCtx, int iOptions); ', 'dllmgr_itf.h', 'int', '�ɹ� 0�� ʧ�� < 0', 2, '����Ĭ�ϻ���', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_GetDefaultCtx', 'T_DLM_CTX_HANDLE DLM_GetDefaultCtx(void); ', 'dllmgr_itf.h', 'T_DLM_CTX_HANDLE', '�ɹ���������� ʧ�ܣ�NULL', 0, '��ȡĬ�ϻ������', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_flowprocessor', 'FP_CreateCtx', 'int FP_CreateCtx(T_FP_CRTCTX_OPTS *ptCrtCtxOpts); ', 'flowprocessor.h', 'int', '�ɹ� 0�� ʧ�� < 0', 1, '�������̻���', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_cvt', 'POC_Datasource4CvtCreateCTX', 'int POC_Datasource4CvtCreateCTX(T_POC_DATASOURCE *ptDataSource, T_POC_DATASOURCE_CRTCTX_OPTS *ptCrtCtxOpts, T_DATASOURCE_ARG *ptInitParams); ', 'poc_datasource_cvt.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 3, '������ʽת��poc����Դ�ӿڻ���', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_static', 'POC_Datasource4StaticCreateCTX', 'int POC_Datasource4StaticCreateCTX(T_POC_DATASOURCE *ptDataSource, T_POC_DATASOURCE_CRTCTX_OPTS *ptCrtCtxOpts, T_DATASOURCE_ARG *ptInitParams); ', 'poc_datasource_static.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 3, '������̬��������Դ����', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsCloseX', 'int dbsCloseX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, '�ر��α꣬���׺ΪXϵ�к������ʹ��', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsLastSql', 'char *dbsLastSql(void); ', 'top_dbs.h', 'char*', null, 0, '��ȡ���ִ�е�sql���ѷ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOperInit', 'int dbsOperInit(int iMaxVarNum, int iMaxNameLen); ', 'top_dbs.h', 'int', null, 2, '��ʼ��sql����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsPrepare', 'int dbsPrepare(const char *sSql); ', 'top_dbs.h', 'int', null, 1, '׼���α꣬�ѷ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsSetDbType', 'int dbsSetDbType(int iDbType); ', 'top_dbs.h', 'int', null, 1, '�������ݿ����ͣ�֧�֣�oracle db2 sybase mqsql informix', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoInit', 'int signAutoInit(char *sTable); ', 'topsign_auto.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoGenerate', 'int signAutoGenerate (char *sKey, char *sSign, int iLen); ', 'topsign_auto.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoGenerateWithCert', 'int signAutoGenerateWithCert(char *sKey, char *sSign, int iLen); ', 'topsign_auto.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoVerify', 'int signAutoVerify (char *sKey, char *sSign, int iLen); ', 'topsign_auto.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoVerifyWithCert', 'int signAutoVerifyWithCert(char *sKey, char *sSign, int iLen, T_SIGN_CERT *ptCert); ', 'topsign_auto.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signInit', 'int signInit(char *sFile, char *sSection); ', 'topsign.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signFinal', 'int signFinal(void); ', 'topsign.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signGenerateAdd', 'int signGenerateAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signGenerateReset', 'int signGenerateReset(void); ', 'topsign.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signGenerate', 'int signGenerateAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signGenerateWithCert', 'int signGenerateWithCert(char *sKey, char *sSign, int iLen); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signVerifyAdd', 'int signVerifyAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signVerifyReset', 'int signVerifyReset(void); ', 'topsign.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signVerify', 'int signVerifyAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signVerifyWithCert', 'int signVerifyWithCert(char *sKey, char *sSign, int iLen, T_SIGN_CERT *ptCert); ', 'topsign.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signDecodeCert', 'int signDecodeCert(T_SIGN_CERT *ptCert); ', 'topsign.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signInit', 'int signInit(char *sFile, char *sSection); ', 'topsign.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signFinal', 'int signFinal(void); ', 'topsign.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signGenerateAdd', 'int signGenerateAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signGenerateReset', 'int signGenerateReset(void); ', 'topsign.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signGenerate', 'int signGenerateAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signGenerateWithCert', 'int signGenerateWithCert(char *sKey, char *sSign, int iLen); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signVerifyAdd', 'int signVerifyAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signVerifyReset', 'int signVerifyReset(void); ', 'topsign.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signVerify', 'int signVerifyAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signVerifyWithCert', 'int signVerifyWithCert(char *sKey, char *sSign, int iLen, T_SIGN_CERT *ptCert); ', 'topsign.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signDecodeCert', 'int signDecodeCert(T_SIGN_CERT *ptCert); ', 'topsign.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algSort', 'void algSort(void *pBase, size_t iNum, size_t iSize, F_COMPAR fCompar); ', 'util_alg.h', 'void', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algBSearch', 'void *algBSearch(const void *pKey, const void *pBase, size_t iNum, size_t iSize, F_COMPAR fCompar); ', 'util_alg.h', 'void*', null, 5, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algLSearch', 'void *algLSearch(const void *pKey, const void *pBase, size_t iNum, size_t iSize, F_COMPAR fCompar); ', 'util_alg.h', 'void*', null, 5, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHCreate', 'int algHCreate(size_t iNum); ', 'util_alg.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHSearch', 'T_ITEM *algHSearch(T_ITEM tItem); ', 'util_alg.h', 'T_ITEM*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHEnter', 'int algHEnter(T_ITEM tItem); ', 'util_alg.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHDestroy', 'void algHDestroy(void); ', 'util_alg.h', 'void', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHCreateR', 'int algHCreateR(size_t iNum, T_HTABLE *ptHtab); ', 'util_alg.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHSearchR', 'T_ITEM *algHSearchR(T_ITEM tItem, T_HTABLE *ptHtab); ', 'util_alg.h', 'T_ITEM*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHEnterR', 'int algHEnterR(T_ITEM tItem, T_HTABLE *ptHtab); ', 'util_alg.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHDestroyR', 'void algHDestroyR(T_HTABLE *ptHtab); ', 'util_alg.h', 'void', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvOpen', 'T_CSV *csvOpen(char *sFileName); ', 'util_csv.h', 'T_CSV*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRow', 'int csvReadRow(T_CSV *ptCsv, char cSep); ', 'util_csv.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRow2', 'int csvReadRow2(T_CSV *ptCsv, const char *sSep); ', 'util_csv.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowSkip', 'int csvReadRowSkip(T_CSV *ptCsv, char cSep, char cSkip); ', 'util_csv.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowN', 'int csvReadRowN(T_CSV *ptCsv, char cSep, int iCnt); ', 'util_csv.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowN2', 'int csvReadRowN2(T_CSV *ptCsv, const char *sSep, int iCnt); ', 'util_csv.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowSkipN', 'int csvReadRowSkipN(T_CSV *ptCsv, char cSep, char cSkip, int iCnt); ', 'util_csv.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowExt', 'int csvReadRowExt(T_CSV *ptCsv, char cSep, char cQuote); ', 'util_csv.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvClose', 'int csvClose(T_CSV *ptCsv); ', 'util_csv.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStr', 'int csvSplitStr(char *sStr, char cSep, T_SPLIT_STR *ptSplitStr); ', 'util_csv.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStr2', 'int csvSplitStr2(char *sStr, const char *sSep, T_SPLIT_STR *ptSplitStr); ', 'util_csv.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStrN', 'int csvSplitStrN(char *sStr, char cSep, int iCnt, T_SPLIT_STR *ptSplitStr); ', 'util_csv.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStrN2', 'int csvSplitStrN2(char *sStr, const char *sSep, int iCnt, T_SPLIT_STR *ptSplitStr); ', 'util_csv.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWrite', 'int csvWrite(FILE *fpFile, char cSep, int iCnt, ...); ', 'util_csv.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteV', 'int csvWriteV(FILE *fpFile, char cSep, int iCnt, char *psCol[]); ', 'util_csv.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteExt', 'int csvWriteExt(FILE *fpFile, char cSep, char cQuote, int iCnt, ...); ', 'util_csv.h', 'int', null, 5, null, null, null, null, null, null, null, null);
commit;
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteExtV', 'int csvWriteExtV(FILE *fpFile, char cSep, char cQuote, int iCnt, char *psCol[]); ', 'util_csv.h', 'int', null, 5, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnNew', 'T_CTN *ctnNew(int iSize, F_CTN_COMPAR fCompar); ', 'util_ctn.h', 'T_CTN*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnReAlloc', 'int ctnReAlloc(T_CTN *ptCtn); ', 'util_ctn.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnFree', 'int ctnFree(T_CTN *ptCtn); ', 'util_ctn.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSetSorted', 'int ctnSetSorted(T_CTN *ptCtn, int iSorted); ', 'util_ctn.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSetCompar', 'int ctnSetCompar(T_CTN *ptCtn, F_CTN_COMPAR fCompar); ', 'util_ctn.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnAdd', 'int ctnAdd(T_CTN *ptCtn, void *pData); ', 'util_ctn.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnGet', 'void *ctnGet(T_CTN *ptCtn, int iIdx); ', 'util_ctn.h', 'void*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnIdx', 'int ctnIdx(T_CTN *ptCtn, void *pData); ', 'util_ctn.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSort', 'int ctnSort(T_CTN *ptCtn); ', 'util_ctn.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSearch', 'void *ctnSearch(T_CTN *ptCtn, const void *pKey); ', 'util_ctn.h', 'void*', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSearchL', 'void *ctnSearchL(T_CTN *ptCtn, const void *pKey, const void *pCur); ', 'util_ctn.h', 'void*', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSearchM', 'void *ctnSearchM(T_CTN *ptCtn, const void *pKey, const void *pCur); ', 'util_ctn.h', 'void*', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSearchIdx', 'int ctnSearchIdx(T_CTN *ptCtn, const void *pKey); ', 'util_ctn.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSearchIdxL', 'int ctnSearchIdxL(T_CTN *ptCtn, const void *pKey, const int iCur); ', 'util_ctn.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSearchIdxM', 'int ctnSearchIdxM(T_CTN *ptCtn, const void *pKey, const int iCur); ', 'util_ctn.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQInit', 'int ipcMsgQInit(int iSvrid); ', 'ipc_msgqueue.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 1, 'ipc�ӿڳ�ʼ��', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQPut', 'int ipcMsgQPut(void *_pBuf, int iBufLen, T_IPC_MSGQ_MD *ptIpcMqMD); ', 'ipc_msgqueue.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 0, '������Ϣ', '�ɹ���0 ʧ�ܣ�<0', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQGet', 'int ipcMsgQGet(void *pBuf, int *piBufLen, T_IPC_MSGQ_MD *ptIpcMqMD); ', 'ipc_msgqueue.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 0, '������Ϣ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQFinalize', 'int ipcMsgQFinalize(void); ', 'ipc_msgqueue.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 0, '�����ͷ�', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQCfm', 'int ipcMsgQCfm(int iFlg, int iOption); ', 'ipc_msgqueue.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 2, 'ȷ����Ϣ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQAddHookItf', 'int ipcMsgQAddHookItf(T_IPC_MSGQ_ITF *_ptMsgQItf, int iOption); ', 'ipc_msgqueue.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 2, '����hook�ӿ�', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent_cli', 'mqInitialize', 'int mqInitialize(T_MQ_AGENT_CFG * ptMQAgentCfg); ', 'mq_agent.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 1, 'mq������ʼ��', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent_cli', 'mqDisConnect', 'int mqDisConnect(void); ', 'mq_agent.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 0, '�Ͽ�����', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent_cli', 'mqSend', 'int mqSend(char *psQName, void *pInBuf, int iLen, T_MQ_AGENT_MD *ptMd, int *piReason); ', 'mq_agent.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 0, '������Ϣ', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent_cli', 'mqRecv', 'int mqRecv(char *psQName, void *pOutBuf, int iBufLen, int *piMsgLen, T_MQ_AGENT_MD *ptMd, int *piReason); ', 'mq_agent.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 0, '������Ϣ', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent_cli', 'mqGetMQMDSet', 'int mqGetMQMDSet(T_MQ_MD_SET *pMqMdSet); ', 'mq_agent.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 1, '������Ϣ��������ʹ���Զ���������ʱʹ��', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent', 'mqInitialize', 'int mqInitialize(T_MQ_AGENT_CFG * ptMQAgentCfg); ', 'mq_agent.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 1, '��ʼ������', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent', 'mqDisConnect', 'int mqDisConnect(void); ', 'mq_agent.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 0, '�Ͽ�����', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent', 'mqSend', 'int mqSend(char *psQName, void *pInBuf, int iLen, T_MQ_AGENT_MD *ptMd, int *piReason); ', 'mq_agent.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 0, '������Ϣ', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent', 'mqRecv', 'int mqRecv(char *psQName, void *pOutBuf, int iBufLen, int *piMsgLen, T_MQ_AGENT_MD *ptMd, int *piReason); ', 'mq_agent.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 0, '������Ϣ', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent', 'mqGetMQMDSet', 'int mqGetMQMDSet(T_MQ_MD_SET *pMqMdSet); ', 'mq_agent.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 1, '������Ϣ���������Զ���MQ��Ϣ����ʱʹ��', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_sms_modem', 'smsSend', 'int smsSend(char *sTty, char *sDest, char *sBody); ', 'net_sms_modem.h', 'int', 'ret=0: success  ret<0: error', 3, 'Send SMS', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbbridge2', 'bdgGetEnv', 'T_BDG_ENV *bdgGetEnv(void); ', 'plug_bridge.h', 'T_BDG_ENV*', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_cvt', 'POC_Datasource4CvtReleaseCTX', 'int POC_Datasource4CvtReleaseCTX(int iOptions); ', 'poc_datasource_cvt.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 1, '�ͷŸ�ʽת��poc����Դ����', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_funs', 'POC_Datasource4FunsCreateCTX', 'int POC_Datasource4FunsCreateCTX(T_POC_DATASOURCE *ptDataSource, T_POC_DATASOURCE_CRTCTX_OPTS *ptCrtCtxOpts, T_DATASOURCE_ARG *ptInitParams); ', 'poc_datasource_funs.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 3, '��������poc����Դ����', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_funs', 'POC_Datasource4FunsReleaseCTX', 'int POC_Datasource4FunsReleaseCTX(int iOptions); ', 'poc_datasource_funs.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 1, '�ͷź���poc����Դ����', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_mem', 'POC_Datasource4MemCreateCTX', 'int POC_Datasource4MemCreateCTX(T_POC_DATASOURCE *ptDataSource, T_POC_DATASOURCE_CRTCTX_OPTS *ptCrtCtxOpts, T_DATASOURCE_ARG *ptInitParams); ', 'poc_datasource_mem.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 3, '����poc��̬�ڴ�����Դ����', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_mem', 'POC_Datasource4MemReleaseCTX', 'int POC_Datasource4MemReleaseCTX(int iOptions); ', 'poc_datasource_mem.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 1, '�ͷ�poc��̬�ڴ�����Դ����', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_static', 'POC_Datasource4StaticReleaseCTX', 'int POC_Datasource4StaticReleaseCTX(int iOptions); ', 'poc_datasource_static.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 1, '�ͷ�poc��̬����Դ����', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteInit', 'int rteInit(int iAlgo, int iSvrEnable, void *sOption); ', 'route.h', 'int', 'ret=0: success  ret<0: error', 0, 'Initialize Route', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteInitEnd', 'int rteInitEnd(void); ', 'route.h', 'int', 'ret=0: success  ret<0: error', 0, 'Finalize Route', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteReset', 'int rteReset(void); ', 'route.h', 'int', 'ret=0: success  ret<0: error', 0, 'Clean Route data inside library', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRoute', 'int rteSetRoute(int iRouteId, int iSrcSvrId, int iDestSvrId, char *sDestSvrFmt); ', 'route.h', 'int', 'ret=0: success  ret<0: error', 4, 'Set a Route information', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteMap', 'int rteSetRouteMap(char *sRouteKey, int iRouteId); ', 'route.h', 'int', 'ret=0: success  ret<0: error', 2, 'Set a Route Map information', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteSvr', 'int rteSetRouteSvr(int iSvrId, char *sOutFmt, int iRouteFlag, int iRouteLocId, char *sRouteCvtFmt); ', 'route.h', 'int', 'ret=0: success  ret<0: error', 5, 'Set a Route Server information', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteLoc', 'int rteSetRouteLoc(int iRouteLocId, int iInd, int iPos, int iLen, char *sStart, char *sEnd); ', 'route.h', 'int', 'ret=0: success  ret<0: error', 6, 'Set a Route Location information', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteNext', 'int rteNext(char *sRouteKey, int iSrcSvrId, int *piDestSvrId, char *sDestSvrFmt); ', 'route.h', 'int', 'ret=0: success  ret<0: error', 4, 'Get Next Route', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteFree', 'int rteFree(void); ', 'route.h', 'int', 'ret=0: success  ret<0: error', 0, 'Free data generated by last query route', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSvrInfo', 'int rteSvrInfo(int iSvrId, char *sBuf, int iBufLen, char *sOutFmt, char *sKey, int iKeyLen); ', 'route.h', 'int', 'ret=0: success  ret<0: error', 6, 'Get Server Information', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSvrFree', 'int rteSvrFree(void); ', 'route.h', 'int', 'ret=0: success  ret<0: error', 0, 'Free data generated by last query server', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteErrStr', 'const char *rteErrStr(void); ', 'route.h', 'constchar*', 'route error string', 0, 'Get Route error string', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtcp_hdr_helper', 'tcpHelperHdr2Int', 'int tcpHelperHdr2Int(void *pHdr, int iLen); ', 'tcp_hdr_helper.h', 'int', '> 0: tcpͨѶ���ĳ��� <0:ʧ��', 0, '����tcpͨѶͷ����', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtcp_hdr_helper', 'tcpHelperInt2Hdr', 'int tcpHelperInt2Hdr(int iVar, void *pHdr, int iLen); ', 'tcp_hdr_helper.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 0, '�����ĳ���ת��Ϊtcpͷ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtcp_hdr_helper', 'tcpHelperSetCustFun', 'int tcpHelperSetCustFun(PFN_TCPHELPER_HDR2INT pfnHdr2Int, PFN_TCPHELPER_INT2HDR pfnInt2Hdr); ', 'tcp_hdr_helper.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 2, '�����Զ���tcpͷ���㺯��', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryWrapDecrypt', 'int cryWrapDecrypt(int iMethod, char *sBuf, int iBufLen); ', 'topcry.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHex', 'char *cryHex(const char *sInBuf, int iInLen, char *sOutBuf); ', 'topcry.h', 'char*', null, 3, 'ʮ�����Ʊ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryUnHex', 'int cryUnHex(const char *sInBuf, char *sOutBuf); ', 'topcry.h', 'int', null, 2, 'ʮ�����ƽ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64', 'char *cryBase64(const char *sInBuf, int iInLen, char *sOutBuf); ', 'topcry.h', 'char*', null, 3, 'base64����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryUnBase64', 'int cryUnBase64(const char *sInBuf, char *sOutBuf); ', 'topcry.h', 'int', null, 2, 'base64����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHexEncode', 'int cryHexEncode(const char *sInBuf, int iInLen, char *sOutBuf, int *piOutLen); ', 'topcry.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHexDecode', 'int cryHexDecode(const char *sInBuf, int iInLen, char *sOutBuf, int *piOutLen); ', 'topcry.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64Encode', 'int cryBase64Encode (const char *sInBuf, int iInLen, char *sOutBuf, int *piOutLen); ', 'topcry.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64Decode', 'int cryBase64Decode (const char *sInBuf, int iInLen, char *sOutBuf, int *piOutLen); ', 'topcry.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3UtilEncrypt', 'int cryDes3UtilEncrypt(const char *sInBuf, int iInLen, char *sOutBuf, int *piOutLen, const char sKey[24]); ', 'topcry.h', 'int', null, 5, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3UtilDecrypt', 'int cryDes3UtilDecrypt(const char *sInBuf, int iInLen, char *sOutBuf, int *piOutLen, const char sKey[24]); ', 'topcry.h', 'int', null, 5, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3Encrypt', 'int cryDes3Encrypt(const char *sKey, int iKeyLen, const char *sInBuf, int iInLen, char *sOutBuf, int *piOutLen); ', 'topcry.h', 'int', null, 6, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3Decrypt', 'int cryDes3Decrypt(const char *sKey, int iKeyLen, const char *sInBuf, int iInLen, char *sOutBuf, int *piOutLen); ', 'topcry.h', 'int', null, 6, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesEncrypt', 'int cryAesEncrypt(const char *sKey, int iKeyLen, const char *sInBuf, int iInLen, char *sOutBuf, int *piOutLen); ', 'topcry.h', 'int', null, 6, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpSend', 'int smtpSend(char *sHostName, int iPort, char *sUser, char *sPass, char *sCharset, char *sTo, char *sSubject, char *sBody); ', 'net_smtp.h', 'int', 'ret=0: success  ret<0: error', 8, 'Send Email', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpMailNew', 'T_MAIL_SEND *smtpMailNew(char *sHostName, int iPort, char *sUser, char *sPass, char *sCharset); ', 'net_smtp.h', 'T_MAIL_SEND*', 'ret!=NULL: success  ret=NULL error', 5, 'Create an Email context', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpMailFree', 'int smtpMailFree(T_MAIL_SEND *ptMail); ', 'net_smtp.h', 'int', 'ret=0: success  ret<0: error', 1, 'Free Email context', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpMailSend', 'int smtpMailSend(T_MAIL_SEND *ptMail, char *sTo, char *sSubject, char *sBody, int iBodyLen); ', 'net_smtp.h', 'int', 'ret=0: success  ret<0: error', 5, 'Send Email by an Email context', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glb_toctl_server', 'toPlugLoad', ' int toPlugLoad(T_PLUG_MGR_PLUG_VAR *ptPlugVar); ', 'plug_toctl_server.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'PlugMgrRegPlug', 'int PlugMgrRegPlug(char *psCfgSection, E_PLUG_MGR_LOADMOD eLoadMod, PFN_PLUG_MGR_PLUG_LOAD_FUN pfnPlugFun); ', 'plug_mgr.h', 'int', null, 3, 'ע����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'PlugMgrLoadPlug', 'int PlugMgrLoadPlug(int iId); ', 'plug_mgr.h', 'int', null, 1, '���ز��', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'PlugMgrOnStart', 'int PlugMgrOnStart(void); ', 'plug_mgr.h', 'int', null, 0, 'Ӧ������', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'RTCoreStart', 'int RTCoreStart(int argc, char *argv[]); ', 'rt_core.h', 'int', null, 2, '����ʱӦ�������ӿ�ʵ��', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'RTCoreInit', 'int RTCoreInit(T_RTCORE_CONTEXT *ptRTCoreCtx); ', 'rt_core.h', 'int', null, 1, '����ʱ��ʼ���ӿ�ʵ��', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'RTCoreMain', 'int RTCoreMain(T_RTCORE_CONTEXT *ptRTCoreCtx); ', 'rt_core.h', 'int', null, 1, '����ʱִ�����ʵ��', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'RTCoreExit', 'void RTCoreExit(void); ', 'rt_core.h', 'void', null, 0, '����ʱ�����˳��ӿ�ʵ��', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperGetStr', 'int CfgOperGetStr(char *psSection, char *psObj, char *psKey, char *psDefault, char *psOutBuf, int iLenBuf, char *psCfgFile); ', 'cfg_oper.h', 'int', null, 7, '��ȡ����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperGetInt', 'int CfgOperGetInt(char *psSection, char *psObj, char *psKey, int iDefault, char *psCfgFile); ', 'cfg_oper.h', 'int', null, 5, '�������ļ��л�ȡ����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrInitialize', 'int EventMgrInitialize(int iOption); ', 'event_mgr.h', 'int', null, 1, '�¼���������ʼ��', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrRegPlug', 'int EventMgrRegPlug(int iPlugId); ', 'event_mgr.h', 'int', null, 1, '���¼�������ע����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrRegEventHandler', 'int EventMgrRegEventHandler(int iPlugId, int iEventId, int iToEventId, PFN_EVENT_MGR_EHDL pfnEventHandler, int iOption); ', 'event_mgr.h', 'int', null, 5, '���¼�������ע���¼�����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrPostEvent', 'int EventMgrPostEvent(int iSrcPlugId, int iEventId, void *pInData, void *pOutData, int iOption); ', 'event_mgr.h', 'int', null, 5, '�����¼�', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperMGetStr', 'int CfgOperMGetStr(char *psSection, char *psObj, char *psKey, char *psDefault, char *psOutBuf, int iLenBuf, char *psCfgFile[]); ', 'cfg_oper.h', 'int', null, 7, '�Ӷ�������ļ��л�ȡ����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlOpen', 'int sqlOpen(char *zDbFile); ', 'sqlmem.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlOpenMem', 'int sqlOpenMem(void); ', 'sqlmem.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlClose', 'int sqlClose(void); ', 'sqlmem.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlIsOpend', 'int sqlIsOpend(void); ', 'sqlmem.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlExecute', 'int sqlExecute(char *zSql); ', 'sqlmem.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlGetTable', 'int sqlGetTable(char *zSql, char ***pazResust, int *piRow, int *piCol); ', 'sqlmem.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlFreeTable', 'int sqlFreeTable(char **azResult); ', 'sqlmem.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlPrepare', 'T_SQL_STMT sqlPrepare(char *zSql); ', 'sqlmem.h', 'T_SQL_STMT', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlStep', 'int sqlStep(T_SQL_STMT stmt); ', 'sqlmem.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlReset', 'int sqlReset(T_SQL_STMT stmt); ', 'sqlmem.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlFinalize', 'int sqlFinalize(T_SQL_STMT stmt); ', 'sqlmem.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlBindInt', 'int sqlBindInt(T_SQL_STMT stmt, int iCol, int iValue); ', 'sqlmem.h', 'int', null, 3, null, null, null, null, null, null, null, null);
commit;
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlBindString', 'int sqlBindString(T_SQL_STMT stmt, int iCol, char *zValue); ', 'sqlmem.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlBindDouble', 'int sqlBindDouble(T_SQL_STMT stmt, int iCol, double dValue); ', 'sqlmem.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlBindNull', 'int sqlBindNull(T_SQL_STMT stmt, int iCol); ', 'sqlmem.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlColumnInt', 'int sqlColumnInt(T_SQL_STMT stmt, int iCol); ', 'sqlmem.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlColumnString', 'const char *sqlColumnString(T_SQL_STMT stmt, int iCol); ', 'sqlmem.h', 'constchar*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlColumnDouble', 'double sqlColumnDouble(T_SQL_STMT stmt, int iCol); ', 'sqlmem.h', 'double', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlErrStr', 'const char *sqlErrStr(void); ', 'sqlmem.h', 'const char*', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlVersion', 'const char *sqlVersion(void); ', 'sqlmem.h', 'const char*', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesDecrypt', 'int cryAesDecrypt(const char *sKey, int iKeyLen, const char *sInBuf, int iInLen, char *sOutBuf, int *piOutLen); ', 'topcry.h', 'int', null, 6, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryMd5', 'char *cryMd5(const char *sInBuf, int iInLen, char sOutBuf[16]); ', 'topcry.h', 'char*', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryMd5File', 'char *cryMd5File(const char *sFile, char sOutBuf[16]); ', 'topcry.h', 'char*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'crySha1', 'char *crySha1(const char *sInBuf, int iInLen, char sOutBuf[20]); ', 'topcry.h', 'char*', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'crySha1File', 'char *crySha1File(const char *sFile, char sOutBuf[20]); ', 'topcry.h', 'char*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHexSelfTest', 'int cryHexSelfTest(int iVerbose); ', 'topcry.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64SelfTest', 'int cryBase64SelfTest(int iVerbose); ', 'topcry.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDesSelfTest', 'int cryDesSelfTest(int iVerbose); ', 'topcry.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesSelfTest', 'int cryAesSelfTest(int iVerbose); ', 'topcry.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryMdxSelfTest', 'int cryMdxSelfTest(int iVerbose); ', 'topcry.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryShaxSelfTest', 'int cryShaxSelfTest(int iVerbose); ', 'topcry.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBegin', 'int dbsBegin(void); ', 'top_dbs.h', 'int', null, 0, '��ʼ����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindArray', 'int dbsBindArray(char *asArray[], int iCnt); ', 'top_dbs.h', 'int', null, 2, '��һ��������ѷ���', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindArrayX', 'int dbsBindArrayX(T_TOP_DBS_STMT hStmt, char *asArray[], int iCnt); ', 'top_dbs.h', 'int', null, 3, '��һ�����', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindCount', 'int dbsBindCount(void); ', 'top_dbs.h', 'int', null, 0, '��ȥ�󶨲����������ѷ���', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindCountX', 'int dbsBindCountX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, '��ȡ�󶨲�������', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindName', 'char *dbsBindName(int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 2, '��ȡ�󶨲��������ѷ���', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindNameX', 'char *dbsBindNameX(T_TOP_DBS_STMT hStmt, int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 3, '��ȡ�󶨲�����', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindNull', 'int dbsBindNull(int iCol); ', 'top_dbs.h', 'int', null, 1, '��Null,�ѷ���', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindNullX', 'int dbsBindNullX(T_TOP_DBS_STMT hStmt, int iCol); ', 'top_dbs.h', 'int', null, 2, '��Null', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindSepValues', 'int dbsBindSepValues(char sSep, const char *sBuf, int iLen); ', 'top_dbs.h', 'int', null, 3, '�ѷ���', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindSepValuesX', 'int dbsBindSepValuesX(T_TOP_DBS_STMT hStmt, char sSep, const char *sBuf, int iLen); ', 'top_dbs.h', 'int', null, 4, null, 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindString', 'int dbsBindString(int iCol, const char *sStr, int iLen); ', 'top_dbs.h', 'int', null, 3, '�ѷ���', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindStringX', 'int dbsBindStringX(T_TOP_DBS_STMT hStmt, int iCol, const char *sStr, int iLen); ', 'top_dbs.h', 'int', null, 4, '��ָ�������ϰ��ַ���', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsClose', 'int dbsClose(void); ', 'top_dbs.h', 'int', null, 0, '�ر��α꣬�ѷ���', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsCloseA', 'int dbsCloseA(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, '�ر��α꣬���׺ΪAϵ�к������ʹ��', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsCloseV', 'int dbsCloseV(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, '�ر��α꣬���׺ΪVϵ�к������ʹ��', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnBuffer', 'int dbsColumnBuffer(void); ', 'top_dbs.h', 'int', null, 0, '���������һ���ڴ������ѷ���', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnBufferX', 'int dbsColumnBufferX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, 'Ϊ�������һ���ڴ�����Ų�ѯ���', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnChar', 'int dbsColumnChar(int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, '�ѷ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnCharX', 'int dbsColumnCharX(T_TOP_DBS_STMT hStmt, int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnChars', 'int dbsColumnChars(char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 2, '�ѷ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnCharsX', 'int dbsColumnCharsX(T_TOP_DBS_STMT hStmt, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnCount', 'int dbsColumnCount(void); ', 'top_dbs.h', 'int', null, 0, '��ȡ������еĸ������ѷ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnCountX', 'int dbsColumnCountX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, '��ȡ��ѯ���������', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnLength', 'int dbsColumnLength(int iCol); ', 'top_dbs.h', 'int', null, 1, '��ȡ�����ָ���е�ֵ�ĳ��ȣ��ѷ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnLengthX', 'int dbsColumnLengthX(T_TOP_DBS_STMT hStmt, int iCol); ', 'top_dbs.h', 'int', null, 2, '��ȡ�����ָ���е�ֵ�ĳ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnName', 'char *dbsColumnName(int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 2, '��ȡ�������ѷ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnNameX', 'char *dbsColumnNameX(T_TOP_DBS_STMT hStmt, int iCol, char *sName); ', 'top_dbs.h', 'char*', null, 3, '��ȡ����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnString', 'int dbsColumnString(int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, '�ѷ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnStringX', 'int dbsColumnStringX(T_TOP_DBS_STMT hStmt, int iCol, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 4, '��������еĻ�����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnStrings', 'int dbsColumnStrings(char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 2, '�ѷ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnStringsX', 'int dbsColumnStringsX(T_TOP_DBS_STMT hStmt, char *sBuf, int iSize); ', 'top_dbs.h', 'int', null, 3, '������������еĻ�����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsCommit', 'int dbsCommit(void); ', 'top_dbs.h', 'int', null, 0, '�ύ����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsConnect', 'int dbsConnect(char *sConnStr); ', 'top_dbs.h', 'int', null, 1, '�������ݿ�', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsDisconnect', 'int dbsDisconnect(void); ', 'top_dbs.h', 'int', null, 0, '�Ͽ����ݿ�����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsErrStr', 'char *dbsErrStr(void); ', 'top_dbs.h', 'char*', null, 0, '��ȡ���ݿ������Ϣ', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecStmtX', 'int dbsExecStmtX(char *psSql, char * psBindVars[], int iBindCnt, char * psColVars[], int iColCnt); ', 'top_dbs.h', 'int', null, 5, 'ִ��һ��sql���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecute', 'int dbsExecute(const char *sSql); ', 'top_dbs.h', 'int', null, 1, 'ִ��һ��sql��䣬��֧�ֲ�ѯ����֧�ְ󶨲���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecuteA', 'int dbsExecuteA(char *sSql, int iBindCnt, char *psBind[], int iSelectCnt, char *psSelect[]); ', 'top_dbs.h', 'int', null, 5, 'ִ��һ��sql���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecuteV', 'int dbsExecuteV(char *sSql, ...); ', 'top_dbs.h', 'int', null, 2, 'ִ��һ��sql���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsFetch', 'int dbsFetch(void); ', 'top_dbs.h', 'int', null, 0, 'ȡ�α��еļ�¼���ѷ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsFetchA', 'int dbsFetchA(T_TOP_DBS_STMT hStmt, int iSelectCnt, char *psSelect[]); ', 'top_dbs.h', 'int', null, 3, 'ȡ�α��еļ�¼', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsFetchV', 'int dbsFetchV(T_TOP_DBS_STMT hStmt, ...); ', 'top_dbs.h', 'int', null, 2, 'ȡ�α��еļ�¼������ֵ����ʱʹ��', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsFetchX', 'int dbsFetchX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, 'ȡ�α��еļ�¼', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetErrInfo', 'char *dbsGetErrInfo(char *sBuf, int iBufLen); ', 'top_dbs.h', 'char*', null, 2, '��ȡ������Ϣ', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetFetchArrayX', 'int dbsGetFetchArrayX(T_TOP_DBS_STMT hStmt, char * psColVars[], int iColCnt); ', 'top_dbs.h', 'int', null, 3, 'ȡһ����¼����Ϊָ������', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetField', 'const char *dbsGetField(int iCol, int *piLen); ', 'top_dbs.h', 'const char*', null, 2, '��ȡĳ�����ֵ���ѷ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetFieldX', 'const char *dbsGetFieldX(T_TOP_DBS_STMT hStmt, int iCol, int *piLen); ', 'top_dbs.h', 'const char*', null, 3, '��ȡĳ�е�ֵ', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetInd', 'int dbsGetInd(int iCol); ', 'top_dbs.h', 'int', null, 1, '��ȡָ���е�ָʾ�����ѷ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetIndX', 'int dbsGetIndX(T_TOP_DBS_STMT hStmt, int iCol); ', 'top_dbs.h', 'int', null, 2, '��ȡָ���е�ָʾ��', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetLastSql', 'char *dbsGetLastSql(char *sBuf, int iBufLen); ', 'top_dbs.h', 'char*', null, 2, '��ȡ���ִ�е�sql���ѷ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOpen', 'int dbsOpen(void); ', 'top_dbs.h', 'int', null, 0, '���α꣬�ѷ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOpenA', 'int dbsOpenA(T_TOP_DBS_STMT *phStmt, char *sSql, int iBindCnt, char *psBind[]); ', 'top_dbs.h', 'int', null, 4, '���α�', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOpenV', 'int dbsOpenV(T_TOP_DBS_STMT *phStmt, char *sSql, ...); ', 'top_dbs.h', 'int', null, 3, '���α�', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOpenX', 'int dbsOpenX(T_TOP_DBS_STMT hStmt); ', 'top_dbs.h', 'int', null, 1, '���α꣬���׺ΪXϵ�к������ʹ��', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOperSetNumberLen', 'int dbsOperSetNumberLen(int nLen); ', 'top_dbs.h', 'int', null, 1, '����number���ͣ�תΪ�ַ����ĳ��ȣ��ѷ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOperSetNumberLenX', 'int dbsOperSetNumberLenX(T_TOP_DBS_STMT hStmt, int nLen); ', 'top_dbs.h', 'int', null, 2, '����number���ͣ�תΪ�ַ����ĳ���', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsPrepareX', 'int dbsPrepareX(const char *sSql, T_TOP_DBS_STMT *phStmt); ', 'top_dbs.h', 'int', null, 2, '׼���α�', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsRollback', 'int dbsRollback(void); ', 'top_dbs.h', 'int', null, 0, '�ع�����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsSetCfgFile', 'int dbsSetCfgFile(char *psCfgFile, char *psCfgSection); ', 'top_dbs.h', 'int', null, 2, '���������ļ���û���ر�˵��һ�㲻ʹ��', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsSqlCode', 'int dbsSqlCode(void); ', 'top_dbs.h', 'int', null, 0, '��ȡsqlcode', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsSqlcaRestore', 'int dbsSqlcaRestore(void); ', 'top_dbs.h', 'int', null, 0, '�ظ�sqlca����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsSqlcaSave', 'int dbsSqlcaSave(void); ', 'top_dbs.h', 'int', null, 0, '����sqlca����', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopmac', 'macInit', 'int macInit(char *sTable, char *sKeyIndex); ', 'topmac.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopmac', 'macFree', 'int macFree(void); ', 'topmac.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopmac', 'macGenerate', 'int macGenerate(InMsgPtr ptMessage, char *sMessage, char *sMac, int iLen); ', 'topmac.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopmac', 'macVerify', 'int macVerify (InMsgPtr ptMessage, char *sMessage, char *sMac, int iLen); ', 'topmac.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regCompile', 'T_REGEXP *regCompile(const char *sReg, int iFlags); ', 'topregex.h', 'T_REGEXP*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regFree', 'int regFree(T_REGEXP *ptRegExp); ', 'topregex.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regExec', 'int regExec(T_REGEXP *ptRegExp, const char *sStr); ', 'topregex.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSubCount', 'int regSubCount(T_REGEXP *ptRegExp); ', 'topregex.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSub', 'int regSubCount(T_REGEXP *ptRegExp); ', 'topregex.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSubString', 'char *regSubString(T_REGEXP *ptRegExp, int iIndex, const char *sStr, int *piLen); ', 'topregex.h', 'char*', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regMatch', 'int regMatch(const char *sReg, const char *sStr);', 'topregex.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regMatchI', 'int regMatchI(const char *sReg, const char *sStr);', 'topregex.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regMatchN', 'int regMatchN(const char *sReg, const char *sStr, int iSize);', 'topregex.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regMatchNI', 'int regMatchNI(const char *sReg, const char *sStr, int iSize);', 'topregex.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearch', 'char *regSearch(const char *sReg, const char *sStr, int *piLen);', 'topregex.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearchI', 'char *regSearchI(const char *sReg, const char *sStr, int *piLen);', 'topregex.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearchN', 'char *regSearchN(const char *sReg, const char *sStr, int iSize, int *piLen);', 'topregex.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearchNI', 'char *regSearchNI(const char *sReg, const char *sStr, int iSize, int *piLen);', 'topregex.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
commit;
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regErrStr', 'const char *regErrStr(void); ', 'topregex.h', 'const char*', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signInit', 'int signInit(char *sFile, char *sSection); ', 'topsign.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signFinal', 'int signFinal(void); ', 'topsign.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signGenerateAdd', 'int signGenerateAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signGenerateReset', 'int signGenerateReset(void); ', 'topsign.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signGenerate', 'int signGenerateAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signGenerateWithCert', 'int signGenerateWithCert(char *sKey, char *sSign, int iLen); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signVerifyAdd', 'int signVerifyAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signVerifyReset', 'int signVerifyReset(void); ', 'topsign.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signVerify', 'int signVerifyAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signVerifyWithCert', 'int signVerifyWithCert(char *sKey, char *sSign, int iLen, T_SIGN_CERT *ptCert); ', 'topsign.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signDecodeCert', 'int signDecodeCert(T_SIGN_CERT *ptCert); ', 'topsign.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signInit', 'int signInit(char *sFile, char *sSection); ', 'topsign.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signFinal', 'int signFinal(void); ', 'topsign.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signGenerateAdd', 'int signGenerateAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signGenerateReset', 'int signGenerateReset(void); ', 'topsign.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signGenerate', 'int signGenerateAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signGenerateWithCert', 'int signGenerateWithCert(char *sKey, char *sSign, int iLen); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signVerifyAdd', 'int signVerifyAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signVerifyReset', 'int signVerifyReset(void); ', 'topsign.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signVerify', 'int signVerifyAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signVerifyWithCert', 'int signVerifyWithCert(char *sKey, char *sSign, int iLen, T_SIGN_CERT *ptCert); ', 'topsign.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signUploadCert', 'int signUploadCert(char *sKey, char *sCert); ', 'topsign.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signDeleteCert', 'int signDeleteCert(char *sKey); ', 'topsign.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signInit', 'int signInit(char *sFile, char *sSection); ', 'topsign.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signFinal', 'int signFinal(void); ', 'topsign.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signGenerateAdd', 'int signGenerateAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signGenerateReset', 'int signGenerateReset(void); ', 'topsign.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signGenerate', 'int signGenerateAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signGenerateWithCert', 'int signGenerateWithCert(char *sKey, char *sSign, int iLen); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signVerifyAdd', 'int signVerifyAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signVerifyReset', 'int signVerifyReset(void); ', 'topsign.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signVerify', 'int signVerifyAdd(char *sElement, int iLen, int iType); ', 'topsign.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signVerifyWithCert', 'int signVerifyWithCert(char *sKey, char *sSign, int iLen, T_SIGN_CERT *ptCert); ', 'topsign.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signDecodeCert', 'int signDecodeCert(T_SIGN_CERT *ptCert); ', 'topsign.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signUploadCert', 'int signUploadCert(char *sKey, char *sCert); ', 'topsign.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signDeleteCert', 'int signDeleteCert(char *sKey); ', 'topsign.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'desEncrypt3DES', 'int desEncrypt3DES(unsigned char *sInBuf, size_t nInBufLen, unsigned char *sOutBuf, size_t *pnOutBufLen, unsigned char sKey[24]); ', 'util_des.h', 'int', null, 5, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'desDecrypt3DES', 'int desDecrypt3DES(unsigned char *sInBuf, size_t nInBufLen, unsigned char *sOutBuf, size_t *pnOutBufLen, unsigned char sKey[24]); ', 'util_des.h', 'int', null, 5, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmDate2Tt', 'time_t dtmDate2Tt(char sDate[9]); ', 'util_dtm.h', 'time_t', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmTime2Tt', 'time_t dtmTime2Tt(char sTime[15]); ', 'util_dtm.h', 'time_t', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmTt2Date', 'char *dtmTt2Date(time_t ttTime, char sDate[9]); ', 'util_dtm.h', 'char*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmTt2Time', 'char *dtmTt2Time(time_t ttTime, char sTime[15]); ', 'util_dtm.h', 'char*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmGetCurDate', 'char *dtmGetCurDate(char sDate[9]); ', 'util_dtm.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmGetCurTime', 'char *dtmGetCurTime(char sTime[15]); ', 'util_dtm.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmAddDays', 'char *dtmAddDays(char sDate[9], int nDayCnt); ', 'util_dtm.h', 'char*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmAddSeconds', 'char *dtmAddSeconds(char sTime[15], int nSecondCnt); ', 'util_dtm.h', 'char*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmDaysBetween', 'int dtmDaysBetween(char sDate1[9], char sDate2[9]); ', 'util_dtm.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmSecondsBetween', 'int dtmSecondsBetween(char sTime1[15], char sTime2[15]); ', 'util_dtm.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmFmtTime', 'char *dtmFmtTime(char *sBuf, size_t nBufLen, char *sFmt, time_t ttTime); ', 'util_dtm.h', 'char*', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmGetCurFmtTime', 'char *dtmGetCurFmtTime(char *sBuf, size_t nBufLen, char *sFmt); ', 'util_dtm.h', 'char*', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmStdTime', 'char *dtmStdTime(char *sBuf); ', 'util_dtm.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmBeginTimer', 'int dtmBeginTimer(struct timeval *ptvBegin); ', 'util_dtm.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmEndTimer', 'int dtmEndTimer(struct timeval *ptvBegin); ', 'util_dtm.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmBeginTimer2', 'int dtmBeginTimer2(T_TIMER *ptTimer); ', 'util_dtm.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmEndTimer2', 'int dtmEndTimer2(T_TIMER *ptTimer); ', 'util_dtm.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encEncodeBase64', 'int encEncodeBase64(unsigned char *sInBuf, size_t nInBufLen, unsigned char *sOutBuf, size_t *pnOutBufLen); ', 'util_enc.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encDecodeBase64', 'int encDecodeBase64(unsigned char *sInBuf, size_t nInBufLen, unsigned char *sOutBuf, size_t *pnOutBufLen); ', 'util_enc.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encEncodeHexZero', 'int encEncodeHexZero(unsigned char *sInBuf, size_t nInBufLen, unsigned char *sOutBuf, size_t *pnOutBufLen); ', 'util_enc.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encDecodeHexZero', 'int encDecodeHexZero(unsigned char *sInBuf, size_t nInBufLen, unsigned char *sOutBuf, size_t *pnOutBufLen); ', 'util_enc.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encEncodeHex16', 'int encEncodeHex16(unsigned char *sInBuf, size_t nInBufLen, unsigned char *sOutBuf, size_t *pnOutBufLen); ', 'util_enc.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encDecodeHex16', 'int encDecodeHex16(unsigned char *sInBuf, size_t nInBufLen, unsigned char *sOutBuf, size_t *pnOutBufLen); ', 'util_enc.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'filRead', 'int filRead(char *sFile, char *sBuf, int *piLen); ', 'util_fil.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'filWrite', 'int filWrite(char *sBuf, int iLen, char *sFile); ', 'util_fil.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'filDateDir', 'char *filDateDir(char *sPath); ', 'util_fil.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'filDateDir2', 'char *filDateDir2(char *sPath); ', 'util_fil.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'filGetSeqNext', 'int filGetSeqNext(char *sFileName, int iMax); ', 'util_fil.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashNew', 'T_HASH_TABLE *hashNew(int iSize); ', 'util_hash.h', 'T_HASH_TABLE*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashAdd', 'int hashAdd(T_HASH_TABLE *ptHashTable, const char *sKey, void *pValue); ', 'util_hash.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashSet', 'int hashSet(T_HASH_TABLE *ptHashTable, const char *sKey, void *pValue); ', 'util_hash.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashGet', 'void *hashGet(T_HASH_TABLE *ptHashTable, const char *sKey); ', 'util_hash.h', 'void*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashDel', 'void *hashDel(T_HASH_TABLE *ptHashTable, const char *sKey); ', 'util_hash.h', 'void*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashFree', 'int hashFree(T_HASH_TABLE *ptHashTable); ', 'util_hash.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashCount', 'int hashCount(T_HASH_TABLE *ptHashTable); ', 'util_hash.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashIter', 'const char *hashIter(T_HASH_TABLE *ptHashTable); ', 'util_hash.h', 'const char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashRewind', 'int hashRewind(T_HASH_TABLE *ptHashTable); ', 'util_hash.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashSort', 'int hashSort(T_HASH_TABLE *ptHashTable, int (*fCompare)(void *, void *)); ', 'util_hash.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadString', 'int iniReadString(char *sSection, char *sKey, char *sDefault, char *sOutBuf, size_t nInBufLen, char *sFile); ', 'util_ini.h', 'int', null, 6, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadInt', 'int iniReadInt(char *sSection, char *sKey, int nDefault, char *sFile); ', 'util_ini.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadString2', 'int iniReadString2(char *sSection, char *sKey, char *sDefault, char *sOutBuf, size_t iInBufLen, char *sFile); ', 'util_ini.h', 'int', null, 6, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadInt2', 'int iniReadInt2(char *sSection, char *sKey, int iDefault, char *sFile); ', 'util_ini.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniWriteString', 'int iniWriteString(char *sSection, char *sKey, char *sInBuf, char *sFile); ', 'util_ini.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strRightTrim', 'char *strRightTrim(char *sStr); ', 'util_str.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strLeftTrim', 'char *strLeftTrim(char *sStr); ', 'util_str.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strTrim', 'char *strTrim(char *sStr); ', 'util_str.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strInt2Str', 'char *strInt2Str(int nNum, char *sBuf, size_t nBufLen); ', 'util_str.h', 'char*', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2Int', 'int strStr2Int(char *sBuf, size_t nBufLen); ', 'util_str.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strLong2Str', 'char *strLong2Str(long nNum, char *sBuf, size_t nBufLen); ', 'util_str.h', 'char*', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2Long', 'long strStr2Long(char *sBuf, size_t nBufLen); ', 'util_str.h', 'long', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strLL2Str', 'char *strLL2Str(long long nNum, char *sBuf, size_t nBufLen); ', 'util_str.h', 'char*', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2LL', 'long long strStr2LL(char *sBuf, size_t nBufLen); ', 'util_str.h', 'long long', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strDbl2Str', 'char *strDbl2Str(double dNum, char *sBuf, size_t nBufLen, int nDot); ', 'util_str.h', 'char*', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2Dbl', 'double strStr2Dbl(char *sBuf, size_t nBufLen, int nDot); ', 'util_str.h', 'double', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strDbl2StrRaw', 'char *strDbl2StrRaw(double dNum, char *sBuf, size_t nBufLen, int nDot); ', 'util_str.h', 'char*', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2DblRaw', 'double strStr2DblRaw(char *sBuf, size_t nBufLen, int nDot); ', 'util_str.h', 'double', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strMem2Str', 'char *strMem2Str(char *sDest, int iDestSize, char *sSrc, int iSrcLen); ', 'util_str.h', 'char*', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strToLower', 'char *strToLower(char *sStr); ', 'util_str.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strToUpper', 'char *strToUpper(char *sStr); ', 'util_str.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strFirstUpper', 'char *strFirstUpper(char *sStr); ', 'util_str.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStrChr', 'char *strStrChr(char *sBuf, int (*pIsMatch)(char), int (*pIsEnd)(char)); ', 'util_str.h', 'char*', null, 2, null, null, null, null, null, null, null, null);
commit;
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strDirName', 'char *strDirName(char *sPath); ', 'util_str.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strBaseName', 'char *strBaseName(char *sPath); ', 'util_str.h', 'char*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strPathJoin', 'char *strPathJoin(char *sPrefix, char *sPath); ', 'util_str.h', 'char*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strPathJoin2', 'char *strPathJoin2(char *sPath, char *sAppend); ', 'util_str.h', 'char*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strReplaceDir', 'char *strReplaceDir(char *sPath, char *sDir); ', 'util_str.h', 'char*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strErrno', 'char *strErrno(void); ', 'util_str.h', 'char*', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dllOpen', 'H_DllFile dllOpen(char *_sDllFile); ', 'os_dll.h', 'H_DllFile', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dllGetFun', 'void* dllGetFun(H_DllFile _hDll, char *_sFunName); ', 'os_dll.h', 'void*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dllClose', 'void dllClose(H_DllFile _hDll); ', 'os_dll.h', 'void', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dllErrStr', 'char* dllErrStr(); ', 'os_dll.h', 'char*', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileRead', 'int lockFileRead(int fd, off_t iOffset, int iWhence, off_t iLen); ', 'os_lock.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileReadW', 'int lockFileReadW(int fd, off_t iOffset, int iWhence, off_t iLen); ', 'os_lock.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileWrite', 'int lockFileWrite(int fd, off_t iOffset, int iWhence, off_t iLen); ', 'os_lock.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileWriteW', 'int lockFileWriteW(int fd, off_t iOffset, int iWhence, off_t iLen); ', 'os_lock.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileUnLock', 'int lockFileUnLock(int fd, off_t iOffset, int iWhence, off_t iLen); ', 'os_lock.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procParseAgrs', 'int procParseAgrs(char *psLine, char *psArgv[]); ', 'os_process.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procStartProcess', 'int procStartProcess(char *psProcName, char *psBin, char *psArgs); ', 'os_process.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procStartProcessE', 'int procStartProcessE(char *psProcName, char *psBin, char *psArgs, int iOption); ', 'os_process.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procSndSig2Proc', 'int procSndSig2Proc(int iPid, int iSig); ', 'os_process.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procIsExist', 'int procIsExist(int iPid); ', 'os_process.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procRunAsDaemon', 'int procRunAsDaemon(char *psRoot, int iMask, int iOptions); ', 'os_process.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'fsGetFileSize', 'long fsGetFileSize(char *psFileName); ', 'os_fs.h', 'long', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'fsGetNewFile', 'char *fsGetNewFile(char *sPrefix, char *sFile); ', 'os_fs.h', 'char*', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'semCreate', 'int semCreate(int iKey, int iOption); ', 'os_sem.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'semP', 'int semP(int iSemId); ', 'os_sem.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'semV', 'int semV(int iSemId); ', 'os_sem.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'semDelete', 'int semDelete(int iSemId); ', 'os_sem.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'shmOpen', 'int shmOpen(int iKey, int iSize, int iFlg, T_SHM_HANDLE *ptShmHdl); ', 'os_shm.h', 'int', null, 4, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'shmMap', 'void * shmMap(T_SHM_HANDLE *ptShmHdl); ', 'os_shm.h', 'void*', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'shmUnMap', 'int shmUnMap(void *pAddr); ', 'os_shm.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'shmRemove', 'int shmRemove(T_SHM_HANDLE *ptShmHdl); ', 'os_shm.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockGetPeerAddr', 'int sockGetPeerAddr(int iSockNo, char *psAddr, int *piPort); ', 'os_socket.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockGetLocalAddr', 'int sockGetLocalAddr(int iSockNo, char *psAddr, int *piPort); ', 'os_socket.h', 'int', null, 3, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockCanRead', 'int sockCanRead(int iSockNo); ', 'os_socket.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockIsPeerClosed', 'int sockIsPeerClosed(int iSockNo); ', 'os_socket.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockSetRTimeOut', 'int sockSetRTimeOut(int iSockNo, int iSeconds); ', 'os_socket.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockSetSTimeOut', 'int sockSetSTimeOut(int iSockNo, int iSeconds); ', 'os_socket.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockSetAddrReuse', 'int sockSetAddrReuse(int iSockNo); ', 'os_socket.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockSetKeepAlive', 'int sockSetKeepAlive(int iSockNo); ', 'os_socket.h', 'int', null, 1, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockGetHostIp', 'int sockGetHostIp(char *psHostName, char *psIpAddr); ', 'os_socket.h', 'int', null, 2, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'streamWriteNByte', 'int streamWriteNByte(void *pBuf, int iLen, int iFileNo); ', 'os_stream.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'streamReadNByte', 'int streamReadNByte(void *pBuf, int iLen, int *piReadLen, int iFileNo); ', 'os_stream.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'streamWriteLine', 'int streamWriteLine(void *pBuf, int iLen, int iFileNo); ', 'os_stream.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'streamReadLine', 'int streamReadLine(void *pBuf, int iLen, int *piReadLen, int iFileNo); ', 'os_stream.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'streamWriteNbit', 'int streamWriteNbit(void *pBuf, int iBitCnt, int iFileNo); ', 'os_stream.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgInit', ' struct LogAllCfg * logCfgInit(char *psFile, char *psName); ', 'log_info.h', 'structLogAllCfg*', 'LogAllCfg Info', 2, 'Init log config', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logInit', ' int logInit(char *psFile, char *psName); ', 'log_info.h', 'int', null, 2, 'log cfg init, save cfg into global', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logEnd', ' int logEnd(); ', 'log_info.h', 'int', null, 0, 'Free All Log Info', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgEnd', ' int logCfgEnd(struct LogAllCfg *ptLogAllCfg); ', 'log_info.h', 'int', null, 1, 'Free logAll Cfg', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logInfo', ' int logInfo(char *psLogFile, int nLevel, char *psLevelStr, char *psFile, int nLine, const char *psFunction, char *psLogStr, ...) __LOGINFO_GNUC_EXT__; ', 'log_info.h', 'int', null, 8, 'printf log info,use global log info', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logVInfo', ' int logVInfo(char *psLogFile, int nLevel, char *psLevelStr, char *psFile, int nLine, const char *psFunction, char *psLogStr, va_list ap); ', 'log_info.h', 'int', null, 8, 'log printf Message', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgInfo', ' int logCfgInfo(struct LogAllCfg *ptLogAllCfg, int nLevel, char *psFile, int nLine, const char *psFunction, char *psLogStr, ...) __LOGINFO_GNUC_EXT2__; ', 'log_info.h', 'int', null, 7, 'Printf Log Message In Format By LogAllCfg', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logSession', ' int logSession(char *psKey); ', 'log_info.h', 'int', null, 1, 'log Sesion Function by Default', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgSession', ' int logCfgSession(struct LogAllCfg *ptLogAllCfg, char *psKey); ', 'log_info.h', 'int', null, 2, 'log Sesion Function by LogAllCfg', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logSessionStart', ' int logSessionStart(char *psKey); ', 'log_info.h', 'int', null, 1, 'Do session Start by Default', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgSessionStart', ' int logCfgSessionStart(struct LogAllCfg *ptLogAllCfg, char *psKey); ', 'log_info.h', 'int', null, 2, 'Do session Start by LogAllCfg', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logSessionEnd', ' int logSessionEnd(char *psKey); ', 'log_info.h', 'int', null, 1, 'Session End Funciton by Default Way', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgSessionEnd', ' int logCfgSessionEnd(struct LogAllCfg *ptLogAllCfg, char *psKey); ', 'log_info.h', 'int', null, 2, 'Session End Funciton by LogAllCfg', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logDebugString', ' int logDebugString(char *psLogFile, int nFormat, char *psFile, int nLine, const char *psFunction, char *psStr, char *psStrName, int nStrLen); ', 'log_info.h', 'int', null, 8, 'Printf String Buffer In Hex Mode by default way', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgDebugString', ' int logCfgDebugString(struct LogAllCfg *ptLogAllCfg, char *psFile, int nLine, const char *psFunction, char *psStr, char *psStrName, int nStrLen); ', 'log_info.h', 'int', null, 7, 'Printf String Buffer In Hex Mode by LogAllCfg', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logSetFile', ' int logSetFile(char *psLogFileName); ', 'log_info.h', 'int', null, 1, 'Set Log File Name,Old InterFace, Not Use Again', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logSetMode', ' int logSetMode(int *pnMode); ', 'log_info.h', 'int', null, 1, 'Set Log Show Level,Old Inter Face, Not Use Again', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'SetMaxFileSize', ' int SetMaxFileSize(int nMaxSize); ', 'log_info.h', 'int', null, 1, 'Set File max Size,Old INterface, not used again', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logGetSeesionId', ' int logGetSeesionId(char *psVaule, int nLen); ', 'log_info.h', 'int', null, 2, 'Get Session Key,Old Interface, not use again', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logGetLogFile', ' int logGetLogFile(char *psVaule, int nLen); ', 'log_info.h', 'int', null, 2, 'Get Log File Name,Old Inter Face, Not Use Again', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logSetConfig', ' int logSetConfig(char *psLogFileName, long nLogFileSize, int nLogMode); ', 'log_info.h', 'int', null, 3, 'Set Log File Name/max file len/show level,Old Interface Not Use', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logInitAppender', ' int logInitAppender(LogAppenderPoint ptAppender, FncAppenderPrintf fAppenderPrintf, FncAppenderSessionStart fAppenderSessionStart, FncAppenderSessionEnd fAppenderSessionEnd, FncAppenderFree fAppenderFree, void *ptOtherArgs); ', 'log_plug.h', 'int', null, 0, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logIniDefRead', ' int logIniDefRead(char *psGroup, char *psPkg, char *psKey, char *psDefault, char *psOutBuf, int nOutLen, char *psFile); ', 'log_plug.h', 'int', null, 7, null, null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'diskUseRate', ' int diskUseRate(char *psFilePath); ', 'os_disk.h', 'int', null, 1, 'get disk Use Rate', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'memUseRate', ' int memUseRate(void); ', 'os_memory.h', 'int', null, 0, 'Get Memory Use Rate', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'cpuUseRate', ' int cpuUseRate(void); ', 'os_cpu.h', 'int', null, 0, 'Get Cpu Use Rate', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'netStat', ' int netStat(char *psIp, int nPort, T_NET_TCP_STAT *ptTcpStat); ', 'os_net.h', 'int', null, 3, 'Get Net Stat for givinng ip & port', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'prcGetProcNum', ' int prcGetProcNum(char *psProcName); ', 'os_proc.h', 'int', null, 1, 'Get Proc Num of Process Name', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'prcGetProcName', ' int prcGetProcName(int nPid, char *psProcName, int nNameLen); ', 'os_proc.h', 'int', null, 3, 'Get Process Name By Process Id', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_ibm', 'ipcMsgQIbmMqGet', 'int ipcMsgQIbmMqGet(void *pBuf, int *piBufLen, T_IPC_MSGQ_MD *ptIpcMqMD); ', 'ipc_msgque_ibm.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 0, 'ȡ��Ϣ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_sysv', 'ipcMsgQSysVMqCreateCtx', 'int ipcMsgQSysVMqCreateCtx(T_IPC_MSGQ_CTX *_ptMsgQCtx); ', 'ipc_msgque_sysv.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 1, '��������', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_sysv', 'ipcMsgQSysVMqGet', 'int ipcMsgQSysVMqGet(void *pBuf, int *piBufLen, T_IPC_MSGQ_MD *ptIpcMqMD); ', 'ipc_msgque_sysv.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 0, '������Ϣ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_topmq', 'ipcMsgQTopMqCreateCtx', 'int ipcMsgQTopMqCreateCtx(T_IPC_MSGQ_CTX *_ptMsgQCtx); ', 'ipc_msgque_topmq.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 1, '��������', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_topmq', 'ipcMsgQTopMqGet', 'int ipcMsgQTopMqGet(void *pBuf, int *piBufLen, T_IPC_MSGQ_MD *ptIpcMqMD); ', 'ipc_msgque_topmq.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 0, '������Ϣ', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQCreateCtx', 'int ipcMsgQCreateCtx(T_IPC_MSGQ_CTX *_ptMsgQCtx); ', 'ipc_msgqueue.h', 'int', '�ɹ�0��ʧ��<0 ����ֵ����鿴ipc_queue.h�еĶ���', 1, '������Ϣ����ͨѶ�ӿڻ���', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfault_ipc_hook', 'hookMsgQGet', 'int hookMsgQGet(void *pBuf, int *piBufLen, T_IPC_MSGQ_MD *ptIpcMqMD); ', 'fault_ipc_hook.h', 'int', '�ɹ� 0�� ʧ�� < 0', 0, '���յ���Ϣ���������ڱ��ݱ���', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSendMsgX', 'int BIZ_HelperSendMsgX(char *psBuf, char *psLen, char *psAcc, char *psCond, char *psDest, char *psMsgType); ', 'biz_helper.h', 'int', '�ɹ� 0�� ʧ�� < 0', 6, '��Ϣ������չ��֧��ָ��Ŀ��', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSetValue3', 'int BIZ_HelperSetValue3(char *psBuf, char *psNeedle, char *psPos, char *psLen, char *psTag); ', 'biz_helper.h', 'int', '�ɹ� 0�� ʧ�� < 0', 5, '���̸�����������buf������tag��ȡָ������ֵ�����õ�ָ��tag', 'biz', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperCvtUnload', 'int BIZ_HelperCvtUnload(char *psArgs); ', 'biz_helper.h', 'int', '�ɹ� 0�� ʧ�� < 0', 1, '�ͷŸ�ʽת������Դ', '�ɹ� 0�� ʧ�� < 0', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_ReleaseCtx', 'int DLM_ReleaseCtx(T_DLM_CTX_HANDLE hCtx, int iOptions); ', 'dllmgr_itf.h', 'int', '�ɹ� 0�� ʧ�� < 0', 2, '�ͷŻ���', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_DelFun', 'int DLM_DelFun(T_DLM_CTX_HANDLE hCtx, char *psNameSpace, char *psFunName, int iOptions); ', 'dllmgr_itf.h', 'int', '�ɹ� 0�� ʧ�� < 0', 4, 'ɾ������', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_flowprocessor', 'FP_ReleaseCtx', 'int FP_ReleaseCtx(int iOptions); ', 'flowprocessor.h', 'int', '�ɹ� 0�� ʧ�� < 0', 1, '�ͷ����̻���', 'fw', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent_cli', 'mqConnect', 'int mqConnect(char * psQMRName, int *piReason); ', 'mq_agent.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 2, '����mq', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent_cli', 'mqConfirm', 'int mqConfirm(int iCfmFlg, int *piReason); ', 'mq_agent.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 2, 'ȷ����Ϣ', null, null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent', 'mqConnect', 'int mqConnect(char * psQMRName, int *piReason); ', 'mq_agent.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 2, '����mq', 'base', null, null, null, null, null, null);
insert into TF_FUN (MOD_NAME, FUN_NAME, DECLARATION, HEAD_FILE, RET_TYPE, RET_REMARKS, PARAM_NUM, REMARKS, USAGE, SAMPLE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent', 'mqConfirm', 'int mqConfirm(int iCfmFlg, int *piReason); ', 'mq_agent.h', 'int', '�ɹ���0 ʧ�ܣ�<0', 2, 'ȷ����Ϣ', 'base', null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ArrayGetValue', 'iPos', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ArraySetValue', 'ptVar', 'T_POC_VALUE*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ArraySetValue', 'psTag', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ArraySetValue', 'iPos', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ArrayCount', 'psTag', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ObjectCtl', 'psTag', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ObjectCtl', 'iOptions', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ObjectCtl', 'psValues', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_ibm', 'ipcMsgQIbmMqCreateCtx', '_ptMsgQCtx', 'T_IPC_MSGQ_CTX*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_ibm', 'ipcMsgQIbmMqInit', 'iSvrid', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_ibm', 'ipcMsgQIbmMqCfm', 'iFlg', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_ibm', 'ipcMsgQIbmMqCfm', 'iOption', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_sysv', 'ipcMsgQSysVMqCreateCtx', '_ptMsgQCtx', 'T_IPC_MSGQ_CTX*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_sysv', 'ipcMsgQSysVMqInit', 'iSvrid', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_sysv', 'ipcMsgQSysVMqCfm', 'iFlg', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_sysv', 'ipcMsgQSysVMqCfm', 'iOption', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_topmq', 'ipcMsgQTopMqCreateCtx', '_ptMsgQCtx', 'T_IPC_MSGQ_CTX*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_topmq', 'ipcMsgQTopMqInit', 'iSvrid', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_topmq', 'ipcMsgQTopMqCfm', 'iFlg', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_topmq', 'ipcMsgQTopMqCfm', 'iOption', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQCreateCtx', '_ptMsgQCtx', 'T_IPC_MSGQ_CTX*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQAddItf', 'iMsgQType', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQAddItf', '_ptMsgQItf', 'T_IPC_MSGQ_ITF*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQInit', 'iSvrid', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQCfm', 'iFlg', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQCfm', 'iOption', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQAddHookItf', '_ptMsgQItf', 'T_IPC_MSGQ_ITF*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', 'ipcMsgQAddHookItf', 'iOption', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent_cli', 'mqInitialize', 'ptMQAgentCfg', 'T_MQ_AGENT_CFG* ', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent_cli', 'mqConnect', 'piReason', 'int*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent_cli', 'mqConnect', 'psQMRName', 'char* ', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent_cli', 'mqConfirm', 'piReason', 'int*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent_cli', 'mqConfirm', 'iCfmFlg', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent_cli', 'mqGetMQMDSet', 'pMqMdSet', 'T_MQ_MD_SET*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent', 'mqInitialize', 'ptMQAgentCfg', 'T_MQ_AGENT_CFG* ', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent', 'mqConnect', 'piReason', 'int*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent', 'mqConnect', 'psQMRName', 'char* ', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent', 'mqConfirm', 'piReason', 'int*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent', 'mqConfirm', 'iCfmFlg', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent', 'mqGetMQMDSet', 'pMqMdSet', 'T_MQ_MD_SET*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_sms_modem', 'smsSend', 'sBody', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_sms_modem', 'smsSend', 'sDest', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_sms_modem', 'smsSend', 'sTty', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpSend', 'iPort', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpSend', 'sCharset', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpSend', 'sSubject', 'char*', 6, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpSend', 'sUser', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpSend', 'sBody', 'char*', 7, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpSend', 'sPass', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpSend', 'sTo', 'char*', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpSend', 'sHostName', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpMailNew', 'iPort', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpMailNew', 'sCharset', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpMailNew', 'sUser', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpMailNew', 'sPass', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpMailNew', 'sHostName', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpMailFree', 'ptMail', 'T_MAIL_SEND*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpMailSend', 'iBodyLen', 'int', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpMailSend', 'ptMail', 'T_MAIL_SEND*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpMailSend', 'sSubject', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpMailSend', 'sBody', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpMailSend', 'sTo', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glb_toctl_server', 'toPlugLoad', 'ptPlugVar', 'T_PLUG_MGR_PLUG_VAR*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'PlugMgrRegPlug', 'eLoadMod', 'E_PLUG_MGR_LOADMOD', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'PlugMgrRegPlug', 'psCfgSection', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'PlugMgrRegPlug', 'pfnPlugFun', 'PFN_PLUG_MGR_PLUG_LOAD_FUN', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'PlugMgrLoadPlug', 'iId', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'RTCoreStart', 'argv[]', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'RTCoreStart', 'argc', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'RTCoreInit', 'ptRTCoreCtx', 'T_RTCORE_CONTEXT*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'RTCoreMain', 'ptRTCoreCtx', 'T_RTCORE_CONTEXT*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperGetStr', 'psObj', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperGetStr', 'psSection', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperGetStr', 'iLenBuf', 'int', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperGetStr', 'psKey', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperGetStr', 'psDefault', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperGetStr', 'psOutBuf', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperGetStr', 'psCfgFile', 'char*', 6, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperGetInt', 'iDefault', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperGetInt', 'psObj', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperGetInt', 'psSection', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperGetInt', 'psKey', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperGetInt', 'psCfgFile', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrInitialize', 'iOption', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrRegPlug', 'iPlugId', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrRegEventHandler', 'iEventId', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrRegEventHandler', 'iPlugId', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrRegEventHandler', 'iToEventId', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrRegEventHandler', 'pfnEventHandler', 'PFN_EVENT_MGR_EHDL', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrRegEventHandler', 'iOption', 'int', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrPostEvent', 'iEventId', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrPostEvent', 'pOutData', 'void*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrPostEvent', 'iSrcPlugId', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrPostEvent', 'iOption', 'int', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'EventMgrPostEvent', 'pInData', 'void*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperMGetStr', 'psCfgFile[]', 'char*', 6, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperMGetStr', 'psObj', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperMGetStr', 'psSection', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperMGetStr', 'iLenBuf', 'int', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperMGetStr', 'psKey', 'char*', 2, null, null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperMGetStr', 'psDefault', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', 'CfgOperMGetStr', 'psOutBuf', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_cvt', 'POC_Datasource4CvtCreateCTX', 'ptInitParams', 'T_DATASOURCE_ARG*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_cvt', 'POC_Datasource4CvtCreateCTX', 'ptDataSource', 'T_POC_DATASOURCE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_cvt', 'POC_Datasource4CvtCreateCTX', 'ptCrtCtxOpts', 'T_POC_DATASOURCE_CRTCTX_OPTS*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_cvt', 'POC_Datasource4CvtReleaseCTX', 'iOptions', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_funs', 'POC_Datasource4FunsCreateCTX', 'ptInitParams', 'T_DATASOURCE_ARG*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_funs', 'POC_Datasource4FunsCreateCTX', 'ptDataSource', 'T_POC_DATASOURCE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_funs', 'POC_Datasource4FunsCreateCTX', 'ptCrtCtxOpts', 'T_POC_DATASOURCE_CRTCTX_OPTS*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_funs', 'POC_Datasource4FunsReleaseCTX', 'iOptions', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_mem', 'POC_Datasource4MemCreateCTX', 'ptInitParams', 'T_DATASOURCE_ARG*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_mem', 'POC_Datasource4MemCreateCTX', 'ptDataSource', 'T_POC_DATASOURCE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_mem', 'POC_Datasource4MemCreateCTX', 'ptCrtCtxOpts', 'T_POC_DATASOURCE_CRTCTX_OPTS*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_mem', 'POC_Datasource4MemReleaseCTX', 'iOptions', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_static', 'POC_Datasource4StaticCreateCTX', 'ptInitParams', 'T_DATASOURCE_ARG*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_static', 'POC_Datasource4StaticCreateCTX', 'ptDataSource', 'T_POC_DATASOURCE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_static', 'POC_Datasource4StaticCreateCTX', 'ptCrtCtxOpts', 'T_POC_DATASOURCE_CRTCTX_OPTS*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_static', 'POC_Datasource4StaticReleaseCTX', 'iOptions', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRoute', 'iRouteId', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRoute', 'iSrcSvrId', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRoute', 'iDestSvrId', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRoute', 'sDestSvrFmt', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteMap', 'iRouteId', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteMap', 'sRouteKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteSvr', 'iSvrId', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteSvr', 'iRouteLocId', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteSvr', 'sOutFmt', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteSvr', 'iRouteFlag', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteSvr', 'sRouteCvtFmt', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteLoc', 'iInd', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteLoc', 'iRouteLocId', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteLoc', 'sEnd', 'char*', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteLoc', 'iLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comQueueInit', 'iSvrid', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comQueueInit', 'ptComInitOption', 'T_COM_INITOPTION*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comMsgSend', 'iBufLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comMsgSend', 'ptComMD', 'T_COM_MD*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comMsgSend', 'pBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comUMsgSend', 'iBufLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comUMsgSend', 'ptComMD', 'T_COM_MD*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comUMsgSend', 'iDestSvrId', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comUMsgSend', 'pBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comMsgRecv', 'ptComMD', 'T_COM_MD*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comMsgRecv', 'pBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comMsgRecv', 'piBufLen', 'int*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comUMsgRecv', 'ptComMD', 'T_COM_MD*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comUMsgRecv', 'pBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comUMsgRecv', 'piSrcSvrId', 'int*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comUMsgRecv', 'piBufLen', 'int*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', 'comQueueFinalize', 'iSvrid', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindArray', 'asArray[]', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindArray', 'iCnt', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindArrayX', 'asArray[]', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindArrayX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindArrayX', 'iCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindCountX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindName', 'sName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindName', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindNameX', 'sName', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindNameX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindNameX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindNull', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindNullX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindNullX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindSepValues', 'sBuf', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindSepValues', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindSepValues', 'sSep', 'char', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindSepValuesX', 'sBuf', 'const char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindSepValuesX', 'iLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindSepValuesX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindSepValuesX', 'sSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindString', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindString', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindString', 'sStr', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindStringX', 'iLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindStringX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindStringX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsBindStringX', 'sStr', 'const char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsCloseX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnBufferX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnChar', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnChar', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnChar', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnCharX', 'sBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnCharX', 'iSize', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnCharX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnCharX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnChars', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnChars', 'iSize', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnCharsX', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnCharsX', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnCharsX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnCountX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnLength', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnLengthX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnLengthX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnName', 'sName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnName', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnNameX', 'sName', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnNameX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnNameX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnString', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnString', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnString', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnStringX', 'sBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnStringX', 'iSize', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnStringX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnStringX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnStrings', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnStrings', 'iSize', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnStringsX', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnStringsX', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsColumnStringsX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsConnect', 'sConnStr', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsExecStmtX', 'psColVars[]', 'char* ', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsExecStmtX', 'iColCnt', 'int', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsExecStmtX', 'iBindCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsExecStmtX', 'psSql', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsExecStmtX', 'psBindVars[]', 'char* ', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsExecute', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsFetchX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetErrInfo', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetErrInfo', 'iBufLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetField', 'piLen', 'int*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetField', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetFieldX', 'piLen', 'int*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetFieldX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetFieldX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetInd', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetIndX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetIndX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetLastSql', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsGetLastSql', 'iBufLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsOpenX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsOperInit', 'iMaxNameLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsOperInit', 'iMaxVarNum', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsOperSetNumberLen', 'nLen', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsOperSetNumberLenX', 'nLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsOperSetNumberLenX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsPrepare', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsPrepareX', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsPrepareX', 'phStmt', 'T_TOP_DBS_STMT*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsSetCfgFile', 'psCfgSection', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'dbsSetCfgFile', 'psCfgFile', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindArray', 'asArray[]', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindArray', 'iCnt', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindArrayX', 'asArray[]', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindArrayX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindArrayX', 'iCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindCountX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindName', 'sName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindName', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindNameX', 'sName', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindNameX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindNameX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindNull', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindNullX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindNullX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindSepValues', 'sBuf', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindSepValues', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindSepValues', 'sSep', 'char', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindSepValuesX', 'sBuf', 'const char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindSepValuesX', 'iLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindSepValuesX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindSepValuesX', 'sSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindString', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindString', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindString', 'sStr', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindStringX', 'iLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindStringX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindStringX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsBindStringX', 'sStr', 'const char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsCloseX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnBufferX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnChar', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnChar', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnChar', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnCharX', 'sBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnCharX', 'iSize', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnCharX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnCharX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnChars', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnChars', 'iSize', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnCharsX', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnCharsX', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comQueueInit', 'iSvrid', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comQueueInit', 'ptComInitOption', 'T_COM_INITOPTION*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comMsgSend', 'iBufLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comMsgSend', 'ptComMD', 'T_COM_MD*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comMsgSend', 'pBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comUMsgSend', 'iBufLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comUMsgSend', 'ptComMD', 'T_COM_MD*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comUMsgSend', 'iDestSvrId', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comUMsgSend', 'pBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comMsgRecv', 'ptComMD', 'T_COM_MD*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comMsgRecv', 'pBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comMsgRecv', 'piBufLen', 'int*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comUMsgRecv', 'ptComMD', 'T_COM_MD*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comUMsgRecv', 'pBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comUMsgRecv', 'piSrcSvrId', 'int*', 2, null, null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comUMsgRecv', 'piBufLen', 'int*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', 'comQueueFinalize', 'iSvrid', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', 'cvtWrapConvert', 'sInFmt', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', 'cvtWrapConvert', 'piOutBufLen', 'int*', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', 'cvtWrapConvert', 'sOutFmt', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', 'cvtWrapConvert', 'sInBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', 'cvtWrapConvert', 'psOutBuf', 'char**', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', 'cvtWrapConvert', 'iInBufLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', 'cvtWrapOnce', 'sInFmt', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', 'cvtWrapOnce', 'piOutBufLen', 'int*', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', 'cvtWrapOnce', 'sOutBuf', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', 'cvtWrapOnce', 'sOutFmt', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', 'cvtWrapOnce', 'sInBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', 'cvtWrapOnce', 'iInBufLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindArray', 'asArray[]', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindArray', 'iCnt', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindArrayX', 'asArray[]', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindArrayX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindArrayX', 'iCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindCountX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindName', 'sName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindName', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindNameX', 'sName', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindNameX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindNameX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindNull', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindNullX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindNullX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindSepValues', 'sBuf', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindSepValues', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindSepValues', 'sSep', 'char', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindSepValuesX', 'sBuf', 'const char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindSepValuesX', 'iLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindSepValuesX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindSepValuesX', 'sSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindString', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindString', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindString', 'sStr', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindStringX', 'iLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindStringX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindStringX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsBindStringX', 'sStr', 'const char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsCloseX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnBufferX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnChar', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnChar', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnChar', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnCharX', 'sBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnCharX', 'iSize', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnCharX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnCharX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnChars', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnChars', 'iSize', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnCharsX', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnCharsX', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnCharsX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnCountX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnLength', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnLengthX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnLengthX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnName', 'sName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnName', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnNameX', 'sName', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnNameX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnNameX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnString', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnString', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnString', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnStringX', 'sBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnStringX', 'iSize', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnStringX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnStringX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnStrings', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnStrings', 'iSize', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnStringsX', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnStringsX', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsColumnStringsX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsConnect', 'sConnStr', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsExecStmtX', 'psColVars[]', 'char* ', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsExecStmtX', 'iColCnt', 'int', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsExecStmtX', 'iBindCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsExecStmtX', 'psSql', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsExecStmtX', 'psBindVars[]', 'char* ', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsExecute', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsFetchX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetErrInfo', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetErrInfo', 'iBufLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetField', 'piLen', 'int*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetField', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetFieldX', 'piLen', 'int*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetFieldX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetFieldX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetInd', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetIndX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetIndX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetLastSql', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsGetLastSql', 'iBufLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsOpenX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsOperInit', 'iMaxNameLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsOperInit', 'iMaxVarNum', 'int', 0, null, null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsOperSetNumberLen', 'nLen', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsOperSetNumberLenX', 'nLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsOperSetNumberLenX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsPrepare', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsPrepareX', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsPrepareX', 'phStmt', 'T_TOP_DBS_STMT*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsSetCfgFile', 'psCfgSection', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', 'dbsSetCfgFile', 'psCfgFile', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnCharsX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnCountX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnLength', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnLengthX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnLengthX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnName', 'sName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnName', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnNameX', 'sName', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnNameX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnNameX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnString', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnString', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnString', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnStringX', 'sBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnStringX', 'iSize', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnStringX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnStringX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnStrings', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnStrings', 'iSize', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnStringsX', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnStringsX', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsColumnStringsX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsConnect', 'sConnStr', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsExecStmtX', 'psColVars[]', 'char* ', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsExecStmtX', 'iColCnt', 'int', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsExecStmtX', 'iBindCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsExecStmtX', 'psSql', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsExecStmtX', 'psBindVars[]', 'char* ', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsExecute', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsFetchX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetErrInfo', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetErrInfo', 'iBufLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetField', 'piLen', 'int*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetField', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetFieldX', 'piLen', 'int*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetFieldX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetFieldX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetInd', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetIndX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetIndX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetLastSql', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsGetLastSql', 'iBufLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsOpenX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsOperInit', 'iMaxNameLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsOperInit', 'iMaxVarNum', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsOperSetNumberLen', 'nLen', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsOperSetNumberLenX', 'nLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsOperSetNumberLenX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsPrepare', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsPrepareX', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsPrepareX', 'phStmt', 'T_TOP_DBS_STMT*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsSetCfgFile', 'psCfgSection', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'dbsSetCfgFile', 'psCfgFile', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindArray', 'asArray[]', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindArray', 'iCnt', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindArrayX', 'asArray[]', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindArrayX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindArrayX', 'iCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindCountX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindName', 'sName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindName', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindNameX', 'sName', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindNameX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindNameX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindNull', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindNullX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindNullX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindSepValues', 'sBuf', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindSepValues', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindSepValues', 'sSep', 'char', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindSepValuesX', 'sBuf', 'const char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindSepValuesX', 'iLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindSepValuesX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindSepValuesX', 'sSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindString', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindString', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindString', 'sStr', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindStringX', 'iLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindStringX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindStringX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsBindStringX', 'sStr', 'const char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsCloseX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnBufferX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnChar', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnChar', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnChar', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnCharX', 'sBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnCharX', 'iSize', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnCharX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnCharX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnChars', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnChars', 'iSize', 'int', 1, null, null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnCharsX', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnCharsX', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnCharsX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnCountX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnLength', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnLengthX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnLengthX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnName', 'sName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnName', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnNameX', 'sName', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnNameX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnNameX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnString', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnString', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnString', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnStringX', 'sBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnStringX', 'iSize', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnStringX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnStringX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnStrings', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnStrings', 'iSize', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnStringsX', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnStringsX', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsColumnStringsX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsConnect', 'sConnStr', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsExecStmtX', 'psColVars[]', 'char* ', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsExecStmtX', 'iColCnt', 'int', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsExecStmtX', 'iBindCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsExecStmtX', 'psSql', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsExecStmtX', 'psBindVars[]', 'char* ', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsExecute', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsFetchX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetErrInfo', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetErrInfo', 'iBufLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetField', 'piLen', 'int*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetField', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetFieldX', 'piLen', 'int*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetFieldX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetFieldX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetInd', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetIndX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetIndX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetLastSql', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsGetLastSql', 'iBufLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsOpenX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsOperInit', 'iMaxNameLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsOperInit', 'iMaxVarNum', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsOperSetNumberLen', 'nLen', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsOperSetNumberLenX', 'nLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsOperSetNumberLenX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsPrepare', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsPrepareX', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsPrepareX', 'phStmt', 'T_TOP_DBS_STMT*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsSetCfgFile', 'psCfgSection', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', 'dbsSetCfgFile', 'psCfgFile', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfault_ipc_hook', 'hookMsgQCreateCtx', '_ptMsgQCtx', 'T_IPC_MSGQ_CTX*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfault_ipc_hook', 'hookMsgQInit', 'iSvrid', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfault_ipc_hook', 'hookMsgQCfm', 'iFlg', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfault_ipc_hook', 'hookMsgQCfm', 'iOption', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfunction_plug_ctl', 'plugAddInterface', 'nVersion', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfunction_plug_ctl', 'plugAddInterface', 'fpSetDefault', 'fncSetDefault', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfunction_plug_ctl', 'plugAddInterface', 'psName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfunction_plug_ctl', 'plugInitInterface', 'psFile', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfunction_plug_ctl', 'plugInitInterface', 'psSecation', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperTransaction', 'psCond', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSendMsg', 'psLen', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSendMsg', 'psBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSendMsg', 'psAcc', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSendMsg', 'psCond', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSendMsgX', 'psLen', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSendMsgX', 'psDest', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSendMsgX', 'psMsgType', 'char*', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSendMsgX', 'psBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSendMsgX', 'psAcc', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSendMsgX', 'psCond', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSetValue', 'psLen', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSetValue', 'psTag', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSetValue', 'psValue', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSetValue2', 'psLen', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSetValue2', 'psTag', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSetValue2', 'psBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSetValue2', 'psPos', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSetValue3', 'psLen', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSetValue3', 'psNeedle', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSetValue3', 'psTag', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSetValue3', 'psBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperSetValue3', 'psPos', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperCvtGenOutMsg', 'psTag', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperCvtGenOutMsg', 'psArgs', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperCvtInit', 'psTag', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperCvtInit', 'psArgs', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperTotaSetting', 'psInMsg', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperTotaSetting', 'psOutMsg', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperTotaSetting', 'psTag', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperTotaSetting', 'psCond', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperLoadSysPara', 'sTable', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperLocTranInit', 'psInMsg', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperCvtLoad', 'psArgs', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_HelperCvtUnload', 'psArgs', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_PocHelperInit', 'psChkTable', 'char*', 1, null, null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'BIZ_PocHelperInit', 'psSqlTable', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'locStdSetErrTable', 'sTable', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'locStdErrTrace', 'sErrCode', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'locStdErr', 'sErrCode', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'locCustSetErrTable', 'sTable', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'locCustErrTrace', 'sErrCode', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'locCustErr', 'sErrCode', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_CreateCtx', 'ptCrtCtxOpts', 'T_DLM_CRTCTX_OPTS*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_ReleaseCtx', 'hCtx', 'T_DLM_CTX_HANDLE', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_ReleaseCtx', 'iOptions', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_AddLib', 'hCtx', 'T_DLM_CTX_HANDLE', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_AddLib', 'psLibPath', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_AddLib', 'iOptions', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_AddLib', 'psLibName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_DelLib', 'hCtx', 'T_DLM_CTX_HANDLE', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_DelLib', 'iOptions', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_DelLib', 'psLibName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_GetFun', 'hCtx', 'T_DLM_CTX_HANDLE', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_GetFun', 'psFunName', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_GetFun', 'iOptions', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_GetFun', 'psNameSpace', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_AddFun', 'hCtx', 'T_DLM_CTX_HANDLE', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_AddFun', 'psFunName', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_AddFun', 'iOptions', 'int', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_AddFun', 'psLibName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_AddFun', 'psNameSpace', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_DelFun', 'hCtx', 'T_DLM_CTX_HANDLE', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_DelFun', 'psFunName', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_DelFun', 'iOptions', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_DelFun', 'psNameSpace', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_GetErrors', 'hCtx', 'T_DLM_CTX_HANDLE', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_GetErrors', 'psError', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_SetAsDefaultCtx', 'hCtx', 'T_DLM_CTX_HANDLE', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', 'DLM_SetAsDefaultCtx', 'iOptions', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_flowprocessor', 'FP_CreateCtx', 'ptCrtCtxOpts', 'T_FP_CRTCTX_OPTS*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_flowprocessor', 'FP_ReleaseCtx', 'iOptions', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_flowprocessor', 'FP_AddMod', 'iOptions', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_flowprocessor', 'FP_AddMod', 'psModFile', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_flowprocessor', 'FP_Run', 'iOptions', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_flowprocessor', 'FP_Run', 'psKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_flowprocessor', 'FP_GetErrors', 'psError', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglbmsgrpt', 'msgRpt', 'nErrno', 'int', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglbmsgrpt', 'msgRpt', 'psFileName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglbmsgrpt', 'msgRpt', 'psFunction', 'const char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglbmsgrpt', 'msgRpt', 'nLine', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglbmsgrpt', 'msgRpt', 'psBuf', 'char*', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglbmsgrpt', 'msgRpt', 'nLevel', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglbmsgrpt', 'msgRpt', '...', '...', 6, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglbmsgrpt', 'msgSetSvrId', 'pnMsgSvrId', 'int*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgrpt_svrid', 'MSG_SetSvrId', 'pnMsgSvrId', 'int*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReport', 'sType', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReportV', 'iLine', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReportV', 'sTitle', 'char*', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReportV', 'sFmt', 'char*', 6, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReportV', 'sFunc', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReportV', 'vaArgs', 'va_list', 7, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReportV', 'sType', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReportV', 'sFile', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReportV', 'iErrno', 'int', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgSend', 'ptMsg', 'T_MSGSVR_INFO*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc_helper', 'POC_Helper_Init', 'ptOpts', 'T_POC_HELPER_OPTS*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc_helper', 'POC_Helper_ExcSqlById', 'sSqlId', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc_helper', 'POC_Helper_ExcSql', 'sSqlId', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc_helper', 'POC_Helper_ExcSqlOpen', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc_helper', 'POC_Helper_CheckValue', 'sTag', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_CreateCtx', 'ptCrtCtxOpts', 'T_POC_CRTCTX_OPTS*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ReleaseCtx', 'iOptions', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_AddDataSource', 'ptDataSource', 'T_POC_DATASOURCE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_AddDataSource', 'iOptions', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_DelDataSource', 'iOptions', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_DelDataSource', 'psDataSource', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_BeginSession', 'iOptions', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_BeginSession', 'iId', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_EndSession', 'iOptions', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_EndSession', 'iId', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_RegObject', 'psType', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_RegObject', 'iOptions', 'int', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_RegObject', 'psName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_RegObject', 'iScope', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_RegObject', 'hObjHdl', 'T_POC_OBJECT_HANDLE', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_UnRegObject', 'iOptions', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_UnRegObject', 'psName', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetObjectHdl', 'phObjHdl', 'T_POC_OBJECT_HANDLE*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetObjectHdl', 'psName', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ObjectNew', 'psInitParams', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ObjectNew', 'psType', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ObjectNew', 'iOptions', 'int', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ObjectNew', 'psObjName', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ObjectNew', 'iScope', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ObjectDel', 'iOptions', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ObjectDel', 'psName', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetValueS', 'psTag', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetValueS', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetValueS', 'psVar', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetValueInt32', 'psTag', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetValueInt64', 'psTag', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetValueDouble', 'psTag', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetValue', 'psTag', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetValue', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_GetValue', 'psVar', 'char*', 1, null, null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValueS', 'psTag', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValueS', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValueS', 'psVar', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValueInt32', 'iValue', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValueInt32', 'psTag', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValueInt64', 'psTag', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValueInt64', 'lValue', 'T_POC_INT64', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValueDouble', 'psTag', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValueDouble', 'dValue', 'double', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValue', 'psTag', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValue', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_SetValue', 'psVar', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ArrayGetValue', 'ptVar', 'T_POC_VALUE*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', 'POC_ArrayGetValue', 'psTag', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReport', 'sFile', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReport', 'iLine', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReport', 'sFunc', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReport', 'iErrno', 'int', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReport', 'sTitle', 'char*', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReport', 'sFmt', 'char*', 6, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', 'msgReport', '...', '...', 7, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStrChr', 'pIsEnd', 'int (*)(char)', null, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regMatch', 'sStr', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regMatchI', 'sStr', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regMatchN', 'sStr', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regMatchN', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regMatchNI', 'sStr', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regMatchNI', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearch', 'sStr', 'const char *', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearch', 'piLen', 'int*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearchI', 'sStr', 'const char *', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearchI', 'piLen', 'int*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearchN', 'sStr', 'const char *', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearchN', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearchN', 'piLen', 'int*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearchNI', 'sStr', 'const char *', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearchNI', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearchNI', 'piLen', 'int*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logVInfo', 'nLine', 'int', 4, 'source File Line', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logVInfo', 'psLogStr', 'char*', 6, 'Log Message', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logInfo', 'psLogFile', 'char*', 0, 'If Not Null, Printf to File', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logInfo', 'psFunction', 'const char*', 5, 'source Function Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgEnd', 'ptLogAllCfg', 'struct LogAllCfg*', 0, 'Log All Cfg Info', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgInit', 'psName', 'char*', 1, 'log section Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoInit', 'sTable', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoGenerate', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoGenerate', 'sSign', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoGenerate', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoGenerateWithCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoGenerateWithCert', 'sSign', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoGenerateWithCert', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoVerify', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoVerify', 'sSign', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoVerify', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoVerifyWithCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoVerifyWithCert', 'sSign', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoVerifyWithCert', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', 'signAutoVerifyWithCert', 'ptCert', 'T_SIGN_CERT*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signInit', 'sSection', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signInit', 'sFile', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signGenerateAdd', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signGenerateAdd', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signGenerateAdd', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signGenerate', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signGenerate', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signGenerate', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signGenerateWithCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signGenerateWithCert', 'sSign', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signGenerateWithCert', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signVerifyAdd', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signVerifyAdd', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signVerifyAdd', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signVerify', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signVerify', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signVerify', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signVerifyWithCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signVerifyWithCert', 'sSign', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signVerifyWithCert', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signVerifyWithCert', 'ptCert', 'T_SIGN_CERT*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', 'signDecodeCert', 'ptCert', 'T_SIGN_CERT*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signInit', 'sSection', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signInit', 'sFile', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signGenerateAdd', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signGenerateAdd', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signGenerateAdd', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signGenerate', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signGenerate', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signGenerate', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signGenerateWithCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signGenerateWithCert', 'sSign', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signGenerateWithCert', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signVerifyAdd', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signVerifyAdd', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signVerifyAdd', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signVerify', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signVerify', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signVerify', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signVerifyWithCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signVerifyWithCert', 'sSign', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signVerifyWithCert', 'iLen', 'int', 2, null, null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signVerifyWithCert', 'ptCert', 'T_SIGN_CERT*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', 'signDecodeCert', 'ptCert', 'T_SIGN_CERT*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algBSearch', 'pBase', 'const void*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algBSearch', 'pKey', 'const void*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algBSearch', 'iSize', 'size_t', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algBSearch', 'iNum', 'size_t', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algBSearch', 'fCompar', 'F_COMPAR', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algLSearch', 'pBase', 'const void*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algLSearch', 'pKey', 'const void*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algLSearch', 'iSize', 'size_t', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algLSearch', 'iNum', 'size_t', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algLSearch', 'fCompar', 'F_COMPAR', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHCreate', 'iNum', 'size_t', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHSearch', 'tItem', 'T_ITEM', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHEnter', 'tItem', 'T_ITEM', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHCreateR', 'iNum', 'size_t', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHCreateR', 'ptHtab', 'T_HTABLE*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHSearchR', 'tItem', 'T_ITEM', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHSearchR', 'ptHtab', 'T_HTABLE*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHEnterR', 'tItem', 'T_ITEM', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHEnterR', 'ptHtab', 'T_HTABLE*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'algHDestroyR', 'ptHtab', 'T_HTABLE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvOpen', 'sFileName', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRow', 'cSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRow', 'ptCsv', 'T_CSV*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRow2', 'ptCsv', 'T_CSV*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRow2', 'sSep', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowSkip', 'cSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowSkip', 'ptCsv', 'T_CSV*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowSkip', 'cSkip', 'char', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowN', 'cSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowN', 'ptCsv', 'T_CSV*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowN', 'iCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowN2', 'ptCsv', 'T_CSV*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowN2', 'sSep', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowN2', 'iCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowSkipN', 'cSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowSkipN', 'ptCsv', 'T_CSV*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowSkipN', 'cSkip', 'char', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowSkipN', 'iCnt', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowExt', 'cSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowExt', 'ptCsv', 'T_CSV*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvReadRowExt', 'cQuote', 'char', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvClose', 'ptCsv', 'T_CSV*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStr', 'cSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStr', 'ptSplitStr', 'T_SPLIT_STR*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStr', 'sStr', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStr2', 'ptSplitStr', 'T_SPLIT_STR*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStr2', 'sSep', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStr2', 'sStr', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStrN', 'cSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStrN', 'ptSplitStr', 'T_SPLIT_STR*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStrN', 'sStr', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStrN', 'iCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStrN2', 'ptSplitStr', 'T_SPLIT_STR*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStrN2', 'sSep', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStrN2', 'sStr', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvSplitStrN2', 'iCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWrite', 'fpFile', 'FILE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWrite', 'cSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWrite', '...', '...', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWrite', 'iCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteV', 'fpFile', 'FILE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteV', 'cSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteV', 'psCol[]', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteV', 'iCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteExt', 'fpFile', 'FILE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteExt', 'cSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteExt', 'cQuote', 'char', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteExt', '...', '...', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteExt', 'iCnt', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteExtV', 'fpFile', 'FILE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteExtV', 'cSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteExtV', 'cQuote', 'char', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteExtV', 'psCol[]', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'csvWriteExtV', 'iCnt', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnNew', 'iSize', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnNew', 'fCompar', 'F_CTN_COMPAR', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnReAlloc', 'ptCtn', 'T_CTN*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnFree', 'ptCtn', 'T_CTN*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSetSorted', 'ptCtn', 'T_CTN*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSetSorted', 'iSorted', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSetCompar', 'ptCtn', 'T_CTN*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSetCompar', 'fCompar', 'F_CTN_COMPAR', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnGet', 'ptCtn', 'T_CTN*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnGet', 'iIdx', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSort', 'ptCtn', 'T_CTN*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSearchL', 'ptCtn', 'T_CTN*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSearchL', 'pKey', 'const void*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSearchL', 'pCur', 'const void*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSearchM', 'ptCtn', 'T_CTN*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSearchM', 'pKey', 'const void*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ctnSearchM', 'pCur', 'const void*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'desEncrypt3DES', 'sOutBuf', 'unsigned char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'desEncrypt3DES', 'pnOutBufLen', 'size_t*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'desEncrypt3DES', 'sKey[24]', 'unsigned char', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'desEncrypt3DES', 'sInBuf', 'unsigned char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteLoc', 'iPos', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSetRouteLoc', 'sStart', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteNext', 'iSrcSvrId', 'int', 1, null, null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteNext', 'piDestSvrId', 'int*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteNext', 'sRouteKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteNext', 'sDestSvrFmt', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSvrInfo', 'sKey', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSvrInfo', 'iKeyLen', 'int', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSvrInfo', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSvrInfo', 'iBufLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSvrInfo', 'iSvrId', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', 'rteSvrInfo', 'sOutFmt', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtcp_hdr_helper', 'tcpHelperSetCustFun', 'pfnHdr2Int', 'PFN_TCPHELPER_HDR2INT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtcp_hdr_helper', 'tcpHelperSetCustFun', 'pfnInt2Hdr', 'PFN_TCPHELPER_INT2HDR', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryWrapDecrypt', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryWrapDecrypt', 'iBufLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryWrapDecrypt', 'iMethod', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHex', 'sOutBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHex', 'sInBuf', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHex', 'iInLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryUnHex', 'sOutBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryUnHex', 'sInBuf', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64', 'sOutBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64', 'sInBuf', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64', 'iInLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryUnBase64', 'sOutBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryUnBase64', 'sInBuf', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHexEncode', 'sOutBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHexEncode', 'piOutLen', 'int*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHexEncode', 'sInBuf', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHexEncode', 'iInLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHexDecode', 'sOutBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHexDecode', 'piOutLen', 'int*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHexDecode', 'sInBuf', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHexDecode', 'iInLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64Encode', 'sOutBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64Encode', 'piOutLen', 'int*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64Encode', 'sInBuf', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64Encode', 'iInLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64Decode', 'sOutBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64Decode', 'piOutLen', 'int*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64Decode', 'sInBuf', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64Decode', 'iInLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3UtilEncrypt', 'sOutBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3UtilEncrypt', 'piOutLen', 'int*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3UtilEncrypt', 'sKey[24]', 'const char', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3UtilEncrypt', 'sInBuf', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3UtilEncrypt', 'iInLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3UtilDecrypt', 'sOutBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3UtilDecrypt', 'piOutLen', 'int*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3UtilDecrypt', 'sKey[24]', 'const char', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3UtilDecrypt', 'sInBuf', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3UtilDecrypt', 'iInLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3Encrypt', 'sKey', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3Encrypt', 'iKeyLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3Encrypt', 'sOutBuf', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3Encrypt', 'piOutLen', 'int*', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3Encrypt', 'sInBuf', 'const char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3Encrypt', 'iInLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3Decrypt', 'sKey', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3Decrypt', 'iKeyLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3Decrypt', 'sOutBuf', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3Decrypt', 'piOutLen', 'int*', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3Decrypt', 'sInBuf', 'const char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDes3Decrypt', 'iInLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesEncrypt', 'sKey', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesEncrypt', 'iKeyLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesEncrypt', 'sOutBuf', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesEncrypt', 'piOutLen', 'int*', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesEncrypt', 'sInBuf', 'const char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesEncrypt', 'iInLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesDecrypt', 'sKey', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesDecrypt', 'iKeyLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesDecrypt', 'sOutBuf', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesDecrypt', 'piOutLen', 'int*', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesDecrypt', 'sInBuf', 'const char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesDecrypt', 'iInLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryMd5', 'sOutBuf[16]', 'char', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryMd5', 'sInBuf', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryMd5', 'iInLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryMd5File', 'sOutBuf[16]', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryMd5File', 'sFile', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'crySha1', 'sInBuf', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'crySha1', 'sOutBuf[20]', 'char', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'crySha1', 'iInLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'crySha1File', 'sFile', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'crySha1File', 'sOutBuf[20]', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryHexSelfTest', 'iVerbose', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryBase64SelfTest', 'iVerbose', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryDesSelfTest', 'iVerbose', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryAesSelfTest', 'iVerbose', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryMdxSelfTest', 'iVerbose', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', 'cryShaxSelfTest', 'iVerbose', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindArray', 'asArray[]', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindArray', 'iCnt', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindArrayX', 'asArray[]', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindArrayX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindArrayX', 'iCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindCountX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindName', 'sName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindName', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindNameX', 'sName', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindNameX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindNameX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindNull', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindNullX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindNullX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindSepValues', 'sBuf', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindSepValues', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindSepValues', 'sSep', 'char', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindSepValuesX', 'sBuf', 'const char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindSepValuesX', 'iLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindSepValuesX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindSepValuesX', 'sSep', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindString', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindString', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindString', 'sStr', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindStringX', 'iLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindStringX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindStringX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsBindStringX', 'sStr', 'const char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsCloseA', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsCloseV', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsCloseX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnBufferX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnChar', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnChar', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnChar', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnCharX', 'sBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnCharX', 'iSize', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnCharX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnCharX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnChars', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnChars', 'iSize', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnCharsX', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnCharsX', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnCharsX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnCountX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnLength', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnLengthX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnLengthX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnName', 'sName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnName', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnNameX', 'sName', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnNameX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnNameX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnString', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnString', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnString', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnStringX', 'sBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnStringX', 'iSize', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnStringX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnStringX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnStrings', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnStrings', 'iSize', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnStringsX', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlOpen', 'zDbFile', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlExecute', 'zSql', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlGetTable', 'piCol', 'int*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlGetTable', 'zSql', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlGetTable', 'piRow', 'int*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlGetTable', 'pazResust', 'char***', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlFreeTable', 'azResult', 'char**', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlPrepare', 'zSql', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlStep', 'stmt', 'T_SQL_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlReset', 'stmt', 'T_SQL_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlFinalize', 'stmt', 'T_SQL_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlBindInt', 'stmt', 'T_SQL_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlBindInt', 'iValue', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlBindInt', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlBindString', 'stmt', 'T_SQL_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlBindString', 'zValue', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlBindString', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlBindDouble', 'stmt', 'T_SQL_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlBindDouble', 'dValue', 'double', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlBindDouble', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlBindNull', 'stmt', 'T_SQL_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlBindNull', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlColumnInt', 'stmt', 'T_SQL_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlColumnInt', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlColumnString', 'stmt', 'T_SQL_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlColumnString', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlColumnDouble', 'stmt', 'T_SQL_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', 'sqlColumnDouble', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnStringsX', 'iSize', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsColumnStringsX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsConnect', 'sConnStr', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecStmtX', 'psColVars[]', 'char* ', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecStmtX', 'iColCnt', 'int', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecStmtX', 'iBindCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecStmtX', 'psSql', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecStmtX', 'psBindVars[]', 'char* ', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecute', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecuteA', 'iSelectCnt', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecuteA', 'sSql', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecuteA', 'iBindCnt', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecuteA', 'psBind[]', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecuteA', 'psSelect[]', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecuteV', 'sSql', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsExecuteV', '...', '...', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsFetchA', 'iSelectCnt', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsFetchA', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsFetchA', 'psSelect[]', 'char*', 2, null, null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsFetchV', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsFetchV', '...', '...', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsFetchX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetErrInfo', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetErrInfo', 'iBufLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetFetchArrayX', 'psColVars[]', 'char* ', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetFetchArrayX', 'iColCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetFetchArrayX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetField', 'piLen', 'int*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetField', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetFieldX', 'piLen', 'int*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetFieldX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetFieldX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetInd', 'iCol', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetIndX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetIndX', 'iCol', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetLastSql', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsGetLastSql', 'iBufLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOpenA', 'sSql', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOpenA', 'phStmt', 'T_TOP_DBS_STMT*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOpenA', 'iBindCnt', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOpenA', 'psBind[]', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOpenV', 'sSql', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOpenV', 'phStmt', 'T_TOP_DBS_STMT*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOpenV', '...', '...', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOpenX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOperInit', 'iMaxNameLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOperInit', 'iMaxVarNum', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOperSetNumberLen', 'nLen', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOperSetNumberLenX', 'nLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsOperSetNumberLenX', 'hStmt', 'T_TOP_DBS_STMT', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsPrepare', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsPrepareX', 'sSql', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsPrepareX', 'phStmt', 'T_TOP_DBS_STMT*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsSetCfgFile', 'psCfgSection', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsSetCfgFile', 'psCfgFile', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', 'dbsSetDbType', 'iDbType', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopmac', 'macInit', 'sKeyIndex', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopmac', 'macInit', 'sTable', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopmac', 'macGenerate', 'sMac', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopmac', 'macGenerate', 'sMessage', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopmac', 'macGenerate', 'iLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopmac', 'macGenerate', 'ptMessage', 'InMsgPtr', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopmac', 'macVerify', 'sMac', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopmac', 'macVerify', 'sMessage', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopmac', 'macVerify', 'iLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopmac', 'macVerify', 'ptMessage', 'InMsgPtr', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regCompile', 'sReg', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regCompile', 'iFlags', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regFree', 'ptRegExp', 'T_REGEXP*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regExec', 'ptRegExp', 'T_REGEXP*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regExec', 'sStr', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSubCount', 'ptRegExp', 'T_REGEXP*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSub', 'ptRegExp', 'T_REGEXP*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSubString', 'piLen', 'int*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSubString', 'ptRegExp', 'T_REGEXP*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSubString', 'iIndex', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSubString', 'sStr', 'const char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regMatch', 'sReg', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regMatchI', 'sReg', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regMatchN', 'sReg', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regMatchNI', 'sReg', 'const char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearch', 'sReg', 'const char *', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearchI', 'sReg', 'const char *', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearchN', 'sReg', 'const char *', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', 'regSearchNI', 'sReg', 'const char *', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signInit', 'sSection', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signInit', 'sFile', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signGenerateAdd', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signGenerateAdd', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signGenerateAdd', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signGenerate', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signGenerate', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signGenerate', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signGenerateWithCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signGenerateWithCert', 'sSign', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signGenerateWithCert', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signVerifyAdd', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signVerifyAdd', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signVerifyAdd', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signVerify', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signVerify', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signVerify', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signVerifyWithCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signVerifyWithCert', 'sSign', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signVerifyWithCert', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signVerifyWithCert', 'ptCert', 'T_SIGN_CERT*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'signDecodeCert', 'ptCert', 'T_SIGN_CERT*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signInit', 'sSection', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signInit', 'sFile', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signGenerateAdd', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signGenerateAdd', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signGenerateAdd', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signGenerate', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signGenerate', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signGenerate', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signGenerateWithCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signGenerateWithCert', 'sSign', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signGenerateWithCert', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signVerifyAdd', 'iLen', 'int', 1, null, null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signVerifyAdd', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signVerifyAdd', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signVerify', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signVerify', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signVerify', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signVerifyWithCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signVerifyWithCert', 'sSign', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signVerifyWithCert', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signVerifyWithCert', 'ptCert', 'T_SIGN_CERT*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signUploadCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signUploadCert', 'sCert', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', 'signDeleteCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signInit', 'sSection', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signInit', 'sFile', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signGenerateAdd', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signGenerateAdd', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signGenerateAdd', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signGenerate', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signGenerate', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signGenerate', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signGenerateWithCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signGenerateWithCert', 'sSign', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signGenerateWithCert', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signVerifyAdd', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signVerifyAdd', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signVerifyAdd', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signVerify', 'iLen', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signVerify', 'sElement', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signVerify', 'iType', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signVerifyWithCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signVerifyWithCert', 'sSign', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signVerifyWithCert', 'iLen', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signVerifyWithCert', 'ptCert', 'T_SIGN_CERT*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signDecodeCert', 'ptCert', 'T_SIGN_CERT*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signUploadCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signUploadCert', 'sCert', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'signDeleteCert', 'sKey', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'desEncrypt3DES', 'nInBufLen', 'size_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'desDecrypt3DES', 'sOutBuf', 'unsigned char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'desDecrypt3DES', 'pnOutBufLen', 'size_t*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'desDecrypt3DES', 'sKey[24]', 'unsigned char', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'desDecrypt3DES', 'sInBuf', 'unsigned char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'desDecrypt3DES', 'nInBufLen', 'size_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmDate2Tt', 'sDate[9]', 'char', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmTime2Tt', 'sTime[15]', 'char', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmTt2Date', 'ttTime', 'time_t', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmTt2Date', 'sDate[9]', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmTt2Time', 'ttTime', 'time_t', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmTt2Time', 'sTime[15]', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmGetCurDate', 'sDate[9]', 'char', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmGetCurTime', 'sTime[15]', 'char', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmAddDays', 'nDayCnt', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmAddDays', 'sDate[9]', 'char', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmAddSeconds', 'nSecondCnt', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmAddSeconds', 'sTime[15]', 'char', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmDaysBetween', 'sDate2[9]', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmDaysBetween', 'sDate1[9]', 'char', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmSecondsBetween', 'sTime1[15]', 'char', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmSecondsBetween', 'sTime2[15]', 'char', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmFmtTime', 'sFmt', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmFmtTime', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmFmtTime', 'ttTime', 'time_t', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmFmtTime', 'nBufLen', 'size_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmGetCurFmtTime', 'sFmt', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmGetCurFmtTime', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmGetCurFmtTime', 'nBufLen', 'size_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmStdTime', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmBeginTimer', 'ptvBegin', 'struct timeval*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmEndTimer', 'ptvBegin', 'struct timeval*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmBeginTimer2', 'ptTimer', 'T_TIMER*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dtmEndTimer2', 'ptTimer', 'T_TIMER*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encEncodeBase64', 'sOutBuf', 'unsigned char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encEncodeBase64', 'pnOutBufLen', 'size_t*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encEncodeBase64', 'sInBuf', 'unsigned char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encEncodeBase64', 'nInBufLen', 'size_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encDecodeBase64', 'sOutBuf', 'unsigned char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encDecodeBase64', 'pnOutBufLen', 'size_t*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encDecodeBase64', 'sInBuf', 'unsigned char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encDecodeBase64', 'nInBufLen', 'size_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encEncodeHexZero', 'sOutBuf', 'unsigned char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encEncodeHexZero', 'pnOutBufLen', 'size_t*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encEncodeHexZero', 'sInBuf', 'unsigned char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encEncodeHexZero', 'nInBufLen', 'size_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encDecodeHexZero', 'sOutBuf', 'unsigned char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encDecodeHexZero', 'pnOutBufLen', 'size_t*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encDecodeHexZero', 'sInBuf', 'unsigned char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encDecodeHexZero', 'nInBufLen', 'size_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encEncodeHex16', 'sOutBuf', 'unsigned char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encEncodeHex16', 'pnOutBufLen', 'size_t*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encEncodeHex16', 'sInBuf', 'unsigned char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encEncodeHex16', 'nInBufLen', 'size_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encDecodeHex16', 'sOutBuf', 'unsigned char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encDecodeHex16', 'pnOutBufLen', 'size_t*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encDecodeHex16', 'sInBuf', 'unsigned char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'encDecodeHex16', 'nInBufLen', 'size_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'filRead', 'piLen', 'int*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'filRead', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'filRead', 'sFile', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'filWrite', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'filWrite', 'iLen', 'int', 1, null, null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'filWrite', 'sFile', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'filDateDir', 'sPath', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'filDateDir2', 'sPath', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'filGetSeqNext', 'sFileName', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'filGetSeqNext', 'iMax', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashNew', 'iSize', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashGet', 'sKey', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashGet', 'ptHashTable', 'T_HASH_TABLE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashDel', 'sKey', 'const char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashDel', 'ptHashTable', 'T_HASH_TABLE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashFree', 'ptHashTable', 'T_HASH_TABLE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashCount', 'ptHashTable', 'T_HASH_TABLE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashIter', 'ptHashTable', 'T_HASH_TABLE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashRewind', 'ptHashTable', 'T_HASH_TABLE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashSort', 'fCompare', 'int (*)(void *, void *)', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'hashSort', 'ptHashTable', 'T_HASH_TABLE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadString', 'sKey', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadString', 'sSection', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadString', 'sDefault', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadString', 'sOutBuf', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadString', 'sFile', 'char*', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadString', 'nInBufLen', 'size_t', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadInt', 'sKey', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadInt', 'sSection', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadInt', 'nDefault', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadInt', 'sFile', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadString2', 'sKey', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadString2', 'sSection', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadString2', 'sDefault', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadString2', 'sOutBuf', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadString2', 'sFile', 'char*', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadString2', 'iInBufLen', 'size_t', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadInt2', 'sKey', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadInt2', 'iDefault', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadInt2', 'sSection', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniReadInt2', 'sFile', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniWriteString', 'sKey', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniWriteString', 'sSection', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniWriteString', 'sInBuf', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'iniWriteString', 'sFile', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strRightTrim', 'sStr', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strLeftTrim', 'sStr', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strTrim', 'sStr', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strInt2Str', 'nNum', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strInt2Str', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strInt2Str', 'nBufLen', 'size_t', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2Int', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2Int', 'nBufLen', 'size_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strLong2Str', 'nNum', 'long', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strLong2Str', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strLong2Str', 'nBufLen', 'size_t', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2Long', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2Long', 'nBufLen', 'size_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strLL2Str', 'nNum', 'long long', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strLL2Str', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strLL2Str', 'nBufLen', 'size_t', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2LL', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2LL', 'nBufLen', 'size_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strDbl2Str', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strDbl2Str', 'dNum', 'double', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strDbl2Str', 'nDot', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strDbl2Str', 'nBufLen', 'size_t', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2Dbl', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2Dbl', 'nDot', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2Dbl', 'nBufLen', 'size_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strDbl2StrRaw', 'sBuf', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strDbl2StrRaw', 'dNum', 'double', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strDbl2StrRaw', 'nDot', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strDbl2StrRaw', 'nBufLen', 'size_t', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2DblRaw', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2DblRaw', 'nDot', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStr2DblRaw', 'nBufLen', 'size_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strMem2Str', 'iSrcLen', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strMem2Str', 'iDestSize', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strMem2Str', 'sDest', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strMem2Str', 'sSrc', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strToLower', 'sStr', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strToUpper', 'sStr', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strFirstUpper', 'sStr', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStrChr', 'sBuf', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strStrChr', 'pIsMatch', 'int (*)(char)', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strDirName', 'sPath', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strBaseName', 'sPath', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strPathJoin', 'sPrefix', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strPathJoin', 'sPath', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strPathJoin2', 'sAppend', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strPathJoin2', 'sPath', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strReplaceDir', 'sDir', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'strReplaceDir', 'sPath', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dllOpen', '_sDllFile', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dllGetFun', '_hDll', 'H_DllFile', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dllGetFun', '_sFunName', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'dllClose', '_hDll', 'H_DllFile', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileRead', 'iWhence', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileRead', 'iOffset', 'off_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileRead', 'iLen', 'off_t', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileRead', 'fd', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileReadW', 'iWhence', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileReadW', 'iOffset', 'off_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileReadW', 'iLen', 'off_t', 3, null, null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileReadW', 'fd', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileWrite', 'iWhence', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileWrite', 'iOffset', 'off_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileWrite', 'iLen', 'off_t', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileWrite', 'fd', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileWriteW', 'iWhence', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileWriteW', 'iOffset', 'off_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileWriteW', 'iLen', 'off_t', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileWriteW', 'fd', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileUnLock', 'iWhence', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileUnLock', 'iOffset', 'off_t', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileUnLock', 'iLen', 'off_t', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'lockFileUnLock', 'fd', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procParseAgrs', 'psLine', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procParseAgrs', 'psArgv[]', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procStartProcess', 'psProcName', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procStartProcess', 'psBin', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procStartProcess', 'psArgs', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procStartProcessE', 'psProcName', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procStartProcessE', 'psBin', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procStartProcessE', 'psArgs', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procStartProcessE', 'iOption', 'int', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procSndSig2Proc', 'iPid', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procSndSig2Proc', 'iSig', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procIsExist', 'iPid', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procRunAsDaemon', 'psRoot', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procRunAsDaemon', 'iOptions', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'procRunAsDaemon', 'iMask', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'fsGetFileSize', 'psFileName', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'fsGetNewFile', 'sPrefix', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'fsGetNewFile', 'sFile', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'semCreate', 'iKey', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'semCreate', 'iOption', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'semP', 'iSemId', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'semV', 'iSemId', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'semDelete', 'iSemId', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'shmOpen', 'iFlg', 'int', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'shmOpen', 'iKey', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'shmOpen', 'iSize', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'shmOpen', 'ptShmHdl', 'T_SHM_HANDLE*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'shmMap', 'ptShmHdl', 'T_SHM_HANDLE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'shmRemove', 'ptShmHdl', 'T_SHM_HANDLE*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockGetPeerAddr', 'iSockNo', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockGetPeerAddr', 'piPort', 'int*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockGetPeerAddr', 'psAddr', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockGetLocalAddr', 'iSockNo', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockGetLocalAddr', 'piPort', 'int*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockGetLocalAddr', 'psAddr', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockCanRead', 'iSockNo', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockIsPeerClosed', 'iSockNo', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockSetRTimeOut', 'iSockNo', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockSetRTimeOut', 'iSeconds', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockSetSTimeOut', 'iSockNo', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockSetSTimeOut', 'iSeconds', 'int', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockSetAddrReuse', 'iSockNo', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockSetKeepAlive', 'iSockNo', 'int', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockGetHostIp', 'psHostName', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'sockGetHostIp', 'psIpAddr', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgInit', 'psFile', 'char*', 0, 'log config File Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logInit', 'psFile', 'char*', 0, 'Cfg File Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logInit', 'psName', 'char*', 1, 'Cfg section Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logInfo', 'psFile', 'char*', 3, 'source File Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logInfo', 'psLogStr', 'char*', 6, 'Log Message', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logInfo', 'psLevelStr', 'char*', 2, 'NOT USE', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logInfo', 'nLine', 'int', 4, 'source File Line', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logInfo', '...', '...', 7, 'Log Message Args', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logInfo', 'nLevel', 'int', 1, 'Log Level', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logVInfo', 'psFile', 'char*', 3, 'source File Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logVInfo', 'psLogFile', 'char*', 0, 'If Not Null, printf Message To Log File', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logVInfo', 'psLevelStr', 'char*', 2, 'NOT USE', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logVInfo', 'psFunction', 'const char*', 5, 'source Function Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logVInfo', 'ap', 'va_list', 7, 'Log Message Args', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logVInfo', 'nLevel', 'int', 1, 'Log Level', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgInfo', 'psFile', 'char*', 2, 'source File Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgInfo', 'psLogStr', 'char*', 5, 'Log Message', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgInfo', 'ptLogAllCfg', 'struct LogAllCfg*', 0, 'Log Config Info', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgInfo', 'nLine', 'int', 3, 'source File Line', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgInfo', '...', '...', 6, 'Log Message Args', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgInfo', 'psFunction', 'const char*', 4, 'source Function Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgInfo', 'nLevel', 'int', 1, 'Log Level', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logSession', 'psKey', 'char*', 0, 'Session Key', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgSession', 'ptLogAllCfg', 'struct LogAllCfg*', 0, 'Log All Config Info', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgSession', 'psKey', 'char*', 1, 'Session Key', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logSessionStart', 'psKey', 'char*', 0, 'Session Key', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgSessionStart', 'ptLogAllCfg', 'struct LogAllCfg*', 0, 'All Session Config', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgSessionStart', 'psKey', 'char*', 1, 'Session Key', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logSessionEnd', 'psKey', 'char*', 0, 'Session Key', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgSessionEnd', 'ptLogAllCfg', 'struct LogAllCfg*', 0, 'All Log Cnfig Info', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgSessionEnd', 'psKey', 'char*', 1, 'Session Key', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logDebugString', 'psFile', 'char*', 2, 'Source File name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logDebugString', 'psStrName', 'char*', 6, 'Source String Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logDebugString', 'psLogFile', 'char*', 0, 'Is Not Null, printf log to Log File', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logDebugString', 'nLine', 'int', 3, 'Source File Num', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logDebugString', 'psStr', 'char*', 5, 'Source String', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logDebugString', 'psFunction', 'const char*', 4, 'Source File Function', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logDebugString', 'nStrLen', 'int', 7, 'Source String Line', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logDebugString', 'nFormat', 'int', 1, 'NOT USE Just For Old interface', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgDebugString', 'psFile', 'char*', 1, 'Source File name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgDebugString', 'psStrName', 'char*', 5, 'Debug String Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgDebugString', 'ptLogAllCfg', 'struct LogAllCfg*', 0, 'All Log Configer Info', null, null, null, null, null, null);
commit;
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgDebugString', 'nLine', 'int', 2, 'Source File Line', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgDebugString', 'psStr', 'char*', 4, 'Debug String Buf', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgDebugString', 'psFunction', 'const char*', 3, 'Source File Fucntion Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logCfgDebugString', 'nStrLen', 'int', 6, 'Debug String Buf Line', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logSetFile', 'psLogFileName', 'char*', 0, 'Set Log File Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logSetMode', 'pnMode', 'int*', 0, 'Set Log Show Level', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'SetMaxFileSize', 'nMaxSize', 'int', 0, 'Set File Max Size', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logGetSeesionId', 'nLen', 'int', 1, 'return buffer max len', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logGetSeesionId', 'psVaule', 'char*', 0, 'return session id buffer', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logGetLogFile', 'nLen', 'int', 1, 'return buffer max len', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logGetLogFile', 'psVaule', 'char*', 0, 'retrun file name buffer', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logSetConfig', 'psLogFileName', 'char*', 0, 'Set File Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logSetConfig', 'nLogFileSize', 'long', 1, 'Set File Max Size', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logSetConfig', 'nLogMode', 'int', 2, 'Set Log dispaly level', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logIniDefRead', 'psFile', 'char*', 6, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logIniDefRead', 'nOutLen', 'int', 5, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logIniDefRead', 'psKey', 'char*', 2, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logIniDefRead', 'psOutBuf', 'char*', 4, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logIniDefRead', 'psGroup', 'char*', 0, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logIniDefRead', 'psPkg', 'char*', 1, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'logIniDefRead', 'psDefault', 'char*', 3, null, null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'diskUseRate', 'psFilePath', 'char*', 0, 'File Path For Disk mount', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'netStat', 'psIp', 'char*', 0, 'Check Ip,if psIp is Null Check Local Ip ( Ip / 0.0.0.0 / 127.0.0.1)', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'netStat', 'ptTcpStat', 'T_NET_TCP_STAT*', 2, 'Check Port', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'netStat', 'nPort', 'int', 1, 'return All net connect info', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'prcGetProcNum', 'psProcName', 'char*', 0, 'Porcess Name', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'prcGetProcName', 'nPid', 'int', 0, 'Porcess Id', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'prcGetProcName', 'psProcName', 'char*', 1, 'Return Process Name Buffer', null, null, null, null, null, null);
insert into TF_FUN_PARAMS (MOD_NAME, FUN_NAME, PARAM_NAME, TYPE, IDX, REMARKS, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'prcGetProcName', 'nNameLen', 'int', 2, 'Return Buffer Max Len', null, null, null, null, null, null);
commit;
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_auto', null, 'libtopsign_auto', 'topsign_auto.h', null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_ksvs', null, 'libtopsign_ksvs', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_soft', null, 'libtopsign_soft', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoputil', 'ͨ�ù��߿�', 'libtoputil', 'util.h', 'base', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libapp_mgr_datasource_shm', 'Ӧ�ù����������ڴ�����Դ', 'libapp_mgr_datasource_shm', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue', '��Ϣ����ͨѶ�ӿ�������ѷ�������ipc_queueȡ��', 'libcom_queue', 'com_queue.h', null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libct_cmttag', null, 'libct_cmttag', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libct_cvt', null, 'libct_cvt', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libct_hvps', null, 'libct_hvps', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libct_ibps', null, 'libct_ibps', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libct_ipc2xml', null, 'libct_ipc2xml', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libct_ipc', null, 'libct_ipc', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libct_xml', null, 'libct_xml', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvt2', null, 'libcvt2', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvt_plug_eft', null, 'libcvt_plug_eft', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvt_plug_format_ipc', null, 'libcvt_plug_format_ipc', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvt_plug_format_xml2', null, 'libcvt_plug_format_xml2', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvt_plug_format_xml', null, 'libcvt_plug_format_xml', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvt_plug_sics', null, 'libcvt_plug_sics', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvt', null, 'libcvt', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_db2', 'db2���ݿ����', 'libdbs_db2', 'topdbs.h', 'base', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_oracle', 'oracle���ݿ����', 'libdbs_oracle', 'top_dbs.h', 'base', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfault_commom_tools', '�ݴ��������߼�', 'libfault_commom_tools', null, 'biz', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfunction_plug_ctl', null, 'libfunction_plug_ctl', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_bizhelper', 'ҵ��������������', 'libglb_bizhelper', 'biz_helper.h', 'biz', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_dllmgr', '��̬�������', 'libglb_dllmgr', 'dllmgr_itf.h', 'base', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglbmsgrpt', '��Ϣ�������ѷ���', 'libglbmsgrpt', 'msg_rpt.h', 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc_helper', 'poc���������������ڼ򻯿���', 'libglb_poc_helper', 'poc_helper.h', 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_poc', '�������������ӿ�', 'libglb_poc', 'poc_object.h', 'base', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_datasource_csv', 'ipc���csv����Դ����csv�ļ��м�������', 'libipc_msgque_datasource_csv', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_ibm', '��ϢͨѶibm-mqʵ��', 'libipc_msgque_ibm', 'ipc_msgque_ibm.h', 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_queue', '��Ϣ����ͨѶ�ӿ�', 'libipc_queue', 'ipc_queue.h', 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent_cli', 'MQ�����⣬�ͻ��˷�ʽ��', 'libmq_agent_cli', 'mq_agent.h', null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libmq_agent', 'MQ֧�ֿ⣬ֱ�����й�������ʽʵ��', 'libmq_agent', 'mq_agent.h', null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_sms_modem', '����è֧��', 'libnet_sms_modem', 'net_sms_modem.h', 'base', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_fault_bdg', '�ݴ�����bridge�쳣�������', 'libplug_fault_bdg', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_function_monitor_disk_plug', '���̼�ز��', 'libplug_function_monitor_disk_plug', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_function_monitor_file_plug', '�ļ���ز��', 'libplug_function_monitor_file_plug', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_function_monitor_proc', '���̼�ز��', 'libplug_function_monitor_proc', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_function_plug_ctl', null, 'libplug_function_plug_ctl', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbappmgr', 'Ӧ�ù��������', 'libplug_glbappmgr', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbappmon', '���̼�ز��', 'libplug_glbappmon', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbappsc', '�ű�����̨���', 'libplug_glbappsc', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbbridge2', 'Bridge��չ������汾2', 'libplug_glbbridge2', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbcomnodb', '��Ϣ���г�ʼ�������û�����ݿ�棬�ѷ�����', 'libplug_glbcomnodb', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbcom', '��Ϣ����com_queue�����ʼ��������ѷ���', 'libplug_glbcom', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbcron', '��ʱ���Ȳ��', 'libplug_glbcron', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbcvt', null, 'libplug_glbcvt', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbdb_db', '���ݿ��ʼ��������������ݿ⡢�������ݿ���Դ��', 'libplug_glbdb_db', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glb_flowproc', '���̴������', 'libplug_glb_flowproc', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glb_monitor', '��ز��', 'libplug_glb_monitor', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbmsgque', '��Ϣ���в����ʵ����Ϣ����ͨѶ', 'libplug_glbmsgque', 'plug_glbmsgque.h', 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbmsgsvr', '��Ϣ֪ͨ���', 'libplug_glbmsgsvr', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbpartner_filescan', '������ļ�ɨ����', 'libplug_glbpartner_filescan', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbpartner_sunlink', '�����sunlink�ԽӲ��', 'libplug_glbpartner_sunlink', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbpartner_tcpclient', '�����tcp�ͻ��˲��', 'libplug_glbpartner_tcpclient', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbpartner_tcpserver', '�����tcp����˲��', 'libplug_glbpartner_tcpserver', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbpartner_topmq', null, 'libplug_glbpartner_topmq', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glb_poc_ds_cvt', null, 'libplug_glb_poc_ds_cvt', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbrte', null, 'libplug_glbrte', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbrun', 'commͨ�ö˲��', 'libplug_glbrun', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbswt', 'switch��չ���', 'libplug_glbswt', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbtlr4old', 'tlrcomm������ϵͳ���', 'libplug_glbtlr4old', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_cvt', 'poc��ʽת������Դ', 'libpoc_datasource_cvt', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_funs', 'poc ��������Դ', 'libpoc_datasource_funs', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_mem', 'poc��̬�ڴ�����Դ', 'libpoc_datasource_mem', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libpoc_datasource_static', 'poc��̬�ڴ�����Դ', 'libpoc_datasource_static', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('librte', null, 'librte', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libstt', null, 'libstt', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtcp_hdr_helper', 'tcpͷ��������', 'libtcp_hdr_helper', null, 'base', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtoapi', null, 'libtoapi', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopcry', null, 'libtopcry', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtop_dbs', '���ݿ�ͨ�ýӿ�', 'libtop_dbs', 'top_dbs.h', 'base', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_cfca', 'ǩ��cfca��װ', 'libtopsign_cfca', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign_netsign', '�Ű�ǩ���������ӿڷ�װ', 'libtopsign_netsign', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopsign', 'ǩ��ͨ�ýӿ�', 'libtopsign', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcom_queue_nodb', '��Ϣ���нӿڷ�װ�������ݿ�棬�ѷ���', 'libcom_queue_nodb', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcore_ctx', '���Ļ���', 'libcore_ctx', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libct_cmtdomain', null, 'libct_cmtdomain', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libct_cmthead', null, 'libct_cmthead', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libct_cmt', null, 'libct_cmt', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libct_cnaps2In', null, 'libct_cnaps2In', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvt_plug_cmt', null, 'libcvt_plug_cmt', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvt_plug_cnaps2', null, 'libcvt_plug_cnaps2', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvt_plug_ibps', null, 'libcvt_plug_ibps', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvt_plug_poc', 'poc��ʽת������Դ���', 'libcvt_plug_poc', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libcvtwrap', null, 'libcvtwrap', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_mysql', '���ݿ�mysql��װ', 'libdbs_mysql', 'top_dbs.h', 'base', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libdbs_sybase', '���ݿ�sybase��װ', 'libdbs_sybase', 'top_dbs.h', 'base', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_flowprocessor', '���̴�����', 'libglb_flowprocessor', 'flowprocessor', 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgrpt_svrid', 'msgsvr svrid֧��', 'libglb_msgrpt_svrid', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libglb_msgsvr_api', null, 'libglb_msgsvr_api', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_datasource_db', '��ϢͨѶ���ݿ�����Դ', 'libipc_msgque_datasource_db', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_sysv', '��Ϣ����ͨѶ,sysv��Ϣ����ʵ��', 'libipc_msgque_sysv', 'ipc_msgque_sysv.h', 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libipc_msgque_topmq', '��Ϣ����ͨѶ,topmqͨѶ��װ', 'libipc_msgque_topmq', 'ipc_msgque_topmq.h', 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libnet_smtp', 'smtpʵ��', 'libnet_smtp', 'net_smtp.h', 'base', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbbridge', 'bridge��չʵ�֣��ѷ���', 'libplug_glbbridge', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbpartner_activemq', '�����activemqʵ��', 'libplug_glbpartner_activemq', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbpartner_cicsclient', '�����cics�ͻ���ʵ��', 'libplug_glbpartner_cicsclient', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbpartner_mq_cli', '�����mq�ͻ������ӷ�ʽʵ��', 'libplug_glbpartner_mq_cli', null, 'fw', null, null, null, null, null);
commit;
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbpartner_mq', '�����mq server���ӷ�ʽʵ��', 'libplug_glbpartner_mq', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbpmon', '���̼�ز�����ѷ���', 'libplug_glbpmon', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glb_poc_ds_funs', 'poc ��������Դ���', 'libplug_glb_poc_ds_funs', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glb_poc', 'poc���ز��', 'libplug_glb_poc', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glbtlr', 'tellercomm��չ���', 'libplug_glbtlr', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_glb_toctl_server', '��ʱ����server���', 'libplug_glb_toctl_server', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libplug_mgr', '���������', 'libplug_mgr', null, 'fw', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libsqlmem', null, 'libsqlmem', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopmac', null, 'libtopmac', null, null, null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libtopregex', '�������ʽ���', 'libtopregex', 'topregex.h', 'base', null, null, null, null, null);
insert into TF_MOD (MOD_NAME, REMARKS, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('libfault_ipc_hook', '�ݴ�������ipc����ʵ��', 'libfault_ipc_hook', null, 'fw', null, null, null, null, null);
commit;
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('fault_bdg', 'huateng.glb.fault.bdg', '00.01.0001', 'plug for bdg fault .', 'fault_bdg', 'appPlugLoad', 'plug', 'libplug_fault_bdg.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('poc', 'huateng.glb.poc', '00.01.0001', 'poc glb plug .', 'poc', 'pocPlugLoad', 'plug', 'libplug_glb_poc.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('poc_cvt', 'huateng.glb.poc.cvt', '00.01.0001', 'cvt datasource for poc .', 'poc_cvt', 'pocPlugLoad', 'plug', 'libplug_glb_poc_ds_cvt.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('poc_funs', 'huateng.glb.poc.funs', '00.01.0001', 'functions datasource for poc.', 'poc_funs', 'pocPlugLoad', 'plug', 'libplug_glb_poc_ds_funs.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('poc_flow', 'huateng.glb.poc.flow', '00.01.0001', 'flowunit datasource for poc.', 'poc_flow', 'pocPlugLoad', 'plug', 'libplug_glb_poc_ds_flow.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('toctl', 'huateng.glb.toctl', '00.01.0001', 'timeout ctrl glb plug .', 'toctl', 'toPlugLoad', 'plug', 'libplug_glb_toctl_server.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('to', 'huateng.glb.toctl', '00.01.0001', 'timeout ctrl glb plug .', 'to', 'tocapiPlugLoad', 'plug', 'libtoapi.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('cron', 'huateng.glb.cron', '00.01.0001', 'cron glb plug .', 'cron', 'cronPlugLoad', 'plug', 'libplug_glbcron.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('swt', 'huateng.glb.swt', '00.01.0001', 'swt glb plug .', 'swt', 'swtPlugLoad', 'plug', 'libplug_glbswt.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('flow', 'huateng.glb.flowproc', '00.01.0001', 'flowproc glb plug .', 'flow', 'flowPlugLoad', 'plug', 'libplug_glb_flowproc.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('bdg2', 'huateng.glb.bridge2', '00.01.0001', 'bridge plug version 2.', 'bdg2', 'bdgPlugLoad', 'plug', 'libplug_glbbridge2.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('cvt', 'huateng.glb.convert', '00.00.0001', 'convert plug.', 'cvt', 'cvtPlugLoad', 'plug', 'libplug_glbcvt.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('rte', 'huateng.glb.route', '00.00.0001', 'route plug.', 'rte', 'rtePlugLoad', 'plug', 'libplug_glbrte.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('bdg', 'huateng.glb.bridge', '00.00.0001', 'bridge plug.', 'bdg', 'baseAppPlugLoad', 'plug', 'libplug_glbbridge.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('msgsvr', 'huateng.glb.app.msgsvr', '00.00.0001', 'msgsvr plug.', 'msgsvr', 'msgPlugLoad', 'plug', 'libplug_glbmsgsvr.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('appmgr', 'huateng.glb.app.appmgr', '00.00.0001', 'appmgr plug.', 'appmgr', 'appGlbPlugLoad', 'plug', 'libplug_glbappmgr.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('appmon', 'huateng.glb.app.appmon', '00.00.0001', 'appmon plug.', 'appmon', 'appGlbPlugLoad', 'plug', 'libplug_glbappmon.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('run', 'huateng.glb.app.run', '00.00.0001', 'run plug.', 'run', 'runPlugLoad', 'plug', 'libplug_glbrun.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('scan', 'huateng.glb.partner.filescan', '00.00.0001', 'file scan plug.', 'scan', 'scanPlugLoad', 'plug', 'libplug_glbpartner_filescan.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('cics', 'huateng.glb.partner.cics', '00.01.0001', 'cics client plug.', 'cics', 'cicsPlugLoad', 'plug', 'libplug_glbpartner_cicsclient.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('sunlink', 'huateng.glb.partner.sunlink', '00.00.0001', 'sunlink plug.', 'sunlink', 'sunlinkPlugLoad', 'plug', 'libplug_glbpartner_sunlink.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('appsc', 'huateng.glb.app.appsc', '00.00.0001', 'appsc plug.', 'appsc', 'appGlbPlugLoad', 'plug', 'libplug_glbappsc.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('db', 'huateng.global.db', '00.00.0001', 'global db dbplug.', 'db', 'dbPlugLoad', 'plug', 'libplug_glbdb_db.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('com', 'huateng.global.com', '00.00.0001', 'global com plug.', 'com', 'comPlugLoad', 'plug', 'libplug_glbcom.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('que', 'huateng.global.ipc.msgque', '00.00.0001', 'global msgque plug.', 'que', 'glbMsgQPlugLoad', 'plug', 'libplug_glbmsgque.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('nodbcom', 'huateng.global.com', '00.00.0001', 'global com plug.', 'nodbcom', 'comPlugLoad', 'plug', 'libplug_glbcomnodb.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('tlr', 'huateng.glb.tlr', '00.00.0001', 'global tlr plug.', 'tlr', 'tlrPlugLoad', 'plug', 'libplug_glbtlr.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('tlr4old', 'huateng.glb.tlr4old', '00.00.0001', 'global tlr plug.', 'tlr4old', 'tlrPlugLoad', 'plug', 'libplug_glbtlr4old.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('activemq', 'huateng.global.partner.activemq', '00.00.0001', 'global partner activemq  plug.', 'activemq', 'activePlugLoad', 'plug', 'libplug_glbpartner_activemq.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('mq', 'huateng.global.partner.mq', '00.00.0001', 'global partner mq  plug.', 'mq', 'mqPlugLoad', 'plug', 'libplug_glbpartner_mq.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('tcpcli', 'huateng.global.partner.tcpclient', '00.00.0001', 'global partner tcpclient  plug.', 'tcpcli', 'netPlugLoad', 'plug', 'libplug_glbpartner_tcpclient.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('tcpserv', 'huateng.global.partner.tcpserver', '00.00.0001', 'global partner tcpserver  plug.', 'tcpserv', 'netPlugLoad', 'plug', 'libplug_glbpartner_tcpserver.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('pmon', 'huateng.glb.pmon', '00.00.0001', 'global pmon plug.', 'pmon', 'pmonPlugLoad', 'plug', 'libplug_glbpmon.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('monitor', 'huateng.global.plug.monitor', '00.00.0001', 'global plug manager add-ins.', 'monitor', 'MonitorPlugLoad', 'plug', 'libplug_glb_monitor.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('func_plug', 'huateng.global.plug.plug_ctl', '00.00.0001', 'global plug manager add-ins.', 'func_plug', 'plugctlPlugLoad', 'plug', 'libplug_function_plug_ctl.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('monitor_interface', 'huateng.global.plug.monitorinterface', '00.00.0001', 'monitor interface plug add-ins.', 'monitor_interface', 'plugMonitorInterfacePlugLoad', 'plug', 'libplug_function_monitor_proc.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('monitor_file', 'huateng.global.plug.monitor_file', '00.00.0001', 'monitor plug for monitor interface.', 'monitor_file', 'monitorfilePlugLoad', 'plug', 'libplug_function_monitor_file_plug.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('monitor_disk', 'huateng.global.plug.monitor_disk', '00.00.0001', 'monitor pug for monitor interface.', 'monitor_disk', 'monitDiskPlugLoad', 'plug', 'libplug_function_monitor_disk_plug.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('cvt_interface', 'huateng.global.plug.interface.cvt', '00.00.0001', 'cvt interfacer add-ins.', 'cvt_interface', 'cvtPlugLoad', 'plug', 'libcvt.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('cvt2', 'huateng.global.plug.cvt2', '00.00.0001', 'plug for cvt interface add-ins.', 'cvt2', 'cvtPlugLoad', 'plug', 'libcvt2.so', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('appinit', 'huateng.global.app.init', '00.00.0001', 'global app init add-ons.', 'appinit', ' ', 'plug', ' ', null, null, null, null, null, null, null);
insert into TF_PLUG (PLUG_NAME, FULL_NAME, VERSION, REMARKS, MOD_NAME, LOAD_FUN, OBJECT, LIB_NAME, HEAD_FILE, USAGE, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('base_app', 'huateng.global.base.app', '00.00.0001', 'global app base add-ons.', 'base_app', ' ', 'plug', ' ', null, null, null, null, null, null, null);
commit;
insert into TF_PLUG_EVENT (PLUG_NAME, EVENT_NAME, TYPE, EVENT_ID, EVENT_IN, EVENT_OUT, REMARKS, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('plugmgr', 'EVENT_PLUG_MGR_PLUG_INIT', 'S', '00000001', null, null, 'event manager initialize', null, null, null, null, null);
insert into TF_PLUG_EVENT (PLUG_NAME, EVENT_NAME, TYPE, EVENT_ID, EVENT_IN, EVENT_OUT, REMARKS, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('plugmgr', 'EVENT_PLUG_MGR_PROC_RUN', 'S', '00000002', null, null, 'event manager run', null, null, null, null, null);
insert into TF_PLUG_EVENT (PLUG_NAME, EVENT_NAME, TYPE, EVENT_ID, EVENT_IN, EVENT_OUT, REMARKS, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('plugmgr', 'EVENT_PLUG_MGR_PLUG_UNLOAD', 'S', '00000003', null, null, 'event manager unload', null, null, null, null, null);
insert into TF_PLUG_EVENT (PLUG_NAME, EVENT_NAME, TYPE, EVENT_ID, EVENT_IN, EVENT_OUT, REMARKS, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('plugmgr', 'EVENT_PLUG_MGR_PROC_EXIT', 'S', '00000004', null, null, 'event manager exit', null, null, null, null, null);
insert into TF_PLUG_EVENT (PLUG_NAME, EVENT_NAME, TYPE, EVENT_ID, EVENT_IN, EVENT_OUT, REMARKS, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('que', 'IPC_MSGQUE_NEWMSG', 'D', '10001   ', 'T_PLUG_IPC_MSGQUEUE_EVENTDATA', null, 'que found a new message', null, null, null, null, null);
commit;
insert into TF_PLUG_HANDLER (PLUG_NAME, HANDLER_NAME, EVENT_ID, EVENT_IN, EVENT_OUT, REMARKS, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('que', 'EVENT_PLUG_MGR_PLUG_INIT', '00000001', null, null, 'event manager initialize', null, null, null, null, null);
insert into TF_PLUG_HANDLER (PLUG_NAME, HANDLER_NAME, EVENT_ID, EVENT_IN, EVENT_OUT, REMARKS, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('que', 'EVENT_PLUG_MGR_PROC_RUN', '00000002', null, null, 'event manager run', null, null, null, null, null);
insert into TF_PLUG_HANDLER (PLUG_NAME, HANDLER_NAME, EVENT_ID, EVENT_IN, EVENT_OUT, REMARKS, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('que', 'EVENT_PLUG_MGR_PROC_EXIT', '00000004', null, null, 'event manager exit', null, null, null, null, null);
insert into TF_PLUG_HANDLER (PLUG_NAME, HANDLER_NAME, EVENT_ID, EVENT_IN, EVENT_OUT, REMARKS, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('que', 'IPC_MSGQUE_NEWMSG', '10001   ', 'T_PLUG_IPC_MSGQUEUE_EVENTDATA', null, 'que found a new message', null, null, null, null, null);
insert into TF_PLUG_HANDLER (PLUG_NAME, HANDLER_NAME, EVENT_ID, EVENT_IN, EVENT_OUT, REMARKS, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('que', 'IPC_MSGQUE_GETMSG', '10002   ', 'T_PLUG_IPC_MSGQUEUE_EVENTDATA', null, 'que get message', null, null, null, null, null);
commit;
insert into TF_PLUG_PARAM (PLUG_NAME, PARAM_NAME, TYPE, CFG_MOD, CFG_SECTION, PARAM_KEY, REMARKS, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('que', 'plug.datalib', 'String', 'U', 'que', 'plug.datalib', 'data lib', null, null, null, null, null);
insert into TF_PLUG_PARAM (PLUG_NAME, PARAM_NAME, TYPE, CFG_MOD, CFG_SECTION, PARAM_KEY, REMARKS, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('que', 'plug.datalibfun', 'String', 'U', 'que', 'plug.datalibfun', 'data lib func', null, null, null, null, null);
insert into TF_PLUG_PARAM (PLUG_NAME, PARAM_NAME, TYPE, CFG_MOD, CFG_SECTION, PARAM_KEY, REMARKS, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('que', 'plug.datalibcfg', 'String', 'U', 'que', 'plug.datalibcfg', 'data lib func param', null, null, null, null, null);
insert into TF_PLUG_PARAM (PLUG_NAME, PARAM_NAME, TYPE, CFG_MOD, CFG_SECTION, PARAM_KEY, REMARKS, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('que', 'plug.trytime', 'Int', 'U', 'que', 'plug.trytime', 'que try time', null, null, null, null, null);
insert into TF_PLUG_PARAM (PLUG_NAME, PARAM_NAME, TYPE, CFG_MOD, CFG_SECTION, PARAM_KEY, REMARKS, RSV1, RSV2, RSV3, RSV4, RSV5)
values ('que', 'plug.bufmax', 'Int', 'U', 'que', 'plug.bufmax', 'que buffer size', null, null, null, null, null);
commit;
