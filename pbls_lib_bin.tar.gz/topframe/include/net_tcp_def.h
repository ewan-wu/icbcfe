/*
 *
 *
 * tcp common define.
 *
 *
 * FileName: net_tcp_def.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _NET_TCP_DEF_H_20100408163102_
#define _NET_TCP_DEF_H_20100408163102_
/*--------------------------- Include files -----------------------------*/
#include "os_socket.h"
/*--------------------------- Macro define ------------------------------*/
#define DLEN_NET_TCP_FILENAME 512
#define DLEN_NET_TCP_ERRORSTR 1024

#define NET_TCP_CLIENT_OPTION_RTIMEOUT 0x00000001
#define NET_TCP_CLIENT_OPTION_STIMEOUT 0x00000002
#define NET_TCP_CLIENT_OPTION_KEEPALIVE 0x00000004
#define NET_TCP_CLIENT_OPTION_LINGER 0x00000008
#define NET_TCP_CLIENT_OPTION_USESSL 0x00000010
#define NET_TCP_CLIENT_OPTION_CHKCERT 0x00000020

#define NET_TCP_CLIENT_OPTION_TCPCLIENT 0x00000040

#define NET_TCP_CLIENT_OPTION_NOCERT 0x00000100

/*---------------------------- Type define ------------------------------*/
typedef int (*PFN_NET_TCP_LOGPRINT)(char *, int , char *, char *, int , const char *, char *, ...);
typedef int (*PFN_NET_TCPWRITE)(void *this, void *pBuf, int iWriteLen, int iOptions);
typedef int (*PFN_NET_TCPREAD)(void *this, void *pBuf, int iLen, int *piReadLen, int iOptions);
typedef int (*PFN_NET_TCPOBJINIT)(void *this, int iOptions);
typedef int (*PFN_NET_TCPOBJCLOSE)(void *this, int iOptions);

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_NET_TCP_DEF_H_20100408163102_*/
/*-----------------------------  End ------------------------------------*/
