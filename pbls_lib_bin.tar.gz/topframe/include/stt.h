/*
 *
 *
 *  Struct Tools Function Define.
 *
 *
 * FileName: stt.h 
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 *
 */

#ifndef _STT_H_20100408164431_
#define _STT_H_20100408164431_

/*------------------------ Include files ------------------------*/
#include "libxml/parser.h"

#if 0
#pragma mark -
#pragma mark < Macro define >
#endif
/*--------------------- Macro define ----------------------------*/
/* return code */
#define STT_OK                     0
#define STT_ERR                    -1
#define STT_ERR_ARGS_IS_ERROR      -2

#define STT_ERR_RET \
sttSetRet( STT_ERR ); \
return ( NULL );

#define STT_CHK(f) \
sttSetRet(STT_OK);\
f;\
if ( STT_ERR == sttGetRet() ) {\
    CvtLog(CERR, #f); \
    return (NULL);\
}\

#if 0
#pragma mark -
#pragma mark < Type define >
#endif
/*--------------------- Type define -----------------------------*/
typedef void * (*FncSttParse)(char *psFile, char *psType, void *ptRootNode);
typedef void * (*sttFncParseVoid)(void *ptXmlNode, char *psStructType);
typedef void * (*sttFncGenVoid)(void *ptSruct, void *ptNode, char *psNodeName, char *psStructType);

typedef struct EnumList {
    int nIndex;
    char *psName;
} T_EnumList;

#if 0
#pragma mark -
#pragma mark < Global functions declaration >
#endif
/*--------------------- Global function declaration -------------*/
#ifdef __cplusplus
extern "C" {
#endif
    
    void * sttParseXmlFile(char *psFileName, char *psRootTag, char *psType, void *pfParse);
    int sttGenXmlFile(char *psFileName, void *ptStruct, char *psTagName, char *psType, void *pfGen);
    int sttSetVoidType(void *pPoint, char *psStructType);
    char * sttGetVoidType(void *pPoint);
    void * sttParseVoid(xmlNodePtr ptXmlNode, char *psStructType);
    void * sttGenVoid(void *ptSruct, xmlNodePtr *ptXmlNode, char *psNodeName, char *psStructType);
    int sttAddFuncVoid(sttFncParseVoid fpParseVoid, sttFncGenVoid fpGenVoid);
    int sttResetFunctVoid();
    
    /* For New Api */
    int sttAddSttInfo(char *psType, FncSttParse fParseFunction);
    int sttAddVoidFunctionToSttInfo(char *psType, sttFncParseVoid fpParseVoid, sttFncGenVoid fpGenVoid);
    void * sttParseBySttInfo(char *psFile);
    int sttEnd();
    
    int sttSetRet(int nRet);
    int sttGetRet();
    
    /* char */
    char sttParseXmlChar(xmlNodePtr ptXmlNode, char *psName);
    char sttParseXmlCharDefault(xmlNodePtr ptXmlNode, char *psName, char caDefault);
    void sttGenerateXmlChar(xmlNodePtr ptXmlNode, char caChar, char *psName);
    /* string */
    char * sttParseXmlString(xmlNodePtr ptXmlNode, char *psName);
    void sttGenerateXmlString(xmlNodePtr ptXmlNode, char *psString, char *psName);
    void sttFreeXmlString(char *psString);
    /* int */
    int sttParseXmlInt(xmlNodePtr ptXmlNode, char *psName);
    int sttParseXmlIntDefault(xmlNodePtr ptXmlNode, char *psName, int nDefault);
    void sttGenerateXmlInt(xmlNodePtr ptXmlNode, int nInt, char *psName);
    /* long */
    long sttParseXmlLong(xmlNodePtr ptXmlNode, char *psName);
    long sttParseXmlLongDefault(xmlNodePtr ptXmlNode, char *psName, long lDefault);
    void sttGenerateXmlLong(xmlNodePtr ptXmlNode, long lLong, char *psName);
    /* float */
    float sttParseXmlFloat(xmlNodePtr ptXmlNode, char *psName);
    float sttParseXmlFloatDefault(xmlNodePtr ptXmlNode, char *psName, float fDefault);
    void sttGenerateXmlFloat(xmlNodePtr ptXmlNode, float fFloat, char *psName);
    /* double */
    double sttParseXmlDouble(xmlNodePtr ptXmlNode, char *psName);
    double sttParseXmlDoubleDefault(xmlNodePtr ptXmlNode, char *psName, double dDefualt);
    void sttGenerateXmlDouble(xmlNodePtr ptXmlNode, double dDouble, char *psName);
    /* struct */
    void * sttParseXmlStruct(xmlNodePtr ptXmlNode, char *psType, char *psName, void * fFunc);
    void sttGenerateXmlStruct(xmlNodePtr ptXmlNode, void *ptStruct, char *psName, char *psTypeName, void * fFunc);
    /* List */
    void * sttParseXmlNext(xmlNodePtr ptXmlNode, char *psType, char *psName, void * fFunc);
    void sttGenerateXmlNext(xmlNodePtr ptXmlNode, void *ptStruct, char *psName, char *psTypeName, void * fFunc);
    /* void */
    void * sttParseXmlVoid(xmlNodePtr ptXmlNode, char *psName);
    void sttGenerateXmlVoid(xmlNodePtr ptXmlNode, void *ptVoid, char *psName);
    /* enum */
    int sttParseXmlEnum(void * ptXmlNode, T_EnumList *ptList, char *psType);
    int sttParseXmlEnumDefault(void * ptXmlNode, T_EnumList *ptList, char *psType, int nDefault);
    void sttGenerateXmlEnum(void *ptXmlNode, int nType, T_EnumList *ptList, char *psType);
    int sttParseXmlEnumByName(void *ptXmlNode, char *psType, char *psEnumName);
    void sttGenerateXmlEnumByName(void *ptXmlNode, int nType, char *psType, char *psEnumName);
    
#ifdef __cplusplus
}
#endif
/*--------------------- Global variable -------------------------*/

#endif /* _STT_H_20100408164431_ */
/*--------------------- End -------------------------------------*/
