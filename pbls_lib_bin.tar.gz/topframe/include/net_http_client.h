/*
 *
 *
 * for http server.
 *
 *
 * FileName: net_http_client.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _NET_HTTP_CLIENT_H_20110621091653_
#define _NET_HTTP_CLIENT_H_20110621091653_
/*--------------------------- Include files -----------------------------*/
#include "net_tcp_def.h"
#include "net_http_def.h"
#include "net_tcp_client.h"

/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/
struct T_NET_HTTP_CLIENT_S;

typedef int (*PFN_NET_HTTP_CLIENT_SEND_REQHDR)(struct T_NET_HTTP_CLIENT_S *, int iOptions);
typedef int (*PFN_NET_HTTP_CLIENT_SEND_CONTTENT)(struct T_NET_HTTP_CLIENT_S *this, char *psBuf, int iLen, int iOptions);

typedef int (*PFN_NET_HTTP_CLIENT_GET_RESHDR)(struct T_NET_HTTP_CLIENT_S *this, int iOptions);
typedef int (*PFN_NET_HTTP_CLIENT_GET_CONTENT)(struct T_NET_HTTP_CLIENT_S *this, char *psBuf, int *piLen, int iOptions);

typedef struct T_NET_HTTP_CLIENT_S{
    T_NET_TCPCLIENT *ptTcpClient;
    T_NET_HTTP_REQUEST *ptReq;
    T_NET_HTTP_RESPONSE *ptRes;

    PFN_NET_HTTP_CLIENT_SEND_REQHDR pfnSndReqHdr;
    PFN_NET_HTTP_CLIENT_SEND_CONTTENT pfnSndContent;
    PFN_NET_HTTP_CLIENT_GET_RESHDR pfnGetResHdr;
    PFN_NET_HTTP_CLIENT_GET_CONTENT pfnGetContent;
    PFN_NET_TCP_LOGPRINT pfnLogPrint;
} T_NET_HTTP_CLIENT;

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @function: netHttpClientCreate
 *
 * @desc: ����HTTPCLIENT����
 *
 * @param ptClient: tcpclient����
 * @param pfnLogPrint: ��־����
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int netHttpClientCreate(T_NET_HTTP_CLIENT * ptClient,
                        PFN_NET_TCP_LOGPRINT pfnLogPrint);

#ifdef __cplusplus
}
#endif

#endif /*_NET_HTTP_CLIENT_H_20110621091653_*/
/*-----------------------------  End ------------------------------------*/
