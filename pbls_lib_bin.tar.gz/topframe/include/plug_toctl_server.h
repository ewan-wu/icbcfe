/*
 *
 * 
 * Time Out Servere Plug
 * 
 * 
 * FileName: plug_toctl_server.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _PLUG_TOCTL_SERVER_H_20101129154230_
#define _PLUG_TOCTL_SERVER_H_20101129154230_
/*--------------------------- Include files -----------------------------*/
#include "plug_mgr.h"
#include "toapi.h"

/*--------------------------- Macro define ------------------------------*/
#define TO_CFG_SECTION_NAME "toctl"
#define TO_CFG_TBALE_NAME "table"
#define TO_CFG_SEND_ID_NAME "sendid"
#define TO_CFG_TIME_OUT_NAME "timeout"
#define TO_CFG_SLEEOP_TIME "sleep"

#define EVENT_TO_PROCESS 110001

#define DLEN_TABLE_LEN 64
#define DLEN_TO_SEND_ID_LEN 10
#define DLEN_TO_SEND_MSG_LEN DLEN_TO_INFO_LEN - DLEN_TO_SEND_ID_LEN

/*---------------------------- Type define ------------------------------*/
/* To Base Info */
typedef struct ToInfo {
    char sToKey[DLEN_TO_KEY_LEN];
    char sToInfo[DLEN_TO_INFO_LEN];
} ToInfo;

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @function: toPlugLoad
 *
 * @desc: 
 *
 * @param ptPlugVar:
 *
 * @return int: 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int toPlugLoad(T_PLUG_MGR_PLUG_VAR *ptPlugVar);

#ifdef __cplusplus
}
#endif

#endif /*_PLUG_TOCTL_SERVER_H_20101129154230_*/
/*-----------------------------  End ------------------------------------*/
