/*
 *
 *
 * Plugin Bridge Version 2
 *
 *
 * FileName: plug_bridge.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _PLUG_BRIDGE_H_20100730092434_
#define _PLUG_BRIDGE_H_20100730092434_
/*--------------------------- Include files -----------------------------*/
#include	"plug_glbmsgque.h"

/*--------------------------- Macro define ------------------------------*/
#define	BDG_EVT_BASE	90000
#define	BDG_EVT_AFT_RCV	(BDG_EVT_BASE + 0)
#define	BDG_EVT_AFT_SVR	(BDG_EVT_BASE + 1)
#define	BDG_EVT_AFT_RTE	(BDG_EVT_BASE + 2)
#define	BDG_EVT_AFT_CVT	(BDG_EVT_BASE + 3)

#define	BDG_ERR_BASE	99000
#define	BDG_ERR_READ	(BDG_ERR_BASE + 0)
#define	BDG_ERR_SERVER	(BDG_ERR_BASE + 1)
#define	BDG_ERR_ROUTE	(BDG_ERR_BASE + 2)
#define	BDG_ERR_CONVERT	(BDG_ERR_BASE + 3)
#define	BDG_ERR_WRITE	(BDG_ERR_BASE + 4)
#define	BDG_ERR_SEND	(BDG_ERR_BASE + 5)

/*---------------------------- Type define ------------------------------*/
typedef int (*F_BDG_ROUTE)(char *sRouteKey, int iSrcSvrId,
                           int *piDestSvrId, char *sDestSvrFmt,
                           char **psErrStr);

typedef int (*F_BDG_SERVER)(T_PLUG_IPC_MSGQUEUE_EVENTDATA *ptIpc,
                            int iSvrId, char *sBuf, int iBufLen,
                            char *sOutFmt, char *sKey, int iKeyLen,
                            char **psErrStr);

typedef int (*F_BDG_CONVERT)(T_PLUG_IPC_MSGQUEUE_EVENTDATA *ptIpc,
                             char *sInFmt, char *sInBuf, int iInBufLen,
                             char *sOutFmt, char **psOutBuf, int *piOutBufLen,
                             char **psErrStr);

typedef int (*F_BDG_FREE)(void);

typedef struct {
	/* plugin ctx */
	T_PLUG_MGR_PLUG_VAR	*ptPlugVar;

	/* buffrt ctx */
	struct {
		char	*pIn;
		char	*pOut;
		int		iSize;
	} tBuf;

	/* out file ctx */
	struct {
		int			iLimit;
		const char	*pDir;
	} tFile;

	/* functions ctx */
	struct {
		F_BDG_SERVER	fSvr;
		F_BDG_FREE		fSvrFree;

		F_BDG_ROUTE		fRte;
		F_BDG_FREE		fRteFree;

		F_BDG_CONVERT	fCvt;
		F_BDG_FREE		fCvtFree;
	} tFunc;

	/* run ctx */
	struct {
		/* at the beginning */
		T_PLUG_IPC_MSGQUEUE_EVENTDATA	*ptIpcIn;

		/* after recv */
		int			iSrcSvrId;
		const char	*pIn;
		int			iInLen;

		/* after server */
		const char	*pSrcFmt;
		const char	*pKey;

		/* after route */
		int			iDestSvrId;
		const char	*pDestFmt;

		/* after convert */
		const char	*pOut;
		int			iOutLen;

		/* ready to send */
		T_PLUG_IPC_MSGQUEUE_EVENTDATA	*ptIpcOut;
	} tRun;

	/* error ctx */
	struct {
		int		iNo;
		char	*pStr;
	} tErr;
} T_BDG_ENV;

/*---------------------- Global function declaration --------------------*/
#ifdef __cplusplus
extern "C" {
#endif

/**
 * @function: bdgGetEnv
 *
 * @desc: ���Bridgeģ���ڲ��������
 *
 * @return T_BDG_ENV *: Bridge�������
 *
 */
T_BDG_ENV *bdgGetEnv(void);

#ifdef __cplusplus
}
#endif

#endif /*_PLUG_BRIDGE_H_20100730092434_*/
/*-----------------------------  End ------------------------------------*/
