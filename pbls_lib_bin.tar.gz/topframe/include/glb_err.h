/*
 *
 * 
 * global error code define.
 * 
 * 
 * FileName: glb_err.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _GLB_ERR_H_20100107092852_
#define _GLB_ERR_H_20100107092852_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_GLB_ERR_H_20100107092852_*/
/*-----------------------------  End ------------------------------------*/
