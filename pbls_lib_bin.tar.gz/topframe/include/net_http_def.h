/*
 *
 *
 * http itf.
 *
 *
 * FileName: net_http_def.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _NET_HTTP_DEF_H_20110713135829_
#define _NET_HTTP_DEF_H_20110713135829_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/
/**/
#define DLEN_NET_HTTP_HDR_ATTR_TINY 64
#define DLEN_NET_HTTP_HDR_ATTR_MINI 256
#define DLEN_NET_HTTP_HDR_ATTR_LARGE 1024
#define DLEN_NET_HTTP_HDR_ATTR_HUGE 10240

#define DLEN_NET_HTTP_HDR_COOKIE_MAX 100


/*---------------------------- Type define ------------------------------*/
/* HTTP 1.1

general-header = Cache-Control            ; Section 14.9
                      | Connection               ; Section 14.10
                      | Date                     ; Section 14.18
                      | Pragma                   ; Section 14.32
                      | Trailer                  ; Section 14.40
                      | Transfer-Encoding        ; Section 14.41
                      | Upgrade                  ; Section 14.42
                      | Via                      ; Section 14.45
                      | Warning                  ; Section 14.46

entity-header  = Allow                    ; Section 14.7
                      | Content-Encoding         ; Section 14.11
                      | Content-Language         ; Section 14.12
                      | Content-Length           ; Section 14.13
                      | Content-Location         ; Section 14.14
                      | Content-MD5              ; Section 14.15
                      | Content-Range            ; Section 14.16
                      | Content-Type             ; Section 14.17
                      | Expires                  ; Section 14.21
                      | Last-Modified            ; Section 14.29
                      | extension-header
                      
Request       = Request-Line              ; Section 5.1
                        *(( general-header        ; Section 4.5
                         | request-header         ; Section 5.3
                         | entity-header ) CRLF)  ; Section 7.1
                        CRLF
                        [ message-body ]          ; Section 4.3

Response      = Status-Line               ; Section 6.1
                       *(( general-header        ; Section 4.5
                        | response-header        ; Section 6.2
                        | entity-header ) CRLF)  ; Section 7.1
                       CRLF
                       [ message-body ]          ; Section 7.2
                       
*/
                        
typedef struct {
    char sCacheControl[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sConnection[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sKeepAlive[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sDate[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sPragma[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sTransferEncoding[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sUpgrade[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sVia[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sWarning[DLEN_NET_HTTP_HDR_ATTR_MINI];
} T_NET_HTTP_GENERAL_HEADER;

typedef struct {
    char sAllow[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sContentEncoding[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sContentLanguage[DLEN_NET_HTTP_HDR_ATTR_TINY];
    int  iContentLength;
    char sContentLocation[DLEN_NET_HTTP_HDR_ATTR_MINI];
    char sContentMD5[DLEN_NET_HTTP_HDR_ATTR_MINI];
    char sContentRange[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sContentType[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sExpires[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sLastModified[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sExtensionHeader[DLEN_NET_HTTP_HDR_ATTR_TINY];
} T_NET_HTTP_ENTITY_HEADER;

/* Cookie:
   cookie          =       NAME "=" VALUE *(";" cookie-av)
   NAME            =       attr
   VALUE           =       value
   cookie-av       =       "Comment" "=" value
                   |       "Domain" "=" value
                   |       "Max-Age" "=" value
                   |       "Path" "=" value
                   |       "Secure"
                   |       "Version" "=" 1*DIGIT
*/

typedef struct {
    char sName[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sValue[DLEN_NET_HTTP_HDR_ATTR_MINI];
    char sComment[DLEN_NET_HTTP_HDR_ATTR_MINI];
    char sDomain[DLEN_NET_HTTP_HDR_ATTR_MINI];
    char sMaxAge[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sPath[DLEN_NET_HTTP_HDR_ATTR_MINI];
    char sSecure[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sVersion[DLEN_NET_HTTP_HDR_ATTR_TINY];
} T_NET_HTTP_COOKIE;

typedef struct {
    int iCookieNum;
    T_NET_HTTP_COOKIE tCookies[DLEN_NET_HTTP_HDR_COOKIE_MAX];
} T_NET_HTTP_COOKIES;

typedef struct {
    /*Request-Line:Method SP Request-URI SP HTTP-Version CRLF*/
    char sMethod[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sUri[DLEN_NET_HTTP_HDR_ATTR_LARGE];
    char sHttpVer[DLEN_NET_HTTP_HDR_ATTR_TINY];

    /*general-header  */
    T_NET_HTTP_GENERAL_HEADER tGeneralHeader;
    
    /*request-header  */
    char sAccept[DLEN_NET_HTTP_HDR_ATTR_LARGE];
    char sAcceptCharset[DLEN_NET_HTTP_HDR_ATTR_MINI];
    char sAcceptEncoding[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sAcceptLanguage[DLEN_NET_HTTP_HDR_ATTR_MINI];
    char sAuthorization[DLEN_NET_HTTP_HDR_ATTR_LARGE];
    char sExpect[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sFrom[DLEN_NET_HTTP_HDR_ATTR_MINI];
    char sHost[DLEN_NET_HTTP_HDR_ATTR_MINI];
   /* char sIfMatch[];
    char sIfModifiedSince[];
    char sIfNoneMatch[];
    char sIfRange[];
    char sIfUnmodifiedSince[];*/
    int iMaxForwards;
    char sProxyAuthorization[DLEN_NET_HTTP_HDR_ATTR_LARGE];
    char sRange[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sReferer[DLEN_NET_HTTP_HDR_ATTR_LARGE];
    char sTE[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sUserAgent[DLEN_NET_HTTP_HDR_ATTR_MINI];

    /*entity-header  */
    T_NET_HTTP_ENTITY_HEADER tEntityHeader;

    /*other*/
    T_NET_HTTP_COOKIES * ptCookies;
    
} T_NET_HTTP_REQUEST;

typedef struct {
    /*Status-Line:HTTP-Version SP Status-Code SP Reason-Phrase CRLF*/
    char sHttpVer[DLEN_NET_HTTP_HDR_ATTR_TINY];    /**/
    int  iStatusCode;
    char sReasonPhrase[DLEN_NET_HTTP_HDR_ATTR_MINI];

    /*general-header*/
     T_NET_HTTP_GENERAL_HEADER tGeneralHeader;
     
    /*response-header*/
    char sAcceptRanges[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sAge[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sETag[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sLocation[DLEN_NET_HTTP_HDR_ATTR_LARGE];
    char sProxyAuthenticate[DLEN_NET_HTTP_HDR_ATTR_LARGE];
    char sRetryAfter[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sServer[DLEN_NET_HTTP_HDR_ATTR_MINI];
    char sVary[DLEN_NET_HTTP_HDR_ATTR_TINY];
    char sWWWAuthenticate[DLEN_NET_HTTP_HDR_ATTR_MINI];

    /*entity-header*/
    T_NET_HTTP_ENTITY_HEADER tEntityHeader;

    /*other*/
    T_NET_HTTP_COOKIES * ptCookies;
} T_NET_HTTP_RESPONSE;
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_NET_HTTP_DEF_H_20110713135829_*/
/*-----------------------------  End ------------------------------------*/
