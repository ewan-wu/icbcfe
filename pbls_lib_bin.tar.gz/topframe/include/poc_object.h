/*
 *
 *
 * object interface define.
 *
 *
 * FileName: poc_object.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _POC_OBJECT_H_20101105093013_
#define _POC_OBJECT_H_20101105093013_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/
#define VAR_POC_OBJECT_VAR_TYPE_STR 0
#define VAR_POC_OBJECT_VAR_TYPE_STRUCT 1
#define VAR_POC_OBJECT_VAR_TYPE_FUNCTION 2

#define VAR_POC_OBJECT_SELF "POC"
#define VAR_POC_DEFAULT_OBJECT "DEFAULTOBJECT"
#define VAR_POC_DEFAULT_OBJECT_TAG "POC.DEFAULTOBJECT"
/*---------------------------- Type define ------------------------------*/
typedef long long  T_POC_INT64;

typedef struct {
    int iType;
    int iLen;
    const char *psValue;
} T_POC_VALUE;

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @function: POC_GetValueS
 *
 * @desc: ��ȡPOC��Tagֵ(string)
 *
 * @param psTag: Tag
 * @param psVar: Tagֵ����
 * @param iLen: Tagֵ���泤��
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int POC_GetValueS(const char *psTag, char *psVar, int iLen);

/**
 * @function: POC_GetValueInt32
 *
 * @desc: ��ȡPOC��Tagֵ(int32)
 *
 * @param psTag: Tag
 *
 * @return int: Tagֵ
 *
 */
int POC_GetValueInt32(const char *psTag);

/**
 * @function: POC_GetValueInt64
 *
 * @desc: ��ȡPOC��Tagֵ(int64)
 *
 * @param psTag: Tag
 *
 * @return T_POC_INT64: Tagֵ
 *
 */
T_POC_INT64 POC_GetValueInt64(const char *psTag);

/**
 * @function: POC_GetValueDouble
 *
 * @desc: ��ȡPOC��Tagֵ(double)
 *
 * @param psTag: Tag
 *
 * @return double: Tagֵ
 *
 */
double POC_GetValueDouble(const char *psTag);

/**
 * @function: POC_GetValue
 *
 * @desc: ��ȡPOC��Tagֵ
 *
 * @param psTag: Tag
 * @param ptVar: Tagֵ
 *
 * @return T_POC_VALUE *: Tagֵ
 *
 */
T_POC_VALUE *POC_GetValue(const char *psTag, T_POC_VALUE *ptVar);

/**
 * @function: POC_SetValueS
 *
 * @desc: ����POC��Tagֵ(string)
 *
 * @param psTag: Tag
 * @param psVar: Tagֵ
 * @param iLen: Tagֵ����
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int POC_SetValueS(const char *psTag, const char *psVar, int iLen);

/**
 * @function: POC_SetValueInt32
 *
 * @desc: ����POC��Tagֵ(int32)
 *
 * @param psTag: Tag
 * @param iValue: Tagֵ
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int POC_SetValueInt32(const char *psTag, int iValue);

/**
 * @function: POC_SetValueInt64
 *
 * @desc: ����POC��Tagֵ(int64)
 *
 * @param psTag: Tag
 * @param lValue: Tagֵ
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int POC_SetValueInt64(const char *psTag, T_POC_INT64 lValue);

/**
 * @function: POC_SetValueDouble
 *
 * @desc: ����POC��Tagֵ(double)
 *
 * @param psTag: Tag
 * @param dValue: Tagֵ
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int POC_SetValueDouble(const char *psTag, double dValue);

/**
 * @function: POC_SetValue
 *
 * @desc: ����POC��Tagֵ
 *
 * @param psTag: Tag
 * @param psVar: Tagֵ
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int POC_SetValue(const char *psTag, T_POC_VALUE *ptVar);

/**
 * @function: POC_ArrayGetValue
 *
 * @desc: ��ȡPOC��Tagֵ(����)
 *
 * @param psTag: Tag
 * @param iPos: �����±�
 * @param ptVar: Tagֵ
 *
 * @return T_POC_VALUE *: Tagֵ
 *
 */
T_POC_VALUE *POC_ArrayGetValue(const char *psTag, int iPos, T_POC_VALUE *ptVar);

/**
 * @function: POC_ArraySetValue
 *
 * @desc: ����POC��Tagֵ(����)
 *
 * @param psTag: Tag
 * @param iPos: �����±�
 * @param ptVar: Tagֵ
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int POC_ArraySetValue(const char *psTag, int iPos, T_POC_VALUE *ptVar);

/**
 * @function: POC_ArrayGetPos
 *
 * @desc: ȡ��ָ���±������Tag
 *
 * @param psTag: Tag
 * @param iPos: �����±�
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int POC_ArrayGetPos(const char *psTag, int iPos);

/**
 * @function: POC_ArraySetPos
 *
 * @desc: ����ָ���±������Tag
 *
 * @param psTag: Tag
 * @param iPos: �����±�
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int POC_ArraySetPos(const char *psTag, int iPos);

/**
 * @function: POC_ArrayCount
 *
 * @desc: ��ȡPOC������Tag������������
 *
 * @param psTag: Tag
 *
 * @return int: ret=0 ����; ret<0 ʧ��
 *
 */
int POC_ArrayCount(const char *psTag);

#ifdef __cplusplus
}
#endif

#endif /*_POC_OBJECT_H_20101105093013_*/
/*-----------------------------  End ------------------------------------*/
