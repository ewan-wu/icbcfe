/*
 *
 *
 * datasource interface define.
 *
 *
 * FileName: poc_datasource.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _POC_DATASOURCE_H_20101105092904_
#define _POC_DATASOURCE_H_20101105092904_
/*--------------------------- Include files -----------------------------*/
#include "core_ctx.h"
#include "poc_object.h"

/*--------------------------- Macro define ------------------------------*/
#define DLEN_POC_DATASOURCE_NAME 256
#define DLEN_POC_DATASOURCE_ARGC_MAX 20
#define DLEN_POC_DATASOURCE_ARGS_MAX 1024

#define VAR_POC_DATASOURCE_VER_0 0
#define VAR_POC_DATASOURCE_VER_1 1

/*---------------------------- Type define ------------------------------*/
struct T_POC_ITERATOR_T;

typedef void* T_POC_OBJECT_HANDLE;

typedef struct {
    int iArgc;
    char *psArgV[DLEN_POC_DATASOURCE_ARGC_MAX];
    char sArgs[DLEN_POC_DATASOURCE_ARGS_MAX];
} T_DATASOURCE_ARG;

typedef T_POC_OBJECT_HANDLE (*PFN_POC_DATASOURCE_OBJECTNEW)(char *psObjName, T_DATASOURCE_ARG *ptInitParams, int iOptions);
typedef int (*PFN_POC_DATASOURCE_OBJECTDEL)(T_POC_OBJECT_HANDLE hObjHdl, int iOptions);

typedef T_POC_VALUE * (*PFN_POC_DATASOURCE_GETVALUE)(T_POC_OBJECT_HANDLE hObjHdl, char *psTag, T_POC_VALUE *ptVar);
typedef int (*PFN_POC_DATASOURCE_SETVALUE)(T_POC_OBJECT_HANDLE hObjHdl, char *psTag, T_POC_VALUE *ptVar);

typedef T_POC_VALUE * (*PFN_POC_DATASOURCE_ARRAY_GETVALUE)(T_POC_OBJECT_HANDLE hObjHdl, int iPos, char *psTag, T_POC_VALUE *ptVar);
typedef int (*PFN_POC_DATASOURCE_ARRAY_SETVALUE)(T_POC_OBJECT_HANDLE hObjHdl, int iPos, char *psTag, T_POC_VALUE *ptVar);
typedef int (*PFN_POC_DATASOURCE_ARRAY_COUNT)(T_POC_OBJECT_HANDLE hObjHdl, char *psTag);

typedef int (*PFN_POC_DATASOURCE_ARRAY_GETPOS)(T_POC_OBJECT_HANDLE hObjHdl, int iPos, char *psTag, char *psTagFull, int iOptions);
typedef int (*PFN_POC_DATASOURCE_ARRAY_SETPOS)(T_POC_OBJECT_HANDLE hObjHdl, int iPos, char *psTag, char *psTagFull, int iOptions);

typedef int (*PFN_POC_DATASOURCE_OBJCTL)(T_POC_OBJECT_HANDLE hObjHdl, char *psTag, T_DATASOURCE_ARG *ptValues);

typedef int (*PFN_POC_DATASOURCE_GETERROR)(char *psError);

typedef int (*PFN_POC_DATASOURCE_TAGTYPE)(T_POC_OBJECT_HANDLE hObjHdl, char *psTag,  char *psValue);

/*Reflection interfaces*/
typedef int (*PFN_POC_DATASOURCE_ATTRITER_BEGIN)(T_POC_OBJECT_HANDLE hObjHdl, struct T_POC_ITERATOR_T *ptIter);
typedef int (*PFN_POC_DATASOURCE_ATTRITER)(T_POC_OBJECT_HANDLE hObjHdl, struct T_POC_ITERATOR_T *ptIter,  char *psValue);
typedef int (*PFN_POC_DATASOURCE_ATTRITER_END)(T_POC_OBJECT_HANDLE hObjHdl, struct T_POC_ITERATOR_T *ptIter);

typedef struct {
    /*ver:0*/
    int iVer;
    char sName[DLEN_POC_DATASOURCE_NAME];

    PFN_POC_DATASOURCE_OBJECTNEW pfnNew;
    PFN_POC_DATASOURCE_OBJECTDEL pfnDel;

    PFN_POC_DATASOURCE_SETVALUE pfnSetValue;
    PFN_POC_DATASOURCE_GETVALUE pfnGetValue;

    PFN_POC_DATASOURCE_ARRAY_SETVALUE pfnArraySetValue;
    PFN_POC_DATASOURCE_ARRAY_GETVALUE pfnArrayGetValue;
    PFN_POC_DATASOURCE_ARRAY_COUNT pfnArrayCount;

    PFN_POC_DATASOURCE_OBJCTL pfnCtl;

    PFN_POC_DATASOURCE_GETERROR pfnGetError;
    
    /*ver: 1*/
    PFN_POC_DATASOURCE_ARRAY_GETPOS pfnArraySetPos;
    PFN_POC_DATASOURCE_ARRAY_SETPOS pfnArrayGetPos;
    
    PFN_POC_DATASOURCE_TAGTYPE pfnTagType;
    
    PFN_POC_DATASOURCE_ATTRITER_BEGIN pfnAttrIterBegin;
    PFN_POC_DATASOURCE_ATTRITER pfnAttrIter;
    PFN_POC_DATASOURCE_ATTRITER_END pfnAttrIterEnd;
    
} T_POC_DATASOURCE;

typedef struct {
    int iVer;
    PFN_RTCORE_LOGPRINT pfnLogPrint;
    int iOptions;
} T_POC_DATASOURCE_CRTCTX_OPTS;

typedef int (*PFN_POC_DATASOURCE_CREATECTX)(T_POC_DATASOURCE *ptDataSource, T_POC_DATASOURCE_CRTCTX_OPTS *ptCrtCtxOpts, T_DATASOURCE_ARG *ptInitParams);
typedef int (*PFN_POC_DATASOURCE_RELEASECTX)(int iOptions);

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_POC_DATASOURCE_H_20101105092904_*/
/*-----------------------------  End ------------------------------------*/
