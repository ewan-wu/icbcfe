/*
 *
 *
 * for http server.
 *
 *
 * FileName: net_http_server.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _NET_HTTP_SERVER_H_20110621091646_
#define _NET_HTTP_SERVER_H_20110621091646_
/*--------------------------- Include files -----------------------------*/
#include "net_tcp_def.h"
#include "net_http_def.h"
#include "net_tcp_server.h"

/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/
struct T_NET_HTTP_SERVER_S;

typedef int (*PFN_NET_HTTP_SERVER_GET_REQHDR)(struct T_NET_HTTP_SERVER_S *this, int iOptions);
typedef int (*PFN_NET_HTTP_SERVER_GET_CONTENT)(struct T_NET_HTTP_SERVER_S *this, char *psBuf, int *piLen, int iOptions);

typedef int (*PFN_NET_HTTP_SERVER_SEND_RESHDR)(struct T_NET_HTTP_SERVER_S *this, int iOptions);
typedef int (*PFN_NET_HTTP_SERVER_SEND_CONTTENT)(struct T_NET_HTTP_SERVER_S *this, char *psBuf, int iLen, int iOptions);


typedef struct T_NET_HTTP_SERVER_S{
    T_NET_TCPSERVER *ptTcpServer;
    T_NET_HTTP_REQUEST *ptReq;
    T_NET_HTTP_RESPONSE *ptRes;

    PFN_NET_HTTP_SERVER_GET_REQHDR pfnGetReqHdr;
    PFN_NET_HTTP_SERVER_GET_CONTENT pfnGetContent;

    PFN_NET_HTTP_SERVER_SEND_RESHDR pfnSndResHdr;
    PFN_NET_HTTP_SERVER_SEND_CONTTENT pfnSndContent;
    PFN_NET_TCP_LOGPRINT pfnLogPrint;
} T_NET_HTTP_SERVER;
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @function: netHttpSeverCreate
 *
 * @desc: ����TCPSERVER����
 *
 * @param ptServer: tcpserver����
 * @param pfnLogPrint: ��־����
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int netHttpSeverCreate(T_NET_HTTP_SERVER * ptServer,
                       PFN_NET_TCP_LOGPRINT pfnLogPrint);

#ifdef __cplusplus
}
#endif

#endif /*_NET_HTTP_SERVER_H_20110621091646_*/
/*-----------------------------  End ------------------------------------*/
