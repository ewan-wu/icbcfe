/*
 *
 * 
 * global type define.
 * 
 * 
 * FileName: glb_def.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _GLB_DEF_H_20100107091813_
#define _GLB_DEF_H_20100107091813_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/
/*-------------------------*/
/*IPC ͷֵ����*/
/*-------------------------*/
#define GLB_IPC_PKGTYPE_BIZ '1'     /*ҵ����*/
#define GLB_IPC_PKGTYPE_INNER '2'   /*ϵͳ�ڲ�����*/

#define GLB_IPC_STORETYPE_MEM '1'   /*�ڴ淽ʽ*/
#define GLB_IPC_STORETYPE_FILE '2'  /*�ļ���ʽ*/

/*-------------------------*/
/*�ӽ�����Կ����*/
/*-------------------------*/
#define GLB_KEY ((unsigned char *)	\
	"\xA1\x96\xD4\x5D\xDC\x27\x68\x52\xF6\x27\x84\x40\xA8\x54\x10\x7A\x63\x66\x1A\xFA\xD8\x39\x8D\x26")

#define GLB_KEY_LEN 24

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_GLB_DEF_H_20100107091813_*/
/*-----------------------------  End ------------------------------------*/
