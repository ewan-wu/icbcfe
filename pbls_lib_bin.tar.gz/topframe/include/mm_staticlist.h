/*
 *
 * 
 * -mmemmgr for static mem list.
 * 
 * 
 * FileName: mm_staticlist.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _MM_STATICLIST_H_20110608111612_
#define _MM_STATICLIST_H_20110608111612_
/*--------------------------- Include files -----------------------------*/
#include "core_ctx.h"

/*--------------------------- Macro define ------------------------------*/
/*options*/
#define OPT_MM_SML_ALLOC_NO_CHUNKED 0x01

/*error code*/
#define ERR_MM_SML_OK 0

#define ERR_MM_SML_BASE (-2000)
#define ERR_MM_SML_NOTFOUND (ERR_MM_SML_BASE-1)
#define ERR_MM_SML_INIT (ERR_MM_SML_BASE-2)
#define ERR_MM_SML_PARAM (ERR_MM_SML_BASE-3)
#define ERR_MM_SML_HANDLE (ERR_MM_SML_BASE-4)
#define ERR_MM_SML_SPACE (ERR_MM_SML_BASE-5)
#define ERR_MM_SML_STAT (ERR_MM_SML_BASE-6)
#define ERR_MM_SML_UNKNOW (ERR_MM_SML_BASE-500)

/*---------------------------- Type define ------------------------------*/
typedef int T_MM_SML_HANDLE_BUF;
typedef int T_MM_SML_CUR;

typedef struct {
    int iOptions;
    PFN_RTCORE_LOGPRINT pfnLog;
} T_MM_SML_CTX_OPT;
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


/**
 * @function: mmSmlCreateCtx
 *
 * @desc: 
 *
 * @param ptOpt: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmSmlCreateCtx(T_MM_SML_CTX_OPT *ptOpt);


/**
 * @function: mmSmlFormat
 *
 * @desc: 
 *
 * @param pMem: 
 * @param iMemSize: 
 * @param iChunkSize: 
 * @param iOptions: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmSmlFormat(void *pMem, int iMemSize, int iChunkSize, int iOptions);

/**
 * @function: mmSmlCheck
 *
 * @desc: 
 *
 * @param pMem: 
 * @param iOptions: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmSmlCheck(void *pMem, int iOptions);


/**
 * @function: mmSmlAlloc
 *
 * @desc: 
 *
 * @param pMem: 
 * @param iSize: 
 * @param iOptions: 
 *
 * @return T_MM_SML_HANDLE_BUF : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
T_MM_SML_HANDLE_BUF mmSmlAlloc(void *pMem, int iSize, int iOptions);

/**
 * @function: mmSmlRealloc
 *
 * @desc: 
 *
 * @param pMem: 
 * @param hBuf: 
 * @param iSize: 
 * @param iOptions: 
 *
 * @return T_MM_SML_HANDLE_BUF : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
T_MM_SML_HANDLE_BUF mmSmlRealloc(void *pMem, T_MM_SML_HANDLE_BUF hBuf, int iSize, int iOptions);

/**
 * @function: mmSmlFree
 *
 * @desc: 
 *
 * @param pMem: 
 * @param hBuf: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmSmlFree(void *pMem, T_MM_SML_HANDLE_BUF hBuf);


/**
 * @function: mmSmlPreCaleChunkNum
 *
 * @desc: 
 *
 * @param iMemSize: 
 * @param iChunkSize: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmSmlPreCaleChunkNum(int iMemSize, int iChunkSize);

/**
 * @function: mmSmlPreCaleMemSize
 *
 * @desc: 
 *
 * @param iChunkSize: 
 * @param iChunkNum: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmSmlPreCaleMemSize(int iChunkSize, int iChunkNum);


/**
 * @function: mmSmlHdl2Addr
 *
 * @desc: 
 *
 * @param pMem: 
 * @param hBuf: 
 *
 * @return void * : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
void * mmSmlHdl2Addr(void *pMem, T_MM_SML_HANDLE_BUF hBuf);

/**
 * @function: mmSmlGetSize
 *
 * @desc: 
 *
 * @param pMem: 
 * @param hBuf: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmSmlGetSize(void *pMem, T_MM_SML_HANDLE_BUF hBuf);


/**
 * @function: mmSmlCopy2ML
 *
 * @desc: 
 *
 * @param pMem: 
 * @param pBuf: 
 * @param iBufLen: 
 * @param hBuf: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmSmlCopy2ML(void *pMem, void *pBuf, int iBufLen, T_MM_SML_HANDLE_BUF hBuf);

/**
 * @function: mmSmlCopy2Buf
 *
 * @desc: 
 *
 * @param pMem: 
 * @param hBuf: 
 * @param pBuf: 
 * @param iBufLen: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmSmlCopy2Buf(void *pMem, T_MM_SML_HANDLE_BUF hBuf, void *pBuf, int iBufLen);


/**
 * @function: mmSmlCurOpen
 *
 * @desc: 
 *
 * @param pMem: 
 * @param pCur: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmSmlCurOpen(char *pMem, T_MM_SML_CUR *pCur);

/**
 * @function: mmSmlCurFetch
 *
 * @desc: 
 *
 * @param pMem: 
 * @param pCur: 
 *
 * @return T_MM_SML_HANDLE_BUF : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
T_MM_SML_HANDLE_BUF mmSmlCurFetch(char *pMem, T_MM_SML_CUR *pCur);

/**
 * @function: mmSmlCurClose
 *
 * @desc: 
 *
 * @param pMem: 
 * @param pCur: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmSmlCurClose(char *pMem, T_MM_SML_CUR *pCur);


/**
 * @function: mmSmlGetFree
 *
 * @desc: 
 *
 * @param pMem: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmSmlGetFree(void *pMem);

/**
 * @function: mmSmlGetUsed
 *
 * @desc: 
 *
 * @param pMem: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmSmlGetUsed(void *pMem);

/**
 * @function: mmSmlGetTotal
 *
 * @desc: 
 *
 * @param pMem: 
 *
 * @return int : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int mmSmlGetTotal(void *pMem);

/**
 * @function: mmSmlGetError
 *
 * @desc: 
 *
 *
 * @return char * : 
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
char * mmSmlGetError(void);

#ifdef __cplusplus
}
#endif

#endif /*_MM_STATICLIST_H_20110608111612_*/
/*-----------------------------  End ------------------------------------*/
