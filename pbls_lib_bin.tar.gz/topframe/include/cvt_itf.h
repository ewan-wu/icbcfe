#ifndef _CVT_ITF_H
#define _CVT_ITF_H

/*------------------------ Include files ------------------------*/

/*--------------------- Macro define ----------------------------*/
#define CVT_INTERFACE_VERSION 1
#define CVT_INTERFACE_NAME    "CVT_INTERFACE"

/*--------------------- Type define -----------------------------*/
typedef struct InnerMessage *InMessagePtr;
typedef struct Value *ValuePtr;

typedef struct cvtInterface {
    int          (*FncCvtInit)(char *psFileName);
    int          (*FncCvtEnd)();
    InMessagePtr (*FncCvtInitMessasge)(char *psMessageId, char * psFormatId, char *psBuf, int nBufLen, int *pnError);
    InMessagePtr (*FncCvtGenerateMessasge)(InMessagePtr ptSourceMessage, char *psCvtFormatId, char *psBuf, int *pnBufLen, int *pnError);
    InMessagePtr (*FncCvtParseMessasge)(char * psFormatId, char *psBuf, int nBufLen, int * pnError);
    ValuePtr     (*FncCvtGetNameValue)(InMessagePtr ptMessage, char *psValueName, int *pnError);
    int          (*FncCvtSetNameValue)(InMessagePtr ptMessage, char * psFieldName, char *psValue, int nLen);
    InMessagePtr (*FncCvtNewMessage)(char *psMsgId, char *psMsgType, int *pnError);
    int          (*FncCvtGenMessage)(InMessagePtr ptMsg, char *psOutBuf, int *pnOutBufLen);
    int          (*FncCvtFreeMessage)(InMessagePtr ptMessage);
    int          (*FncCvtSetLoopTime)(InMessagePtr ptMsg, char *psLoopName, int nLoopTime);
    int          (*FncCvtGetLoopTime)(InMessagePtr ptMsg, char *psLoopName);
    int          (*FncCvtAddLoopTime)(InMessagePtr ptMsg, char *psLoopName);
} cvtInterface;

/*--------------------- Global function declaration -------------*/
#ifdef __cplusplus	
extern "C" {	
#endif	
    
#ifdef __cplusplus	
}
#endif

#endif /* _CVT_ITF_H */
