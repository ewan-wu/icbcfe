/*
 *
 *
 * functions datasource for poc.
 *
 *
 * FileName: poc_datasource_funs.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _POC_DATASOURCE_FUNS_H_20110504163522_
#define _POC_DATASOURCE_FUNS_H_20110504163522_
/*--------------------------- Include files -----------------------------*/
#include "poc_itf.h"
/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @function: POC_Datasource4FunsCreateCTX
 *
 * @desc: ��������poc����Դ����
 *
 * @param ptDataSource: ����Դ
 * @param ptCrtCtxOpts: ����ѡ��
 * @param ptInitParams: ����Դ��ʼ������
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int POC_Datasource4FunsCreateCTX(T_POC_DATASOURCE *ptDataSource, T_POC_DATASOURCE_CRTCTX_OPTS *ptCrtCtxOpts, T_DATASOURCE_ARG *ptInitParams);

/**
 * @function: POC_Datasource4FunsReleaseCTX
 *
 * @desc: �ͷź���poc����Դ����
 *
 * @param iOptions: ѡ��
 *
 * @return int: ret=0 �ɹ�; ret<0 ʧ��
 *
 */
int POC_Datasource4FunsReleaseCTX(int iOptions);

#ifdef __cplusplus
}
#endif

#endif /*_POC_DATASOURCE_FUNS_H_20110504163522_*/
/*-----------------------------  End ------------------------------------*/
