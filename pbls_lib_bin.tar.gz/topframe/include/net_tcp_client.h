/*
 *
 *
 * tcp client functions.
 *
 *
 * FileName: net_tcp_client.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _NET_TCP_CLIENT_H_20100408163005_
#define _NET_TCP_CLIENT_H_20100408163005_
/*--------------------------- Include files -----------------------------*/
#include "openssl/ssl.h"
#include "openssl/err.h"
#include "openssl/dh.h"
#include "net_tcp_def.h"
#include "log_info.h"

/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/
typedef int (*PFN_NET_TCPCONNECT)(void *this, char *psAddr, int iPort, int iOptions);

typedef struct {
    int iRcvTimeOut;
    int iSndTimeOut;
    char sCaFile[DLEN_NET_TCP_FILENAME];
    char sCertFile[DLEN_NET_TCP_FILENAME];
    char sKeyFile[DLEN_NET_TCP_FILENAME];
    char sKeyPass[DLEN_NET_TCP_FILENAME];
    
    /*ֻ������*/
    int iSocketNo;
    char sLocalAddr[DLEN_NET_TCP_FILENAME];
    int iLocalPort;
    char sRemoteAddr[DLEN_NET_TCP_FILENAME];
    int iRemotePort;
    int iIsSSL;
    char sErrorStr[DLEN_NET_TCP_ERRORSTR];
    int iErrorCode;
    int iStat;
    int iSockOpt;
    /*SSL*/
    SSL* ssl;
    SSL_CTX *ctx;
    
    /*����*/
    PFN_NET_TCPOBJINIT pfnInit;
    PFN_NET_TCPCONNECT pfnConnect;
    PFN_NET_TCPWRITE pfnWrite;
    PFN_NET_TCPREAD pfnRead;
    PFN_NET_TCPOBJCLOSE pfnClose;
    PFN_NET_TCP_LOGPRINT pfnLogPrint;
} T_NET_TCPCLIENT;

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @function: netTcpClientCreate
 *
 * @desc: ����TCP CLIENT ����
 *
 * @param ptTcpClient: ����ָ��
 * @param pfnLogPrint: ��־����
 *
 * @return int : 0:�ɹ�, <0:����
 *
 * @comment:
 *
 *
 *
 * @sample:
 *
 *
 */
int netTcpClientCreate(T_NET_TCPCLIENT * ptTcpClient, PFN_NET_TCP_LOGPRINT pfnLogPrint);

#ifdef __cplusplus
}
#endif

#endif /*_NET_TCP_CLIENT_H_20100408163005_*/
/*-----------------------------  End ------------------------------------*/
