/*
 *
 * 
 * ipc struct.
 * 
 * 
 * FileName: glb_ipc.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _GLB_IPC_H_20100107092708_
#define _GLB_IPC_H_20100107092708_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/
#define DLEN_GLB_TXNNO 8
#define DLEN_GLB_PKGID 32
#define DLEN_GLB_PKGLEN 8
#define DLEN_GLB_STORETYPE 1
#define DLEN_GLB_PKGFMT 2
#define DLEN_GLB_BANKNO 12
#define DLEN_GLB_BRNO 12
#define DLEN_GLB_EXTOPTION 32

/*Ĭ������ڴ汨���峤��2M*/
#define DLEN_GLB_MAX_SMSGBUF 1024*1024*5

/*---------------------------- Type define ------------------------------*/
/*ϵͳ����ͷ*/
typedef struct {
    char sTxnno[DLEN_GLB_TXNNO];          /*���׺�*/
    char sPkgId[DLEN_GLB_PKGID];          /*���ı�ʾ*/
    char cRouteOption;                    /*·��ѡ��*/
    char cPkgType;                        /*��������*/
    char sPkgLen[DLEN_GLB_PKGLEN];        /*���ĳ���*/
    char cStoreType;                      /*�洢����*/
    char sPkgFmt[DLEN_GLB_PKGFMT];        /*���ĸ�ʽ*/
    char sBankNo[DLEN_GLB_BANKNO];        /*�к�*/
    char sBrno[DLEN_GLB_BRNO];            /*�����к�*/
    char sExtOption[DLEN_GLB_EXTOPTION];  /*����ѡ��*/
} T_GLB_IPCHDR;

/*�ڲ����ĸ�ʽ*/
typedef struct {
    T_GLB_IPCHDR tGlbIpcHdr;
    char sMsgBuf[DLEN_GLB_MAX_SMSGBUF];
} T_GLB_IPCMSG;
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_GLB_IPC_H_20100107092708_*/
/*-----------------------------  End ------------------------------------*/
