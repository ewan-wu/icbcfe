/*
 *
 * 
 * topmq channel module.
 * 
 * 
 * FileName: topmq_chl.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _TOPMQ_CHL_H_20100119162934_
#define _TOPMQ_CHL_H_20100119162934_
/*--------------------------- Include files -----------------------------*/
#include "topmq_def.h"

/*--------------------------- Macro define ------------------------------*/
#define ERR_TOPMQ_CHL_MSGCONENT (-200)
#define ERR_TOPMQ_CHL_NETCLOSED (-201)

#define DLEN_TOPMQ_CHL_HDR_PKG 8
#define DLEN_TOPMQ_CHL_HDR_VER 2
#define DLEN_TOPMQ_CHL_HDR_SEQ 8
#define DLEN_TOPMQ_CHL_HDR_MSGTYPE 1
#define DLEN_TOPMQ_CHL_IPC_MSGTYPE 8

#define TOPMQ_CHL_HDR_MSGTYPE_NOR '0'
#define TOPMQ_CHL_HDR_MSGTYPE_BIND '1'
#define TOPMQ_CHL_HDR_MSGTYPE_HB '2'
#define TOPMQ_CHL_HDR_MSGTYPE_SYNC '3'
#define TOPMQ_CHL_HDR_MSGTYPE_FILEMSG '4'

#define TOPMQ_CHL_HDR_DEFAULT {'0','0','0','0','0','0','7','5'},\
                                {'0','1'},\
                                {'0','0','0','0','0','0','0','0'},\
                                {TOPMQ_CHL_HDR_MSGTYPE_NOR},\
                                {""},\
                                {'0','0','0','0','0','0','0','0'},\
                                {'0','0','0','0','0','0','0','0'},\
                                {'0','0','0','0','0','0','0','0'}
/*---------------------------- Type define ------------------------------*/
typedef struct {
    char sHdrLen[DLEN_TOPMQ_CHL_HDR_PKG];
    char sVer[DLEN_TOPMQ_CHL_HDR_VER];
    char sSeqno[DLEN_TOPMQ_CHL_HDR_SEQ];
    char sMsgType[DLEN_TOPMQ_CHL_HDR_MSGTYPE];
    char sDestQue[DLEN_TOPMQ_OBJECT_NAME];
    char sIPCMsgType[DLEN_TOPMQ_CHL_IPC_MSGTYPE];
    char sIPCMsgCode[DLEN_TOPMQ_CHL_IPC_MSGTYPE];
    char sPkgLen[DLEN_TOPMQ_CHL_HDR_PKG];
} T_TOPMQ_CHL_HDR;

typedef struct  {
    char sMsgId[DLEN_TOPMQ_API_MSGID];               /*��ϢΨһID*/
    char sCorrelId[DLEN_TOPMQ_API_CORRELID];         /*�����ID*/
    char cMsgStoreType;                              /*���Ĵ洢��ʽ*/
        
    int  iUsage;                                     /*��Ϣ��;*/
    int  iMsgFlags;                                  /*��Ϣ��־��*/
    int  iExpiry;                                    /*��ʱʱ��*/
    int  iFeedback;                                  /*���ر�־*/
    int  iEncoding;                                  /*����*/
    int  iCodedCharSetId;                            /*�ַ���ʶ���*/
    int  iPriority;                                  /*���ȼ�*/
    int  iPersistence;                               /*�־��Ա�־*/
    int  iMsgSeqNo;                                  /*��Ϣ���*/
    int  iReportOpt;                                 /*�ظ���Ϣѡ��*/
    char sFmtName[DLEN_TOPMQ_API_FMT+1];             /*��ʽ����*/
    char sReplyToQ[DLEN_TOPMQ_API_OBJNAME+1];        /*�ظ�������*/
    char sReplyToQMgr[DLEN_TOPMQ_API_OBJNAME+1];     /*�ظ����й�������*/
    char sGroupId[DLEN_TOPMQ_API_MSGID];             /*��Ϣ��Id*/
    int  iPutApplType;                               /*Ӧ������*/
    char sPutApplName[DLEN_TOPMQ_OBJECT_NAME+1];     /*������Ϣ��������*/
    char sPutDate[DLEN_TOPMQ_API_DATE+1];            /*������Ϣ����*/
    char sPutTime[DLEN_TOPMQ_API_TIME+1];            /*������Ϣʱ��*/
} T_TOPMQ_CHL_MD;

typedef struct {
    char sNum[DLEN_TOPMQ_LEN];
    char sLen[DLEN_TOPMQ_LEN];
} T_TOPMQ_CHL_ACCS_HDR;

typedef struct {
    char sLen[DLEN_TOPMQ_LEN];
    char sFlags[DLEN_TOPMQ_FLAGS];
    char sMac[DLEN_TOPMQ_MAC];
} T_TOPMQ_CHL_ACC_HDR;
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_TOPMQ_CHL_H_20100119162934_*/
/*-----------------------------  End ------------------------------------*/
