/*
 *
 * 
 * topmq queue manager.
 * 
 * 
 * FileName: topmq_qmgr.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _TOPMQ_QMGR_H_20100129164924_
#define _TOPMQ_QMGR_H_20100129164924_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_TOPMQ_QMGR_H_20100129164924_*/
/*-----------------------------  End ------------------------------------*/
