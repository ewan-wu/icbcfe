/*
 *
 * 
 * define topmq c api functions and types.
 * 
 * 
 * FileName: topmq_api.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _TOPMQ_API_H_20100125165150_
#define _TOPMQ_API_H_20100125165150_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/
#if defined(__powerpc64__) || defined(__x86_64__) || defined(__ia64__) || defined(__s390x__)
  #define TOPMQ_64_BIT
#endif

#define DLEN_TOPMQ_API_OBJNAME 32
#define DLEN_TOPMQ_API_MSGID 32
#define DLEN_TOPMQ_API_CORRELID DLEN_TOPMQ_API_MSGID
#define DLEN_TOPMQ_API_FMT 8
#define DLEN_TOPMQ_API_DATE 8
#define DLEN_TOPMQ_API_TIME 6
#define DLEN_TOPMQ_API_TIME2 9
#define DLEN_TOPMQ_API_DATETIME (DLEN_TOPMQ_API_DATE+DLEN_TOPMQ_API_TIME)
#define DLEN_TOPMQ_API_DATETIME2 (DLEN_TOPMQ_API_DATE+DLEN_TOPMQ_API_TIME2)
#define DLEN_TOPMQ_API_ACCESSORIES_FILE_NUM_MAX 30
#define DLEN_TOPMQ_API_ACCESSORIES_FILENAME_MAX 512


#define TOPMQ_API_OBJTYPE_QUE 0

/*return code*/
#define ERR_TOPMQ_RET_OK      0
#define ERR_TOPMQ_RET_WARNING 1
#define ERR_TOPMQ_RET_FAILED -1
#define ERR_TOPMQ_RET_UNKNOWN -2
 
/*reason code*/
#define ERR_TOPMQ_RC_NONE                      0                         /*�޴���*/
#define ERR_TOPMQ_RC_UNKWON_ERROR              1                         /*δ֪����*/
#define ERR_TOPMQ_RC_APPL_FIRST                900                       /*��һ��*/
#define ERR_TOPMQ_RC_APPL_LAST                 999                       /*���һ��*/
#define ERR_TOPMQ_RC_ALIAS_BASE_Q_TYPE_ERROR   2001                      /*�������ʹ���*/
#define ERR_TOPMQ_RC_ALREADY_CONNECTED         2002                      /*������*/
#define ERR_TOPMQ_RC_BACKED_OUT                2003                      /**/
#define ERR_TOPMQ_RC_BUFFER_ERROR              2004                      /*�������*/
#define ERR_TOPMQ_RC_BUFFER_LENGTH_ERROR       2005                      /*���泤�ȴ���*/
#define ERR_TOPMQ_RC_CHAR_ATTR_LENGTH_ERROR    2006                      /**/
#define ERR_TOPMQ_RC_CHAR_ATTRS_ERROR          2007                      /**/
#define ERR_TOPMQ_RC_CHAR_ATTRS_TOO_SHORT      2008                      /**/
#define ERR_TOPMQ_RC_CONNECTION_BROKEN         2009                      /*���Ӵ��*/
#define ERR_TOPMQ_RC_DATA_LENGTH_ERROR         2010                      /*���ݳ��ȴ���*/
#define ERR_TOPMQ_RC_DYNAMIC_Q_NAME_ERROR      2011                      /**/
#define ERR_TOPMQ_RC_ENVIRONMENT_ERROR         2012                      /*��������*/
#define ERR_TOPMQ_RC_EXPIRY_ERROR              2013                      /*��ʱ*/
#define ERR_TOPMQ_RC_FEEDBACK_ERROR            2014                      /**/
#define ERR_TOPMQ_RC_GET_INHIBITED             2016                      /**/
#define ERR_TOPMQ_RC_HANDLE_NOT_AVAILABLE      2017                      /**/
#define ERR_TOPMQ_RC_HCONN_ERROR               2018                      /*���Ӿ������*/
#define ERR_TOPMQ_RC_HOBJ_ERROR                2019                      /*����������*/
#define ERR_TOPMQ_RC_INHIBIT_VALUE_ERROR       2020                      /**/
#define ERR_TOPMQ_RC_INT_ATTR_COUNT_ERROR      2021                      /**/
#define ERR_TOPMQ_RC_INT_ATTR_COUNT_TOO_SMALL  2022                      /**/
#define ERR_TOPMQ_RC_INT_ATTRS_ARRAY_ERROR     2023                      /**/
#define ERR_TOPMQ_RC_SYNCPOINT_LIMIT_REACHED   2024                      /**/
#define ERR_TOPMQ_RC_MAX_CONNS_LIMIT_REACHED   2025                      /*�ﵽ���������*/
#define ERR_TOPMQ_RC_MD_ERROR                  2026                      /*��Ϣ����������*/
#define ERR_TOPMQ_RC_MISSING_REPLY_TO_Q        2027                      /*û������reply to q*/
#define ERR_TOPMQ_RC_MSG_TYPE_ERROR            2029                      /*��Ϣ���ʹ���*/
#define ERR_TOPMQ_RC_MSG_TOO_BIG_FOR_Q         2030                      /*��Ϣ̫��*/
#define ERR_TOPMQ_RC_MSG_TOO_BIG_FOR_Q_MGR     2031                      /*��Ϣ̫��*/
#define ERR_TOPMQ_RC_NO_MSG_AVAILABLE          2033                      /*������û����Ϣ*/
#define ERR_TOPMQ_RC_NO_MSG_UNDER_CURSOR       2034                      /**/
#define ERR_TOPMQ_RC_NOT_AUTHORIZED            2035                      /*û����Ȩ*/
#define ERR_TOPMQ_RC_NOT_OPEN_FOR_BROWSE       2036                      /**/
#define ERR_TOPMQ_RC_NOT_OPEN_FOR_INPUT        2037                      /**/
#define ERR_TOPMQ_RC_NOT_OPEN_FOR_INQUIRE      2038                      /**/
#define ERR_TOPMQ_RC_NOT_OPEN_FOR_OUTPUT       2039                      /**/
#define ERR_TOPMQ_RC_NOT_OPEN_FOR_SET          2040                      /**/
#define ERR_TOPMQ_RC_OBJECT_CHANGED            2041                      /*�����ѱ��*/
#define ERR_TOPMQ_RC_OBJECT_IN_USE             2042                      /*��������ʹ����*/
#define ERR_TOPMQ_RC_OBJECT_TYPE_ERROR         2043                      /*�������ʹ���*/
#define ERR_TOPMQ_RC_OD_ERROR                  2044                      /*��������������*/
#define ERR_TOPMQ_RC_OPTION_NOT_VALID_FOR_TYPE 2045                      /**/
#define ERR_TOPMQ_RC_OPTIONS_ERROR             2046                      /*ѡ�����*/
#define ERR_TOPMQ_RC_PERSISTENCE_ERROR         2047                      /**/
#define ERR_TOPMQ_RC_PERSISTENT_NOT_ALLOWED    2048                      /**/
#define ERR_TOPMQ_RC_PRIORITY_EXCEEDS_MAXIMUM  2049                      /**/
#define ERR_TOPMQ_RC_PRIORITY_ERROR            2050                      /**/
#define ERR_TOPMQ_RC_PUT_INHIBITED             2051                      /**/
#define ERR_TOPMQ_RC_Q_DELETED                 2052                      /*������ɾ��*/
#define ERR_TOPMQ_RC_Q_FULL                    2053                      /*��������*/
#define ERR_TOPMQ_RC_Q_NOT_EMPTY               2055                      /*���зǿ�*/
#define ERR_TOPMQ_RC_Q_SPACE_NOT_AVAILABLE     2056                      /*�ռ䲻��*/
#define ERR_TOPMQ_RC_Q_TYPE_ERROR              2057                      /*�������ʹ���*/
#define ERR_TOPMQ_RC_Q_MGR_NAME_ERROR          2058                      /*���й��������ִ���*/
#define ERR_TOPMQ_RC_Q_MGR_NOT_AVAILABLE       2059                      /*���й�����������*/
#define ERR_TOPMQ_RC_REPORT_OPTIONS_ERROR      2061                      /**/
#define ERR_TOPMQ_RC_SECOND_MARK_NOT_ALLOWED   2062                      /**/
#define ERR_TOPMQ_RC_SECURITY_ERROR            2063                      /*��ȫ����*/
#define ERR_TOPMQ_RC_SELECTOR_COUNT_ERROR      2065                      /**/
#define ERR_TOPMQ_RC_SELECTOR_LIMIT_EXCEEDED   2066                      /**/
#define ERR_TOPMQ_RC_SELECTOR_ERROR            2067                      /**/
#define ERR_TOPMQ_RC_SELECTOR_NOT_FOR_TYPE     2068                      /**/
#define ERR_TOPMQ_RC_SIGNAL_OUTSTANDING        2069                      /**/
#define ERR_TOPMQ_RC_SIGNAL_REQUEST_ACCEPTED   2070                      /**/
#define ERR_TOPMQ_RC_STORAGE_NOT_AVAILABLE     2071                      /*�洢��Ч*/
#define ERR_TOPMQ_RC_SYNCPOINT_NOT_AVAILABLE   2072                      /**/
#define ERR_TOPMQ_RC_TRIGGER_CONTROL_ERROR     2075                      /**/
#define ERR_TOPMQ_RC_TRIGGER_DEPTH_ERROR       2076                      /**/
#define ERR_TOPMQ_RC_TRIGGER_MSG_PRIORITY_ERR  2077                      /**/
#define ERR_TOPMQ_RC_TRIGGER_TYPE_ERROR        2078                      /**/
#define ERR_TOPMQ_RC_TRUNCATED_MSG_ACCEPTED    2079                      /*��Ϣ����ȡ*/
#define ERR_TOPMQ_RC_TRUNCATED_MSG_FAILED      2080                      /**/
#define ERR_TOPMQ_RC_UNKNOWN_ALIAS_BASE_Q      2082                      /**/
#define ERR_TOPMQ_RC_UNKNOWN_OBJECT_NAME       2085                      /**/
#define ERR_TOPMQ_RC_UNKNOWN_OBJECT_Q_MGR      2086                      /**/
#define ERR_TOPMQ_RC_UNKNOWN_REMOTE_Q_MGR      2087                      /**/
#define ERR_TOPMQ_RC_WAIT_INTERVAL_ERROR       2090                      /**/
#define ERR_TOPMQ_RC_XMIT_Q_TYPE_ERROR         2091                      /*����������ʹ���*/
#define ERR_TOPMQ_RC_XMIT_Q_USAGE_ERROR        2092                      /*���������;����*/
#define ERR_TOPMQ_RC_NOT_OPEN_FOR_PASS_ALL     2093                      /**/
#define ERR_TOPMQ_RC_NOT_OPEN_FOR_PASS_IDENT   2094                      /**/
#define ERR_TOPMQ_RC_NOT_OPEN_FOR_SET_ALL      2095                      /**/
#define ERR_TOPMQ_RC_NOT_OPEN_FOR_SET_IDENT    2096                      /**/
#define ERR_TOPMQ_RC_CONTEXT_HANDLE_ERROR      2097                      /**/
#define ERR_TOPMQ_RC_CONTEXT_NOT_AVAILABLE     2098                      /**/
#define ERR_TOPMQ_RC_SIGNAL1_ERROR             2099                      /**/
#define ERR_TOPMQ_RC_OBJECT_ALREADY_EXISTS     2100                      /*�����Ѵ���*/
#define ERR_TOPMQ_RC_OBJECT_DAMAGED            2101                      /**/
#define ERR_TOPMQ_RC_RESOURCE_PROBLEM          2102                      /**/
#define ERR_TOPMQ_RC_ANOTHER_Q_MGR_CONNECTED   2103                      /**/
#define ERR_TOPMQ_RC_UNKNOWN_REPORT_OPTION     2104                      /**/
#define ERR_TOPMQ_RC_STORAGE_CLASS_ERROR       2105                      /**/
#define ERR_TOPMQ_RC_COD_NOT_VALID_FOR_XCF_Q   2106                      /**/
#define ERR_TOPMQ_RC_XWAIT_CANCELED            2107                      /**/
#define ERR_TOPMQ_RC_XWAIT_ERROR               2108                      /**/
#define ERR_TOPMQ_RC_SUPPRESSED_BY_EXIT        2109                      /**/
#define ERR_TOPMQ_RC_FORMAT_ERROR              2110                      /*��ʽ����*/
#define ERR_TOPMQ_RC_SOURCE_CCSID_ERROR        2111                      /*ԴCCSID����*/
#define ERR_TOPMQ_RC_SOURCE_INTEGER_ENC_ERROR  2112                      /**/
#define ERR_TOPMQ_RC_SOURCE_DECIMAL_ENC_ERROR  2113                      /**/
#define ERR_TOPMQ_RC_SOURCE_FLOAT_ENC_ERROR    2114                      /**/
#define ERR_TOPMQ_RC_TARGET_CCSID_ERROR        2115                      /**/
#define ERR_TOPMQ_RC_TARGET_INTEGER_ENC_ERROR  2116                      /**/
#define ERR_TOPMQ_RC_TARGET_DECIMAL_ENC_ERROR  2117                      /**/
#define ERR_TOPMQ_RC_TARGET_FLOAT_ENC_ERROR    2118                      /**/
#define ERR_TOPMQ_RC_NOT_CONVERTED             2119                      /**/
#define ERR_TOPMQ_RC_CONVERTED_MSG_TOO_BIG     2120                      /**/
#define ERR_TOPMQ_RC_TRUNCATED                 2120                      /*��Ϣ������*/
#define ERR_TOPMQ_RC_NO_EXTERNAL_PARTICIPANTS  2121                      /**/
#define ERR_TOPMQ_RC_PARTICIPANT_NOT_AVAILABLE 2122                      /**/
#define ERR_TOPMQ_RC_OUTCOME_MIXED             2123                      /**/
#define ERR_TOPMQ_RC_OUTCOME_PENDING           2124                      /**/
#define ERR_TOPMQ_RC_BRIDGE_STARTED            2125                      /**/
#define ERR_TOPMQ_RC_BRIDGE_STOPPED            2126                      /**/
#define ERR_TOPMQ_RC_ADAPTER_STORAGE_SHORTAGE  2127                      /**/
#define ERR_TOPMQ_RC_UOW_IN_PROGRESS           2128                      /**/
#define ERR_TOPMQ_RC_ADAPTER_CONN_LOAD_ERROR   2129                      /**/
#define ERR_TOPMQ_RC_ADAPTER_SERV_LOAD_ERROR   2130                      /**/
#define ERR_TOPMQ_RC_ADAPTER_DEFS_ERROR        2131                      /**/
#define ERR_TOPMQ_RC_ADAPTER_DEFS_LOAD_ERROR   2132                      /**/
#define ERR_TOPMQ_RC_ADAPTER_CONV_LOAD_ERROR   2133                      /**/
#define ERR_TOPMQ_RC_BO_ERROR                  2134                      /**/
#define ERR_TOPMQ_RC_DH_ERROR                  2135                      /**/
#define ERR_TOPMQ_RC_MULTIPLE_REASONS          2136                      /**/
#define ERR_TOPMQ_RC_OPEN_FAILED               2137                      /*��ʧ��*/
#define ERR_TOPMQ_RC_ADAPTER_DISC_LOAD_ERROR   2138                      /**/
#define ERR_TOPMQ_RC_CNO_ERROR                 2139                      /**/
#define ERR_TOPMQ_RC_CICS_WAIT_FAILED          2140                      /**/
#define ERR_TOPMQ_RC_DLH_ERROR                 2141                      /**/
#define ERR_TOPMQ_RC_HEADER_ERROR              2142                      /**/
#define ERR_TOPMQ_RC_SOURCE_LENGTH_ERROR       2143                      /**/
#define ERR_TOPMQ_RC_TARGET_LENGTH_ERROR       2144                      /**/
#define ERR_TOPMQ_RC_SOURCE_BUFFER_ERROR       2145                      /**/
#define ERR_TOPMQ_RC_TARGET_BUFFER_ERROR       2146                      /**/
#define ERR_TOPMQ_RC_IIH_ERROR                 2148                      /**/
#define ERR_TOPMQ_RC_PCF_ERROR                 2149                      /**/
#define ERR_TOPMQ_RC_DBCS_ERROR                2150                      /**/
#define ERR_TOPMQ_RC_OBJECT_NAME_ERROR         2152                      /**/
#define ERR_TOPMQ_RC_OBJECT_Q_MGR_NAME_ERROR   2153                      /**/
#define ERR_TOPMQ_RC_RECS_PRESENT_ERROR        2154                      /**/
#define ERR_TOPMQ_RC_OBJECT_RECORDS_ERROR      2155                      /**/
#define ERR_TOPMQ_RC_RESPONSE_RECORDS_ERROR    2156                      /**/
#define ERR_TOPMQ_RC_ASID_MISMATCH             2157                      /**/
#define ERR_TOPMQ_RC_PMO_RECORD_FLAGS_ERROR    2158                      /**/
#define ERR_TOPMQ_RC_PUT_MSG_RECORDS_ERROR     2159                      /**/
#define ERR_TOPMQ_RC_CONN_ID_IN_USE            2160                      /**/
#define ERR_TOPMQ_RC_Q_MGR_QUIESCING           2161                      /**/
#define ERR_TOPMQ_RC_Q_MGR_STOPPING            2162                      /**/
#define ERR_TOPMQ_RC_DUPLICATE_RECOV_COORD     2163                      /**/
#define ERR_TOPMQ_RC_PMO_ERROR                 2173                      /**/
#define ERR_TOPMQ_RC_API_EXIT_NOT_FOUND        2182                      /**/
#define ERR_TOPMQ_RC_API_EXIT_LOAD_ERROR       2183                      /**/
#define ERR_TOPMQ_RC_REMOTE_Q_NAME_ERROR       2184                      /**/
#define ERR_TOPMQ_RC_INCONSISTENT_PERSISTENCE  2185                      /**/
#define ERR_TOPMQ_RC_GMO_ERROR                 2186                      /**/
#define ERR_TOPMQ_RC_CICS_BRIDGE_RESTRICTION   2187                      /**/
#define ERR_TOPMQ_RC_STOPPED_BY_CLUSTER_EXIT   2188                      /**/
#define ERR_TOPMQ_RC_CLUSTER_RESOLUTION_ERROR  2189                      /**/
#define ERR_TOPMQ_RC_CONVERTED_STRING_TOO_BIG  2190                      /**/
#define ERR_TOPMQ_RC_TMC_ERROR                 2191                      /**/
#define ERR_TOPMQ_RC_PAGESET_FULL              2192                      /**/
#define ERR_TOPMQ_RC_STORAGE_MEDIUM_FULL       2192                      /**/
#define ERR_TOPMQ_RC_PAGESET_ERROR             2193                      /**/
#define ERR_TOPMQ_RC_NAME_NOT_VALID_FOR_TYPE   2194                      /**/
#define ERR_TOPMQ_RC_UNEXPECTED_ERROR          2195                      /**/
#define ERR_TOPMQ_RC_UNKNOWN_XMIT_Q            2196                      /**/
#define ERR_TOPMQ_RC_UNKNOWN_DEF_XMIT_Q        2197                      /**/
#define ERR_TOPMQ_RC_DEF_XMIT_Q_TYPE_ERROR     2198                      /**/
#define ERR_TOPMQ_RC_DEF_XMIT_Q_USAGE_ERROR    2199                      /**/
#define ERR_TOPMQ_RC_NAME_IN_USE               2201                      /**/
#define ERR_TOPMQ_RC_CONNECTION_QUIESCING      2202                      /**/
#define ERR_TOPMQ_RC_CONNECTION_STOPPING       2203                      /**/
#define ERR_TOPMQ_RC_ADAPTER_NOT_AVAILABLE     2204                      /**/
#define ERR_TOPMQ_RC_MSG_ID_ERROR              2206                      /**/
#define ERR_TOPMQ_RC_CORREL_ID_ERROR           2207                      /**/
#define ERR_TOPMQ_RC_FILE_SYSTEM_ERROR         2208                      /**/
#define ERR_TOPMQ_RC_NO_MSG_LOCKED             2209                      /**/
#define ERR_TOPMQ_RC_SOAP_DOTNET_ERROR         2210                      /**/
#define ERR_TOPMQ_RC_SOAP_AXIS_ERROR           2211                      /**/
#define ERR_TOPMQ_RC_SOAP_URL_ERROR            2212                      /**/
#define ERR_TOPMQ_RC_FILE_NOT_AUDITED          2216                      /**/
#define ERR_TOPMQ_RC_CONNECTION_NOT_AUTHORIZED 2217                      /**/
#define ERR_TOPMQ_RC_MSG_TOO_BIG_FOR_CHANNEL   2218                      /**/
#define ERR_TOPMQ_RC_CALL_IN_PROGRESS          2219                      /**/
#define ERR_TOPMQ_RC_RMH_ERROR                 2220                      /**/
#define ERR_TOPMQ_RC_Q_MGR_ACTIVE              2222                      /**/
#define ERR_TOPMQ_RC_Q_MGR_NOT_ACTIVE          2223                      /**/
#define ERR_TOPMQ_RC_Q_DEPTH_HIGH              2224                      /**/
#define ERR_TOPMQ_RC_Q_DEPTH_LOW               2225                      /**/
#define ERR_TOPMQ_RC_Q_SERVICE_INTERVAL_HIGH   2226                      /**/
#define ERR_TOPMQ_RC_Q_SERVICE_INTERVAL_OK     2227                      /**/
#define ERR_TOPMQ_RC_RFH_HEADER_FIELD_ERROR    2228                      /**/
#define ERR_TOPMQ_RC_RAS_PROPERTY_ERROR        2229                      /**/
#define ERR_TOPMQ_RC_UNIT_OF_WORK_NOT_STARTED  2232                      /**/
#define ERR_TOPMQ_RC_CHANNEL_AUTO_DEF_OK       2233                      /**/
#define ERR_TOPMQ_RC_CHANNEL_AUTO_DEF_ERROR    2234                      /**/
#define ERR_TOPMQ_RC_CFH_ERROR                 2235                      /**/
#define ERR_TOPMQ_RC_CFIL_ERROR                2236                      /**/
#define ERR_TOPMQ_RC_CFIN_ERROR                2237                      /**/
#define ERR_TOPMQ_RC_CFSL_ERROR                2238                      /**/
#define ERR_TOPMQ_RC_CFST_ERROR                2239                      /**/
#define ERR_TOPMQ_RC_INCOMPLETE_GROUP          2241                      /**/
#define ERR_TOPMQ_RC_INCOMPLETE_MSG            2242                      /**/
#define ERR_TOPMQ_RC_INCONSISTENT_CCSIDS       2243                      /**/
#define ERR_TOPMQ_RC_INCONSISTENT_ENCODINGS    2244                      /**/
#define ERR_TOPMQ_RC_INCONSISTENT_UOW          2245                      /**/
#define ERR_TOPMQ_RC_INVALID_MSG_UNDER_CURSOR  2246                      /**/
#define ERR_TOPMQ_RC_MATCH_OPTIONS_ERROR       2247                      /**/
#define ERR_TOPMQ_RC_MDE_ERROR                 2248                      /**/
#define ERR_TOPMQ_RC_MSG_FLAGS_ERROR           2249                      /**/
#define ERR_TOPMQ_RC_MSG_SEQ_NUMBER_ERROR      2250                      /**/
#define ERR_TOPMQ_RC_OFFSET_ERROR              2251                      /**/
#define ERR_TOPMQ_RC_ORIGINAL_LENGTH_ERROR     2252                      /**/
#define ERR_TOPMQ_RC_SEGMENT_LENGTH_ZERO       2253                      /**/
#define ERR_TOPMQ_RC_UOW_NOT_AVAILABLE         2255                      /**/
#define ERR_TOPMQ_RC_WRONG_GMO_VERSION         2256                      /**/
#define ERR_TOPMQ_RC_WRONG_MD_VERSION          2257                      /**/
#define ERR_TOPMQ_RC_GROUP_ID_ERROR            2258                      /**/
#define ERR_TOPMQ_RC_INCONSISTENT_BROWSE       2259                      /**/
#define ERR_TOPMQ_RC_XQH_ERROR                 2260                      /**/
#define ERR_TOPMQ_RC_SRC_ENV_ERROR             2261                      /**/
#define ERR_TOPMQ_RC_SRC_NAME_ERROR            2262                      /**/
#define ERR_TOPMQ_RC_DEST_ENV_ERROR            2263                      /**/
#define ERR_TOPMQ_RC_DEST_NAME_ERROR           2264                      /**/
#define ERR_TOPMQ_RC_TM_ERROR                  2265                      /**/
#define ERR_TOPMQ_RC_CLUSTER_EXIT_ERROR        2266                      /**/
#define ERR_TOPMQ_RC_CLUSTER_EXIT_LOAD_ERROR   2267                      /**/
#define ERR_TOPMQ_RC_CLUSTER_PUT_INHIBITED     2268                      /**/
#define ERR_TOPMQ_RC_CLUSTER_RESOURCE_ERROR    2269                      /**/
#define ERR_TOPMQ_RC_NO_DESTINATIONS_AVAILABLE 2270                      /**/
#define ERR_TOPMQ_RC_CONN_TAG_IN_USE           2271                      /**/
#define ERR_TOPMQ_RC_PARTIALLY_CONVERTED       2272                      /**/
#define ERR_TOPMQ_RC_CONNECTION_ERROR          2273                      /**/
#define ERR_TOPMQ_RC_OPTION_ENVIRONMENT_ERROR  2274                      /**/
#define ERR_TOPMQ_RC_CD_ERROR                  2277                      /**/
#define ERR_TOPMQ_RC_CLIENT_CONN_ERROR         2278                      /**/
#define ERR_TOPMQ_RC_CHANNEL_STOPPED_BY_USER   2279                      /**/
#define ERR_TOPMQ_RC_HCONFIG_ERROR             2280                      /**/
#define ERR_TOPMQ_RC_FUNCTION_ERROR            2281                      /**/
#define ERR_TOPMQ_RC_CHANNEL_STARTED           2282                      /**/
#define ERR_TOPMQ_RC_CHANNEL_STOPPED           2283                      /**/
#define ERR_TOPMQ_RC_CHANNEL_CONV_ERROR        2284                      /**/
#define ERR_TOPMQ_RC_SERVICE_NOT_AVAILABLE     2285                      /**/
#define ERR_TOPMQ_RC_INITIALIZATION_FAILED     2286                      /**/
#define ERR_TOPMQ_RC_TERMINATION_FAILED        2287                      /**/
#define ERR_TOPMQ_RC_UNKNOWN_Q_NAME            2288                      /*�������ִ���*/
#define ERR_TOPMQ_RC_SERVICE_ERROR             2289                      /**/
#define ERR_TOPMQ_RC_Q_ALREADY_EXISTS          2290                      /**/
#define ERR_TOPMQ_RC_USER_ID_NOT_AVAILABLE     2291                      /**/
#define ERR_TOPMQ_RC_UNKNOWN_ENTITY            2292                      /**/
#define ERR_TOPMQ_RC_UNKNOWN_AUTH_ENTITY       2293                      /**/
#define ERR_TOPMQ_RC_UNKNOWN_REF_OBJECT        2294                      /**/
#define ERR_TOPMQ_RC_CHANNEL_ACTIVATED         2295                      /**/
#define ERR_TOPMQ_RC_CHANNEL_NOT_ACTIVATED     2296                      /**/
#define ERR_TOPMQ_RC_UOW_CANCELED              2297                      /**/
#define ERR_TOPMQ_RC_FUNCTION_NOT_SUPPORTED    2298                      /**/
#define ERR_TOPMQ_RC_SELECTOR_TYPE_ERROR       2299                      /**/
#define ERR_TOPMQ_RC_COMMAND_TYPE_ERROR        2300                      /**/
#define ERR_TOPMQ_RC_MULTIPLE_INSTANCE_ERROR   2301                      /**/
#define ERR_TOPMQ_RC_SYSTEM_ITEM_NOT_ALTERABLE 2302                      /**/
#define ERR_TOPMQ_RC_BAG_CONVERSION_ERROR      2303                      /**/
#define ERR_TOPMQ_RC_SELECTOR_OUT_OF_RANGE     2304                      /**/
#define ERR_TOPMQ_RC_SELECTOR_NOT_UNIQUE       2305                      /**/
#define ERR_TOPMQ_RC_INDEX_NOT_PRESENT         2306                      /**/
#define ERR_TOPMQ_RC_STRING_ERROR              2307                      /**/
#define ERR_TOPMQ_RC_ENCODING_NOT_SUPPORTED    2308                      /**/
#define ERR_TOPMQ_RC_SELECTOR_NOT_PRESENT      2309                      /**/
#define ERR_TOPMQ_RC_OUT_SELECTOR_ERROR        2310                      /**/
#define ERR_TOPMQ_RC_STRING_TRUNCATED          2311                      /**/
#define ERR_TOPMQ_RC_SELECTOR_WRONG_TYPE       2312                      /**/
#define ERR_TOPMQ_RC_INCONSISTENT_ITEM_TYPE    2313                      /**/
#define ERR_TOPMQ_RC_INDEX_ERROR               2314                      /**/
#define ERR_TOPMQ_RC_SYSTEM_BAG_NOT_ALTERABLE  2315                      /**/
#define ERR_TOPMQ_RC_ITEM_COUNT_ERROR          2316                      /**/
#define ERR_TOPMQ_RC_FORMAT_NOT_SUPPORTED      2317                      /**/
#define ERR_TOPMQ_RC_SELECTOR_NOT_SUPPORTED    2318                      /**/
#define ERR_TOPMQ_RC_ITEM_VALUE_ERROR          2319                      /**/
#define ERR_TOPMQ_RC_HBAG_ERROR                2320                      /**/
#define ERR_TOPMQ_RC_PARAMETER_MISSING         2321                      /**/
#define ERR_TOPMQ_RC_CMD_SERVER_NOT_AVAILABLE  2322                      /**/
#define ERR_TOPMQ_RC_STRING_LENGTH_ERROR       2323                      /**/
#define ERR_TOPMQ_RC_INQUIRY_COMMAND_ERROR     2324                      /**/
#define ERR_TOPMQ_RC_NESTED_BAG_NOT_SUPPORTED  2325                      /**/
#define ERR_TOPMQ_RC_BAG_WRONG_TYPE            2326                      /**/
#define ERR_TOPMQ_RC_ITEM_TYPE_ERROR           2327                      /**/
#define ERR_TOPMQ_RC_SYSTEM_BAG_NOT_DELETABLE  2328                      /**/
#define ERR_TOPMQ_RC_SYSTEM_ITEM_NOT_DELETABLE 2329                      /**/
#define ERR_TOPMQ_RC_CODED_CHAR_SET_ID_ERROR   2330                      /**/
#define ERR_TOPMQ_RC_MSG_TOKEN_ERROR           2331                      /**/
#define ERR_TOPMQ_RC_MISSING_WIH               2332                      /**/
#define ERR_TOPMQ_RC_WIH_ERROR                 2333                      /**/
#define ERR_TOPMQ_RC_RFH_ERROR                 2334                      /**/
#define ERR_TOPMQ_RC_RFH_STRING_ERROR          2335                      /**/
#define ERR_TOPMQ_RC_RFH_COMMAND_ERROR         2336                      /**/
#define ERR_TOPMQ_RC_RFH_PARM_ERROR            2337                      /**/
#define ERR_TOPMQ_RC_RFH_DUPLICATE_PARM        2338                      /**/
#define ERR_TOPMQ_RC_RFH_PARM_MISSING          2339                      /**/
#define ERR_TOPMQ_RC_CHAR_CONVERSION_ERROR     2340                      /**/
#define ERR_TOPMQ_RC_UCS2_CONVERSION_ERROR     2341                      /**/
#define ERR_TOPMQ_RC_DB2_NOT_AVAILABLE         2342                      /**/
#define ERR_TOPMQ_RC_OBJECT_NOT_UNIQUE         2343                      /**/
#define ERR_TOPMQ_RC_CONN_TAG_NOT_RELEASED     2344                      /**/
#define ERR_TOPMQ_RC_CF_NOT_AVAILABLE          2345                      /**/
#define ERR_TOPMQ_RC_CF_STRUC_IN_USE           2346                      /**/
#define ERR_TOPMQ_RC_CF_STRUC_LIST_HDR_IN_USE  2347                      /**/
#define ERR_TOPMQ_RC_CF_STRUC_AUTH_FAILED      2348                      /**/
#define ERR_TOPMQ_RC_CF_STRUC_ERROR            2349                      /**/
#define ERR_TOPMQ_RC_CONN_TAG_NOT_USABLE       2350                      /**/
#define ERR_TOPMQ_RC_GLOBAL_UOW_CONFLICT       2351                      /**/
#define ERR_TOPMQ_RC_LOCAL_UOW_CONFLICT        2352                      /**/
#define ERR_TOPMQ_RC_HANDLE_IN_USE_FOR_UOW     2353                      /**/
#define ERR_TOPMQ_RC_UOW_ENLISTMENT_ERROR      2354                      /**/
#define ERR_TOPMQ_RC_UOW_MIX_NOT_SUPPORTED     2355                      /**/
#define ERR_TOPMQ_RC_WXP_ERROR                 2356                      /**/
#define ERR_TOPMQ_RC_CURRENT_RECORD_ERROR      2357                      /**/
#define ERR_TOPMQ_RC_NEXT_OFFSET_ERROR         2358                      /**/
#define ERR_TOPMQ_RC_NO_RECORD_AVAILABLE       2359                      /**/
#define ERR_TOPMQ_RC_OBJECT_LEVEL_INCOMPATIBLE 2360                      /**/
#define ERR_TOPMQ_RC_NEXT_RECORD_ERROR         2361                      /**/
#define ERR_TOPMQ_RC_BACKOUT_THRESHOLD_REACHED 2362                      /**/
#define ERR_TOPMQ_RC_MSG_NOT_MATCHED           2363                      /**/
#define ERR_TOPMQ_RC_JMS_FORMAT_ERROR          2364                      /**/
#define ERR_TOPMQ_RC_SEGMENTS_NOT_SUPPORTED    2365                      /**/
#define ERR_TOPMQ_RC_WRONG_CF_LEVEL            2366                      /**/
#define ERR_TOPMQ_RC_CONFIG_CREATE_OBJECT      2367                      /**/
#define ERR_TOPMQ_RC_CONFIG_CHANGE_OBJECT      2368                      /**/
#define ERR_TOPMQ_RC_CONFIG_DELETE_OBJECT      2369                      /**/
#define ERR_TOPMQ_RC_CONFIG_REFRESH_OBJECT     2370                      /**/
#define ERR_TOPMQ_RC_CHANNEL_SSL_ERROR         2371                      /**/
#define ERR_TOPMQ_RC_CF_STRUC_FAILED           2373                      /**/
#define ERR_TOPMQ_RC_API_EXIT_ERROR            2374                      /**/
#define ERR_TOPMQ_RC_API_EXIT_INIT_ERROR       2375                      /**/
#define ERR_TOPMQ_RC_API_EXIT_TERM_ERROR       2376                      /**/
#define ERR_TOPMQ_RC_EXIT_REASON_ERROR         2377                      /**/
#define ERR_TOPMQ_RC_RESERVED_VALUE_ERROR      2378                      /**/
#define ERR_TOPMQ_RC_NO_DATA_AVAILABLE         2379                      /**/
#define ERR_TOPMQ_RC_SCO_ERROR                 2380                      /**/
#define ERR_TOPMQ_RC_KEY_REPOSITORY_ERROR      2381                      /**/
#define ERR_TOPMQ_RC_CRYPTO_HARDWARE_ERROR     2382                      /**/
#define ERR_TOPMQ_RC_AUTH_INFO_REC_COUNT_ERROR 2383                      /**/
#define ERR_TOPMQ_RC_AUTH_INFO_REC_ERROR       2384                      /**/
#define ERR_TOPMQ_RC_AIR_ERROR                 2385                      /**/
#define ERR_TOPMQ_RC_AUTH_INFO_TYPE_ERROR      2386                      /**/
#define ERR_TOPMQ_RC_AUTH_INFO_CONN_NAME_ERROR 2387                      /**/
#define ERR_TOPMQ_RC_LDAP_USER_NAME_ERROR      2388                      /**/
#define ERR_TOPMQ_RC_LDAP_USER_NAME_LENGTH_ERR 2389                      /**/
#define ERR_TOPMQ_RC_LDAP_PASSWORD_ERROR       2390                      /**/
#define ERR_TOPMQ_RC_SSL_ALREADY_INITIALIZED   2391                      /**/
#define ERR_TOPMQ_RC_SSL_CONFIG_ERROR          2392                      /**/
#define ERR_TOPMQ_RC_SSL_INITIALIZATION_ERROR  2393                      /**/
#define ERR_TOPMQ_RC_Q_INDEX_TYPE_ERROR        2394                      /**/
#define ERR_TOPMQ_RC_CFBS_ERROR                2395                      /**/
#define ERR_TOPMQ_RC_SSL_NOT_ALLOWED           2396                      /**/
#define ERR_TOPMQ_RC_JSSE_ERROR                2397                      /**/
#define ERR_TOPMQ_RC_SSL_PEER_NAME_MISMATCH    2398                      /**/
#define ERR_TOPMQ_RC_SSL_PEER_NAME_ERROR       2399                      /**/
#define ERR_TOPMQ_RC_UNSUPPORTED_CIPHER_SUITE  2400                      /**/
#define ERR_TOPMQ_RC_SSL_CERTIFICATE_REVOKED   2401                      /**/
#define ERR_TOPMQ_RC_SSL_CERT_STORE_ERROR      2402                      /**/
#define ERR_TOPMQ_RC_CLIENT_EXIT_LOAD_ERROR    2406                      /**/
#define ERR_TOPMQ_RC_CLIENT_EXIT_ERROR         2407                      /**/
#define ERR_TOPMQ_RC_SSL_KEY_RESET_ERROR       2409                      /**/
#define ERR_TOPMQ_RC_UNKNOWN_COMPONENT_NAME    2410                      /**/
#define ERR_TOPMQ_RC_LOGGER_STATUS             2411                      /**/
#define ERR_TOPMQ_RC_COMMAND_MQSC              2412                      /**/
#define ERR_TOPMQ_RC_COMMAND_PCF               2413                      /**/
#define ERR_TOPMQ_RC_CFIF_ERROR                2414                      /**/
#define ERR_TOPMQ_RC_CFSF_ERROR                2415                      /**/
#define ERR_TOPMQ_RC_CFGR_ERROR                2416                      /**/
#define ERR_TOPMQ_RC_MSG_NOT_ALLOWED_IN_GROUP  2417                      /**/
#define ERR_TOPMQ_RC_FILTER_OPERATOR_ERROR     2418                      /**/
#define ERR_TOPMQ_RC_NESTED_SELECTOR_ERROR     2419                      /**/
#define ERR_TOPMQ_RC_EPH_ERROR                 2420                      /**/
#define ERR_TOPMQ_RC_RFH_FORMAT_ERROR          2421                      /**/
#define ERR_TOPMQ_RC_CFBF_ERROR                2422                      /**/
#define ERR_TOPMQ_RC_CLIENT_CHANNEL_CONFLICT   2423                      /**/
#define ERR_TOPMQ_RC_REOPEN_EXCL_INPUT_ERROR   6100                      /**/
#define ERR_TOPMQ_RC_REOPEN_INQUIRE_ERROR      6101                      /**/
#define ERR_TOPMQ_RC_REOPEN_SAVED_CONTEXT_ERR  6102                      /**/
#define ERR_TOPMQ_RC_REOPEN_TEMPORARY_Q_ERROR  6103                      /**/
#define ERR_TOPMQ_RC_ATTRIBUTE_LOCKED          6104                      /**/
#define ERR_TOPMQ_RC_CURSOR_NOT_VALID          6105                      /**/
#define ERR_TOPMQ_RC_ENCODING_ERROR            6106                      /**/
#define ERR_TOPMQ_RC_STRUC_ID_ERROR            6107                      /**/
#define ERR_TOPMQ_RC_NULL_POINTER              6108                      /**/
#define ERR_TOPMQ_RC_NO_CONNECTION_REFERENCE   6109                      /**/
#define ERR_TOPMQ_RC_NO_BUFFER                 6110                      /**/
#define ERR_TOPMQ_RC_BINARY_DATA_LENGTH_ERROR  6111                      /**/
#define ERR_TOPMQ_RC_BUFFER_NOT_AUTOMATIC      6112                      /**/
#define ERR_TOPMQ_RC_INSUFFICIENT_BUFFER       6113                      /**/
#define ERR_TOPMQ_RC_INSUFFICIENT_DATA         6114                      /**/
#define ERR_TOPMQ_RC_DATA_TRUNCATED            6115                      /**/
#define ERR_TOPMQ_RC_ZERO_LENGTH               6116                      /*0����*/
#define ERR_TOPMQ_RC_NEGATIVE_LENGTH           6117                      /**/
#define ERR_TOPMQ_RC_NEGATIVE_OFFSET           6118                      /**/
#define ERR_TOPMQ_RC_INCONSISTENT_FORMAT       6119                      /**/
#define ERR_TOPMQ_RC_INCONSISTENT_OBJECT_STATE 6120                      /**/
#define ERR_TOPMQ_RC_CONTEXT_OBJECT_NOT_VALID  6121                      /*���󲻿���*/
#define ERR_TOPMQ_RC_CONTEXT_OPEN_ERROR        6122                      /*�޷��򿪻���*/
#define ERR_TOPMQ_RC_STRUC_LENGTH_ERROR        6123                      /**/
#define ERR_TOPMQ_RC_NOT_CONNECTED             6124                      /*δ����*/
#define ERR_TOPMQ_RC_NOT_OPEN                  6125                      /*δ��*/
#define ERR_TOPMQ_RC_DISTRIBUTION_LIST_EMPTY   6126                      /**/
#define ERR_TOPMQ_RC_INCONSISTENT_OPEN_OPTIONS 6127                      /**/
#define ERR_TOPMQ_RC_WRONG_VERSION             6128                      /**/
#define ERR_TOPMQ_RC_REFERENCE_ERROR           6129                      /**/
            
/*---------------------------- Type define ------------------------------*/
#if defined(TOPMQ_64_BIT)
 typedef long TMQINT64;
#else
 typedef long long TMQINT64;
#endif

typedef char TMQCHAR;
typedef char * PTMQCHAR;

typedef int TMQINT;
typedef int *PTMQINT;
typedef TMQINT TMQHCONN;
typedef TMQINT * PTMQHCONN;
typedef TMQINT TMQHOBJ;
typedef TMQINT * PTMQHOBJ;
typedef void * PTMQVOID;
typedef TMQCHAR TMQSTRUCID[4];

/*-------------------------------------------------*/
/*Object Descriptor*/
/*-------------------------------------------------*/
#define TOPMQ_OD_STRUC_ID_ARRAY 'O','D',' ',' '
#define TOPMQ_OD_VERISON_1 1
#define TOPMQ_OD_VERISON_2 2

typedef struct {
    /*Ver:1*/
    TMQSTRUCID sStrucId;
    TMQINT iVersion;
    TMQINT iObjType;
    TMQCHAR sObjName[DLEN_TOPMQ_API_OBJNAME+1];
    TMQCHAR sObjQMgrName[DLEN_TOPMQ_API_OBJNAME+1];
} T_TOPMQ_OD;

#define TOPMQ_OD_DEFAULT {TOPMQ_OD_STRUC_ID_ARRAY}, \
            TOPMQ_OD_VERISON_1, \
            TOPMQ_API_OBJTYPE_QUE, "", ""

/*-------------------------------------------------*/
/*Get Message Options*/
/*-------------------------------------------------*/
#define TOPMQ_GMO_STRUC_ID_ARRAY 'G','M','O',' '
#define TOPMQ_GMO_VERISON_1 1
#define TOPMQ_GMO_VERISON_2 2

typedef struct {
    /*Ver:1*/
    TMQSTRUCID sStrucId;
    TMQINT iVersion;
    TMQINT iOptions;            /*get msg options*/
    TMQINT iWaitInterval;       /* Wait interval */
    TMQINT iSignal1;            /* Signal1 */
    TMQINT iSignal2;            /* Signal2 */
    
} T_TOPMQ_GMO;

#define TOPMQ_GMO_DEFAULT {TOPMQ_GMO_STRUC_ID_ARRAY}, \
            TOPMQ_GMO_VERISON_1, \
            0, 0, 0, 0
            
/*-------------------------------------------------*/
/*Put Message Options*/
/*-------------------------------------------------*/
#define TOPMQ_PMO_STRUC_ID_ARRAY 'G','M','O',' '
#define TOPMQ_PMO_VERISON_1 1
#define TOPMQ_PMO_VERISON_2 2

typedef struct {
    /*Ver:1*/
    TMQSTRUCID sStrucId;
    TMQINT iVersion;
    TMQINT iOptions;            /*put msg options*/
    TMQINT iTimeOut;            /*put msg time out*/
} T_TOPMQ_PMO;

#define TOPMQ_PMO_DEFAULT {TOPMQ_PMO_STRUC_ID_ARRAY}, \
            TOPMQ_PMO_VERISON_1, \
            0, 0
            
/*-------------------------------------------------*/
/*Msg Descriptor*/
/*-------------------------------------------------*/
#define TOPMQ_MD_STRUC_ID_ARRAY 'M','D',' ',' '
#define TOPMQ_MD_VERISON_1 1
#define TOPMQ_MD_VERISON_2 2

#define TOPMQ_MD_MSGSTORETYPE_MEM '1'
#define TOPMQ_MD_MSGSTORETYPE_FILE '2'

#define TOPMQ_MD_USAGE_DATAGRAM 0
#define TOPMQ_MD_USAGE_REQUEST 1
#define TOPMQ_MD_USAGE_REPLY 2

#define TOPMQ_MD_MSGFLAGS_SEGMENT 0x00000001
#define TOPMQ_MD_MSGFLAGS_LASTSEGMENT 0x00000002
#define TOPMQ_MD_MSGFLAGS_ACCESSORIES 0x00000004

#define TOPMQ_MD_USAGE_REPORT 3

typedef struct {
    /*Ver: 1*/
    TMQSTRUCID sStrucId;
    TMQINT iVersion;
    TMQINT iMsgType;
    TMQINT iMsgCode;
    TMQCHAR sMsgId[DLEN_TOPMQ_API_MSGID];               /*��ϢΨһID*/
    TMQCHAR sCorrelId[DLEN_TOPMQ_API_CORRELID];         /*�����ID*/
    TMQCHAR cMsgStoreType;                              /*���Ĵ洢��ʽ*/
    
    /*Ver: 2*/
    TMQINT  iUsage;                                     /*��Ϣ��;*/
    TMQINT  iMsgFlags;                                  /*��Ϣ��־��*/
    TMQINT  iExpiry;                                    /*��ʱʱ��*/
    TMQINT  iFeedback;                                  /*���ر�־*/
    TMQINT  iEncoding;                                  /*����*/
    TMQINT  iCodedCharSetId;                            /*�ַ���ʶ���*/
    TMQINT  iPriority;                                  /*���ȼ�*/
    TMQINT  iPersistence;                               /*�־��Ա�־*/
    TMQINT  iMsgSeqNo;                                  /*��Ϣ���*/
    TMQINT  iReportOpt;                                 /*�ظ���Ϣѡ��*/
    TMQCHAR sFmtName[DLEN_TOPMQ_API_FMT+1];             /*��ʽ����*/
    TMQCHAR sReplyToQ[DLEN_TOPMQ_API_OBJNAME+1];        /*�ظ�������*/
    TMQCHAR sReplyToQMgr[DLEN_TOPMQ_API_OBJNAME+1];     /*�ظ����й�������*/
    TMQCHAR sGroupId[DLEN_TOPMQ_API_MSGID];             /*��Ϣ��Id*/
    TMQINT  iPutApplType;                               /*Ӧ������*/
    TMQCHAR sPutApplName[DLEN_TOPMQ_API_OBJNAME+1];     /*������Ϣ��������*/
    TMQCHAR sPutDate[DLEN_TOPMQ_API_DATE+1];            /*������Ϣ����*/
    TMQCHAR sPutTime[DLEN_TOPMQ_API_TIME+1];            /*������Ϣʱ��*/
    PTMQVOID pOptData;                                  /*��������*/
} T_TOPMQ_MD;


#define TOPMQ_MD_DEFAULT {TOPMQ_MD_STRUC_ID_ARRAY}, \
            TOPMQ_MD_VERISON_2, \
            0, 0, "", "", TOPMQ_MD_MSGSTORETYPE_MEM, \
            TOPMQ_MD_USAGE_DATAGRAM, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", "", "", "", \
            0, "", "", "", NULL

/*-------------------------------------------------*/
/*Accessories Descriptor*/
/*-------------------------------------------------*/
#define TOPMQ_ACCESSORIES_MD_STRUC_ID_ARRAY 'A','C','M','D'
#define TOPMQ_ACCESSORIES_MD_VERISON_1 1
#define TOPMQ_ACCESSORIES_MD_TYPE 0

typedef struct {
    /*Ver: 1*/
    TMQSTRUCID sStrucId;
    TMQINT iVersion;
    int  iType;                             /*��������*/
    int  iNum;                              /*�ļ�����*/
    char sFiles[DLEN_TOPMQ_API_ACCESSORIES_FILE_NUM_MAX][DLEN_TOPMQ_API_ACCESSORIES_FILENAME_MAX];
} T_TOPMQ_ACCESSORIES_MD;
    
#define TOPMQ_ACCESSORIES_MD_DEFAULT {TOPMQ_ACCESSORIES_MD_STRUC_ID_ARRAY}, \
                    TOPMQ_ACCESSORIES_MD_VERISON_1, \
                    TOPMQ_ACCESSORIES_MD_TYPE, 0, \
                    {{""},{""},{""},{""},{""},{""},{""},{""},{""},{""}, \
                     {""},{""},{""},{""},{""},{""},{""},{""},{""},{""}, \
                     {""},{""},{""},{""},{""},{""},{""},{""},{""},{""}}


/*-------------------------------------------------*/
/*Dead queue Msg Header*/
/*-------------------------------------------------*/
#define TOPMQ_HDR_DEADQ_STRUC_ID_ARRAY 'D','Q','M','H'
#define TOPMQ_HDR_DEADQ_VERISON_1 1
#define TOPMQ_HDR_DEADQ_VERISON_2 2

typedef struct {
    TMQSTRUCID sStrucId;
    TMQINT iVersion;
    TMQINT iRCode;
} T_TOPMQ_HD_DEADQ;

#define TOPMQ_HD_DEADQ_DEFAULT {TOPMQ_HDR_DEADQ_STRUC_ID_ARRAY}, \
            TOPMQ_HDR_DEADQ_VERISON_1, \
            0 \
/*-------------------------------------------------*/
/*Error queue Msg Header*/
/*-------------------------------------------------*/
#define TOPMQ_HDR_ERRQ_STRUC_ID_ARRAY 'E','Q','M','H'
#define TOPMQ_HDR_ERRQ_VERISON_1 1
#define TOPMQ_HDR_ERRQ_VERISON_2 2

typedef struct {
    TMQSTRUCID sStrucId;
    TMQINT iVersion;
    TMQINT iRCode;
} T_TOPMQ_HDR_ERRMSG;

#define TOPMQ_HD_ERRQ_DEFAULT {TOPMQ_HDR_ERRQ_STRUC_ID_ARRAY}, \
            TOPMQ_HDR_ERRQ_VERISON_1, \
            0 \
/*-------------------------------------------------*/
/*Command Msg Header*/
/*-------------------------------------------------*/
#define TOPMQ_HDR_CMDQ_STRUC_ID_ARRAY 'C','Q','M','H'
#define TOPMQ_HDR_CMDQ_VERISON_1 1
#define TOPMQ_HDR_CMDQ_VERISON_2 2

#define TOPMQ_HDR_CMDQ_CMD_TYPE_OML 0
#define TOPMQ_HDR_CMDQ_CMD_TYPE_OCL 1

#define TOPMQ_HDR_CMDQ_CMD_CODE_DEFINE 0
#define TOPMQ_HDR_CMDQ_CMD_CODE_DELETE 1
#define TOPMQ_HDR_CMDQ_CMD_CODE_DISPLAY 2
#define TOPMQ_HDR_CMDQ_CMD_CODE_START 3
#define TOPMQ_HDR_CMDQ_CMD_CODE_STOP 4
#define TOPMQ_HDR_CMDQ_CMD_CODE_RESET 5
#define TOPMQ_HDR_CMDQ_CMD_CODE_CLEAR 6
#define TOPMQ_HDR_CMDQ_CMD_CODE_ALTER 7


typedef struct {
    TMQSTRUCID sStrucId;
    TMQINT iVersion;
    TMQINT iRCode;
    TMQINT iCmdType;   /*OML, OCL*/
    TMQINT iCmdCode;
    TMQINT iNum;
} T_TOPMQ_HDR_CMDMSG; 

#define TOPMQ_HD_CMDQ_DEFAULT {TOPMQ_HDR_CMDQ_STRUC_ID_ARRAY}, \
            TOPMQ_HDR_CMDQ_VERISON_1, \
            0,0,0,0 \
            
/*CMD MSG FORMAT DEFINE*/
#define DLEN_TOPMQ_API_CMD_LINE_LABEL 32
typedef struct {
    TMQCHAR sLabel[DLEN_TOPMQ_API_CMD_LINE_LABEL];
    TMQINT  iSubNum;
    TMQINT  iLen;
    TMQCHAR sValue[1];
} T_TOPMQ_CMDMSG_LINE;

/*-------------------------------------------------*/
/*xmitq Msg Header*/
/*-------------------------------------------------*/
#define TOPMQ_HDR_XMITQ_STRUC_ID_ARRAY 'X','T','M','H'
#define TOPMQ_HDR_XMITQ_VERISON_1 1
#define TOPMQ_HDR_XMITQ_VERISON_2 2

typedef struct {
    TMQSTRUCID sStrucId;
    TMQINT iVersion;
    TMQCHAR sDestQ[DLEN_TOPMQ_API_OBJNAME];        /*Ŀ�������*/
    TMQCHAR sDestQMgr[DLEN_TOPMQ_API_OBJNAME];     /*Ŀ����й�������*/
} T_TOPMQ_HDR_XMITQ; 

#define TOPMQ_HD_XMITQ_DEFAULT {TOPMQ_HDR_XMITQ_STRUC_ID_ARRAY}, \
            TOPMQ_HDR_XMITQ_VERISON_1, \
            "", ""\
                       
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/**
 * ���Ӷ��й�����
 *
 * @param psQMgrName: 
 * @param pHconn: 
 * @param piReason: 
 *
 * @return 0:�ɹ�
 *        <0:����
 *
 */
TMQINT TOPMQCONN(PTMQCHAR psQMgrName, PTMQHCONN pHconn, PTMQINT piReason);

/**
 * �Ͽ��������������
 *
 * @param Hconn: 
 * @param piReason: 
 *
 * @return 0:�ɹ�
 *        <0:����
 *
 */
TMQINT TOPMQDISC(TMQHCONN Hconn, PTMQINT piReason);

/**
 * �򿪶���
 *
 * @param Hconn: 
 * @param pObjDesc: 
 * @param iOptions: 
 * @param pHobj: 
 * @param piReason: 
 *
 * @return 0:�ɹ�
 *        <0:����
 *
 */
TMQINT TOPMQOPEN(TMQHCONN Hconn, PTMQVOID pObjDesc, TMQINT iOptions, PTMQHOBJ pHobj, PTMQINT piReason);

/**
 * �رն���
 *
 * @param Hconn: 
 * @param iOptions: 
 * @param pHobj: 
 * @param piReason: 
 *
 * @return 0:�ɹ�
 *        <0:����
 *
 */
TMQINT TOPMQCLOSE(TMQHCONN Hconn, TMQINT iOptions, PTMQHOBJ pHobj, PTMQINT piReason);

/**
 * ��ʼ����
 *
 * @param Hconn: 
 * @param pBeginOpts: 
 * @param piReason: 
 *
 * @return 0:�ɹ�
 *        <0:����
 *
 */
TMQINT TOPMQBEGIN(TMQHCONN Hconn, PTMQVOID pBeginOpts, PTMQINT piReason);

/**
 * �ع�����
 *
 * @param Hconn: 
 * @param piReason: 
 *
 * @return 0:�ɹ�
 *        <0:����
 *
 */
TMQINT TOPMQBACK(TMQHCONN Hconn, PTMQINT piReason);

/**
 * �ύ����
 *
 * @param Hconn: 
 * @param piReason: 
 *
 * @return 0:�ɹ�
 *        <0:����
 *
 */
TMQINT TOPMQCMIT(TMQHCONN Hconn, PTMQINT piReason);

/**
 * ������Ϣ
 *
 * @param Hconn: 
 * @param Hobj: 
 * @param pMsgDesc: 
 * @param pPutMsgOpts: 
 * @param iLenBuf: 
 * @param pBuf: 
 * @param piReason: 
 *
 * @return 0:�ɹ�
 *        <0:����
 *
 */
TMQINT TOPMQPUT(TMQHCONN Hconn, TMQHOBJ Hobj, PTMQVOID pMsgDesc, 
        PTMQVOID pPutMsgOpts, TMQINT iLenBuf, PTMQVOID pBuf, PTMQINT piReason);

/**
 * ȡ����Ϣ
 *
 * @param Hconn: 
 * @param Hobj: 
 * @param pMsgDesc: 
 * @param pGetMsgOpts: 
 * @param iLenBuf: 
 * @param pBuf: 
 * @param pDataLen: 
 * @param piReason: 
 *
 * @return 0:�ɹ�
 *        <0:����
 *
 */
TMQINT TOPMQGET(TMQHCONN Hconn, TMQHOBJ Hobj, PTMQVOID pMsgDesc, PTMQVOID pGetMsgOpts, 
        TMQINT iLenBuf, PTMQVOID pBuf, PTMQINT pDataLen, PTMQINT piReason);

/**
 * ��ѯ��������
 *
 * @param Hconn: 
 * @param psObjType: 
 * @param psObjName: 
 * @param psAttrNames: 
 * @param psAttrs: 
 * @param piReason: 
 *
 * @return 0:�ɹ�
 *        <0:����
 *
 */
TMQINT TOPMQINQ(TMQHCONN Hconn, PTMQCHAR psObjType, PTMQCHAR psObjName, TMQINT iAttrNum, PTMQCHAR psAttrNames[], PTMQCHAR psAttrs[], PTMQINT piReason);

/**
 * ���ö�������
 *
 * @param Hconn: 
 * @param psObjType: 
 * @param psObjName: 
 * @param psAttrNames: 
 * @param psAttrs: 
 * @param piReason: 
 *
 * @return 0:�ɹ�
 *        <0:����
 *
 */
TMQINT TOPMQSET(TMQHCONN Hconn, PTMQCHAR psObjType, PTMQCHAR psObjName, TMQINT iAttrNum, PTMQCHAR psAttrNames[], PTMQCHAR psAttrs[], PTMQINT piReason);


#ifdef __cplusplus
}
#endif

#endif /*_TOPMQ_API_H_20100125165150_*/
/*-----------------------------  End ------------------------------------*/
