/*
 *
 * 
 * datasource interface define.
 * 
 * 
 * FileName: topmq_queue_datasource.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _TOPMQ_QUEUE_DATASOURCE_H_20110601202242_
#define _TOPMQ_QUEUE_DATASOURCE_H_20110601202242_
/*--------------------------- Include files -----------------------------*/
#include "topmq_api.h"
#include "topmq_object.h"
#include "topmq_queue.h"
#define VAR_TOPMQ_QUE_DS_LOADFUN "TMQ_QueDSLoad"
/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/
/*--------------------------------------------------*/
/*���й���*/
/*--------------------------------------------------*/
typedef int (*PFN_TMQ_QUEDBCREATE)(char *psName, int iOptions);
typedef int (*PFN_TMQ_QUEDBDELETE)(char *psName, int iOptions);
typedef int (*PFN_TMQ_QUEDBOPEN)(char *psName, T_TMQ_OBJ_DB_HANDLE hObjDb, int iOptions);
typedef int (*PFN_TMQ_QUEDBCLOSE)(char *psName, int iOptions);

typedef T_TMQ_QUE_DB_HANDLE (*PFN_TMQ_QUEDBCONN)(char *psName, T_TMQ_OBJ_DB_HANDLE hObjDb, int iOptions);
typedef int (*PFN_TMQ_QUEDBDISCONN)(T_TMQ_QUE_DB_HANDLE hDB);

typedef int (*PFN_TMQ_QUEDBISEXIST)(char *psName);
typedef int (*PFN_TMQ_QUEDBISOPEN)(char *psName);

/*--------------------------------------------------*/
/*���ݲ���*/
/*--------------------------------------------------*/
typedef int (*PFN_TMQ_QUEADD)(T_TMQ_QUE_DB_HANDLE hDB, char *psName, int iOptions);
typedef int (*PFN_TMQ_QUEDEL)(T_TMQ_QUE_DB_HANDLE hDB, char *psName, int iOptions);

typedef int (*PFN_TMQ_QUEOPEN)(T_TMQ_QUE_DB_HANDLE hDB, char *psName, T_TMQ_QUE_OBJ_HANDLE *phObj, int iOptions);
typedef int (*PFN_TMQ_QUECLOSE)(T_TMQ_QUE_DB_HANDLE hDB, char *psName, T_TMQ_QUE_OBJ_HANDLE hObj, int iOptions);
typedef int (*PFN_TMQ_QUEGETDEPTH)(T_TMQ_QUE_DB_HANDLE hDB, char *psName);

typedef int (*PFN_TMQ_QUEMSGPUT)(T_TMQ_QUE_DB_HANDLE hDB, T_TMQ_QUE_OBJ_HANDLE hObj, T_TOPMQ_QUE_MD *ptMD, T_TOPMQ_QUE_PMO *ptPMO, void *pBuf, int iDataLen);
typedef int (*PFN_TMQ_QUEMSGGET)(T_TMQ_QUE_DB_HANDLE hDB, T_TMQ_QUE_OBJ_HANDLE hObj, T_TOPMQ_QUE_MD *ptMD, T_TOPMQ_QUE_GMO *ptGMO, void *pBuf, int *piDataLen);

typedef T_TMQ_QUE_CUR_HANDLE (*PFN_TMQ_QUECUROPEN)(T_TMQ_QUE_DB_HANDLE hDB, char *psName);
typedef int (*PFN_TMQ_QUECURFETCH)(T_TMQ_QUE_DB_HANDLE hDB, T_TMQ_OBJ_CUR_HANDLE pCur, T_TOPMQ_QUE_MD *ptMD, void *pBuf, int *piDataLen, int iOptions);
typedef int (*PFN_TMQ_QUECURCLOSE)(T_TMQ_QUE_DB_HANDLE hDB, T_TMQ_OBJ_CUR_HANDLE hCur);
/*--------------------------------------------------*/
/*��������*/
/*--------------------------------------------------*/
typedef int (*PFN_TMQ_QUEISEXIST)(T_TMQ_QUE_DB_HANDLE hDB, char *psName);

/*--------------------------------------------------*/
/*������*/
/*--------------------------------------------------*/
typedef char * (*PFN_TMQ_QUEGETERROR)(void);
typedef int (*PFN_TMQ_QUEGETRCODE)(void);


typedef struct {
    PFN_TMQ_QUEDBCREATE        pfnQueDBCreate      ;
    PFN_TMQ_QUEDBDELETE        pfnQueDBDelete      ;
    PFN_TMQ_QUEDBOPEN          pfnQueDBOpen        ;
    PFN_TMQ_QUEDBCLOSE         pfnQueDBClose       ;
                              
    PFN_TMQ_QUEDBCONN          pfnQueDBConn        ;
    PFN_TMQ_QUEDBDISCONN       pfnQueDBDisConn     ;
    
    PFN_TMQ_QUEDBISEXIST       pfnQueDBIsExist     ;
    PFN_TMQ_QUEDBISOPEN        pfnQueDBIsOpen     ;
                              
    /*-----------------------------------*/
    /*���ݲ���*/  
    /*-----------------------------------*/
    PFN_TMQ_QUEADD             pfnQueAdd           ;
    PFN_TMQ_QUEDEL             pfnQueDel           ;
                               
    PFN_TMQ_QUEOPEN            pfnQueOpen          ;
    PFN_TMQ_QUECLOSE           pfnQueClose         ;
    PFN_TMQ_QUEGETDEPTH        pfnQueGetDepth      ;
                               
    PFN_TMQ_QUEMSGPUT          pfnQueMsgPut        ;
    PFN_TMQ_QUEMSGGET          pfnQueMsgGet        ;
                               
    PFN_TMQ_QUECUROPEN         pfnQueCurOpen       ;
    PFN_TMQ_QUECURFETCH        pfnQueCurFetch      ;
    PFN_TMQ_QUECURCLOSE        pfnQueCurClose      ;
    
    PFN_TMQ_QUEISEXIST         pfnQueIsExist       ;
                             
    /*-----------------------------------*/
    /*���ݲ���*/  
    /*-----------------------------------*/
    PFN_TMQ_QUEGETERROR        pfnQueGetError      ;
    PFN_TMQ_QUEGETRCODE        pfnQueGetRCode      ;
    
} T_TMQ_QUE_DS_ITF;

typedef T_TMQ_QUE_DS_ITF * (*PFN_TMQ_QUEDSLOAD)(int iOptions);
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

T_TMQ_QUE_DS_ITF * TMQ_QueDSLoad(int iOptions);

#ifdef __cplusplus
}
#endif

#endif /*_TOPMQ_QUEUE_DATASOURCE_H_20110601202242_*/
/*-----------------------------  End ------------------------------------*/
