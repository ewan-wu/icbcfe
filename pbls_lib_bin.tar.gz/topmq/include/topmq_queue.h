/*
 *
 * 
 * topmq queue interface define.
 * 
 * 
 * FileName: topmq_queue.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _TOPMQ_QUEUE_H_20110601201215_
#define _TOPMQ_QUEUE_H_20110601201215_
/*--------------------------- Include files -----------------------------*/
#include "topmq_api.h"
#include "topmq_object.h"
/*--------------------------- Macro define ------------------------------*/
/*-------------------------------------------------------*/
/*���ȶ���*/
/*-------------------------------------------------------*/
/*��Ϣ����СΪ20M*/
#define DLEN_TOPMQ_IPC_MSGSIZE (2*1024*1024+200)

#define DLEN_TOPMQ_MSGID 32
#define DLEN_TOPMQ_CORRELID 32

#define DLEN_TOPMQ_QUE_DBTYPE_MAX   32
/*----------------------------------------------------*/
/*�����붨��*/
/*----------------------------------------------------*/
#define ERR_TOPMQ_QUE_OK 0

#define ERR_TOPMQ_QUE_BASE (-8000)
#define ERR_TOPMQ_QUE_NOTFOUND (ERR_TOPMQ_OBJ_BASE-1)
#define ERR_TOPMQ_QUE_OPEN (ERR_TOPMQ_OBJ_BASE-4)
#define ERR_TOPMQ_QUE_FETCH (ERR_TOPMQ_OBJ_BASE-5)
#define ERR_TOPMQ_QUE_CLOSE (ERR_TOPMQ_OBJ_BASE-6)
#define ERR_TOPMQ_QUE_CONN (ERR_TOPMQ_OBJ_BASE-7)
#define ERR_TOPMQ_QUE_DISCONN (ERR_TOPMQ_OBJ_BASE-8)
#define ERR_TOPMQ_QUE_COMMIT (ERR_TOPMQ_OBJ_BASE-9)
#define ERR_TOPMQ_QUE_ROLLBACK (ERR_TOPMQ_OBJ_BASE-10)
#define ERR_TOPMQ_QUE_DECLARE (ERR_TOPMQ_OBJ_BASE-11)
#define ERR_TOPMQ_QUE_ANALYSQL (ERR_TOPMQ_OBJ_BASE-12)
#define ERR_TOPMQ_QUE_INIT (ERR_TOPMQ_OBJ_BASE-20)
#define ERR_TOPMQ_QUE_PARAM (ERR_TOPMQ_OBJ_BASE-21)
#define ERR_TOPMQ_QUE_HANDLE (ERR_TOPMQ_OBJ_BASE-22)
#define ERR_TOPMQ_QUE_SPACE (ERR_TOPMQ_OBJ_BASE-23)
#define ERR_TOPMQ_QUE_STAT (ERR_TOPMQ_OBJ_BASE-24)
#define ERR_TOPMQ_QUE_RCV (ERR_TOPMQ_OBJ_BASE-25)
#define ERR_TOPMQ_QUE_UNKNOW (ERR_TOPMQ_OBJ_BASE-500)
/*---------------------------- Type define ------------------------------*/
typedef  void * T_TMQ_QUE_DB_HANDLE;
typedef  void * T_TMQ_QUE_OBJ_HANDLE;
typedef  void * T_TMQ_QUE_CUR_HANDLE;

typedef T_TOPMQ_MD T_TOPMQ_QUE_MD ;
typedef T_TOPMQ_GMO T_TOPMQ_QUE_GMO;
typedef T_TOPMQ_PMO T_TOPMQ_QUE_PMO;

typedef int (*PFN_TOPMQ_MSG_EVENT_CALL_BACK) (int iEventType, char *psQueName, void *pBuf, T_TOPMQ_QUE_MD *ptMD, int iDataLen);

typedef struct {
    char sDbType[DLEN_TOPMQ_QUE_DBTYPE_MAX];
    PFN_TOPMQ_MSG_EVENT_CALL_BACK pfnMsgEventHandle;
} T_TOPMQ_QUE_CREATE_CTX_OPT;
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*context*/
int TMQ_QueCreateCtx(T_TOPMQ_QUE_CREATE_CTX_OPT *ptOpt);

/*--------------------------------------------------*/
/*���й���*/
/*--------------------------------------------------*/
int TMQ_QueDBCreate(char *psName, int iOptions);
int TMQ_QueDBDelete(char *psName, int iOptions);
int TMQ_QueDBOpen(char *psName, T_TMQ_OBJ_DB_HANDLE hObjDb, int iOptions);
int TMQ_QueDBClose(char *psName, int iOptions);

T_TMQ_QUE_DB_HANDLE TMQ_QueDBConn(char *psName, T_TMQ_OBJ_DB_HANDLE hObjDb, int iOptions);
int TMQ_QueDBDisConn(T_TMQ_QUE_DB_HANDLE hDB);

int TMQ_QueDBIsExist(char *psName);
int TMQ_QueDBIsOpen(char *psName);

/*--------------------------------------------------*/
/*���ݲ���*/
/*--------------------------------------------------*/
int TMQ_QueAdd(T_TMQ_QUE_DB_HANDLE hDB, char *psName, int iOptions);
int TMQ_QueDel(T_TMQ_QUE_DB_HANDLE hDB, char *psName, int iOptions);

int TMQ_QueOpen(T_TMQ_QUE_DB_HANDLE hDB, char *psName, T_TMQ_QUE_OBJ_HANDLE *phObj, int iOptions);
int TMQ_QueClose(T_TMQ_QUE_DB_HANDLE hDB, char *psName, T_TMQ_QUE_OBJ_HANDLE hObj, int iOptions);

int TMQ_QueGetDepth(T_TMQ_QUE_DB_HANDLE hDB, char *psName);

int TMQ_QueMsgPut(T_TMQ_QUE_DB_HANDLE hDB, T_TMQ_QUE_OBJ_HANDLE hObj, T_TOPMQ_QUE_MD *ptMD, T_TOPMQ_QUE_PMO *ptPMO, void *pBuf, int iDataLen);
int TMQ_QueMsgGet(T_TMQ_QUE_DB_HANDLE hDB, T_TMQ_QUE_OBJ_HANDLE hObj, T_TOPMQ_QUE_MD *ptMD, T_TOPMQ_QUE_GMO *ptGMO, void *pBuf, int *piDataLen);

T_TMQ_QUE_CUR_HANDLE TMQ_QueCurOpen(T_TMQ_QUE_DB_HANDLE hDB, char *psName);
int TMQ_QueCurFetch(T_TMQ_QUE_DB_HANDLE hDB, T_TMQ_OBJ_CUR_HANDLE pCur, T_TOPMQ_QUE_MD *ptMD, void *pBuf, int *piDataLen, int iOptions);
int TMQ_QueCurClose(T_TMQ_QUE_DB_HANDLE hDB, T_TMQ_OBJ_CUR_HANDLE hCur);
/*--------------------------------------------------*/
/*��������*/
/*--------------------------------------------------*/

int TMQ_QueIsExist(T_TMQ_QUE_DB_HANDLE hDB, char *psName);

/*--------------------------------------------------*/
/*������*/
/*--------------------------------------------------*/
char * TMQ_QueGetError(void);
int TMQ_QueGetRCode(void);

#ifdef __cplusplus
}
#endif

#endif /*_TOPMQ_QUEUE_H_20110601201215_*/
/*-----------------------------  End ------------------------------------*/
