/*
 *
 * 
 * topmq glb define.
 * 
 * 
 * FileName: topmq_def.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _TOPMQ_DEF_H_20100122120812_
#define _TOPMQ_DEF_H_20100122120812_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/
#if defined(__powerpc64__) || defined(__x86_64__) || defined(__ia64__) || defined(__s390x__)
  #define TOPMQ_64_BIT
#endif

#define VAR_TOPMQ_LSR_SOCK_ID "__TOPMQ_SOCK_ID"

#define VAR_TOPMQM_QMGRS_PATH "qmgrs"

/*-------------------------------------------------------*/
/*bin define*/
/*-------------------------------------------------------*/
#define VAR_TOPMQ_BIN "topmq_app"

/*-------------------------------------------------------*/
/*config section define*/
/*-------------------------------------------------------*/
#define VAR_TOPMQM_LISTENER_CFG "lsr"
#define VAR_TOPMQM_RCVCHL_CFG "chlr"
#define VAR_TOPMQM_SNDCHL_CFG "chls"
#define VAR_TOPMQM_SC_CFG "sc"

#define VAR_TOPMQM_CHL_SSL "SSL"

#define VAR_TOPMQ_MSG_EXPIRE_MAX 3600 /*���ʱʱ��*/

#define DLEN_TOPMQ_LEN 8
#define DLEN_TOPMQ_FLAGS 8
#define DLEN_TOPMQ_MAC 64

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /*_TOPMQ_DEF_H_20100122120812_*/
/*-----------------------------  End ------------------------------------*/
