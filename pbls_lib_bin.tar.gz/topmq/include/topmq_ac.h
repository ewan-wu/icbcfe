/*
 *
 * 
 * topmq app common lib.
 * 
 * 
 * FileName: topmq_ac.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _TOPMQ_AC_H_20100122202625_
#define _TOPMQ_AC_H_20100122202625_
/*--------------------------- Include files -----------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "topmq_def.h"      
#include "topmq_log.h"
#include "topmq_object.h"
#include "topmq_queue.h"
/*--------------------------- Macro define ------------------------------*/
#define VAR_TOPMQM_ENV_HOME_NAME "TOPMQM_HOME"
#define VAR_TOPMQM_HOME_DEFPATH "/var/topmq"
#define VAR_TOPMQM_QMGRS_PATH "qmgrs"
#define VAR_TOPMQM_QMGR_PATH "mqm"
#define VAR_TOPMQM_DATA_PATH "data"
#define VAR_TOPMQM_EXPIRE_PATH "expire"
#define VAR_TOPMQM_QUE_PATH "queues"
#define VAR_TOPMQM_CHL_PATH "channels"
#define VAR_TOPMQM_LSR_PATH "listeners"
#define VAR_TOPMQM_TRACE_PATH "trace"
#define VAR_TOPMQM_ERROR_PATH "errors"
#define VAR_TOPMQM_ERROR_FILE "ERROR.LOG"

#define VAR_TOPMQM_CMD_QUEUE "SYS.Q.CMD"
#define VAR_TOPMQM_DEAD_QUEUE "SYS.Q.DEAD"
#define VAR_TOPMQM_ERR_QUEUE "SYS.Q.ERRMSG"
#define VAR_TOPMQM_EXPIRE_QUEUE "SYS.Q.EXPIRE"
#define VAR_TOPMQM_CMD_MSGTYPE 654321

#define VAR_TOPMQM_ETCNAME "topmq.ini"

#define CFG_TOPMQM_GENERAL_SECTION "general"
#define CFG_TOPMQM_RUNLEVEL "runlevel"
/*---------------------------- Type define ------------------------------*/

typedef struct {
    char sObjName[DLEN_TOPMQ_OBJECT_NAME];
    T_TMQ_OBJ_DB_HANDLE hObjDB;
    T_TMQ_QUE_DB_HANDLE hQueDB;
} T_TOPMQ_QMGR_CTX;

/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

char * TMQ_GetMQMHome(void);
char * TMQ_GetConfFile(void);
char * TMQ_GetQmgrName(void);
int TMQ_SetQmgrName(char *psQmgrName);

int TMQ_GetLogLevel(void);

int TMQ_InitQmgrCtx(T_TOPMQ_QMGR_CTX * ptCtx, char *psQmgrName);

#ifdef __cplusplus
}
#endif

#endif /*_TOPMQ_AC_H_20100122202625_*/
/*-----------------------------  End ------------------------------------*/
