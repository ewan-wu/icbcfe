/*
 *
 * 
 * topmq object interface define.
 * 
 * 
 * FileName: topmq_object.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _TOPMQ_OBJECT_H_20110601203041_
#define _TOPMQ_OBJECT_H_20110601203041_
/*--------------------------- Include files -----------------------------*/
#include "topmq_def.h"
/*--------------------------- Macro define ------------------------------*/

/*-------------------------------------------------------*/
/*���ȶ���*/
/*-------------------------------------------------------*/
#define DLEN_TOPMQ_PATH_MAX   512
#define DLEN_TOPMQ_TYPE 32
#define DLEN_TOPMQ_OBJECT_NAME 32
#define DLEN_TOPMQ_FMT 8
#define DLEN_TOPMQ_LEN 8
#define DLEN_TOPMQ_DATE 8
#define DLEN_TOPMQ_TIME 6
#define DLEN_TOPMQ_TIME2 9
#define DLEN_TOPMQ_DATETIME (DLEN_TOPMQ_API_DATE+DLEN_TOPMQ_API_TIME)
#define DLEN_TOPMQ_DATETIME2 (DLEN_TOPMQ_API_DATE+DLEN_TOPMQ_API_TIME2)
#define DLEN_TOPMQ_ACCESSORIES_FILE_NUM_MAX 30
#define DLEN_TOPMQ_ACCESSORIES_FILENAME_MAX 512
#define DLEN_TOPMQ_IPADDR 60
#define DLEN_TOPMQ_CONNNAME 125
#define DLEN_TOPMQ_PASS 20
#define DLEN_TOPMQ_UERID 6
#define DLEN_TOPMQ_TRIGDATA 60
#define DLEN_TOPMQ_SSLCIPH 30
#define DLEN_TOPMQ_CMD 1024
#define DLEN_TOPMQ_DEFPRTY 1
#define DLEN_TOPMQ_STATUS 32
#define DLEN_TOPMQ_USAGE 32

#define DLEN_TOPMQ_QUE_CNT_MAX 1000
#define DLEN_TOPMQ_CHL_CNT_MAX 100
#define DLEN_TOPMQ_LSR_CNT_MAX 50

#define DLEN_TOPMQ_OBJ_DBTYPE_MAX   32

/*-------------------------------------------------------*/
/*�������Ͷ���*/
/*-------------------------------------------------------*/
#define VAR_TOPMQ_OBJ_TYPE_QMGR "QMGR"
#define VAR_TOPMQ_OBJ_TYPE_QMGRS "QMGRS"

/*queue*/
#define VAR_TOPMQ_OBJ_TYPE_Q "Q"
#define VAR_TOPMQ_OBJ_TYPE_QS "QS"

/*channel*/
#define VAR_TOPMQ_OBJ_TYPE_CHL "CHL"
#define VAR_TOPMQ_OBJ_TYPE_CHS "CHS"

/*listener*/
#define VAR_TOPMQ_OBJ_TYPE_LSR "LSR"
#define VAR_TOPMQ_OBJ_TYPE_LSRS "LSRS"

/*other*/
#define VAR_TOPMQ_OBJ_TYPE_NODE "NODE"
#define VAR_TOPMQ_OBJ_TYPE_CLUST "CLUST"

/*-------------------------------------------------------*/
/*�����������ƶ���*/
/*-------------------------------------------------------*/
/*���й�����������������������*/
#define VAR_TOPMQ_QMGR_COL_NAME "NAME"
#define VAR_TOPMQ_QMGR_COL_TYPE "TYPE"
#define VAR_TOPMQ_QMGR_COL_ALTDATE "ALTDATE"
#define VAR_TOPMQ_QMGR_COL_ALTTIME "ALTTIME"
#define VAR_TOPMQ_QMGR_COL_CRDATE "CRDATE"
#define VAR_TOPMQ_QMGR_COL_CRTIME "CRTIME"
#define VAR_TOPMQ_QMGR_COL_DEADQ "DEADQ"
#define VAR_TOPMQ_QMGR_COL_ERRQ "ERRQ"
#define VAR_TOPMQ_QMGR_COL_EXPIREQ "EXPIREQ"
#define VAR_TOPMQ_QMGR_COL_SEQNO "SEQNO"
#define VAR_TOPMQ_QMGR_COL_MAXSEQNO "MAXSEQNO"
#define VAR_TOPMQ_QMGR_COL_CAFILE "CAFILE"
#define VAR_TOPMQ_QMGR_COL_CERTFILE "CERTFILE"
#define VAR_TOPMQ_QMGR_COL_KEYFILE "KEYFILE"
#define VAR_TOPMQ_QMGR_COL_KEYPASS "KEYPASS"

/*���й�����״̬*/
#define VAR_TOPMQ_QMGR_COL_PID "PID"

/*���У�����������������*/
#define VAR_TOPMQ_QUE_COL_NAME "NAME"
#define VAR_TOPMQ_QUE_COL_TYPE "TYPE"
#define VAR_TOPMQ_QUE_COL_ALTDATE "ALTDATE"
#define VAR_TOPMQ_QUE_COL_ALTTIME "ALTTIME"
#define VAR_TOPMQ_QUE_COL_CRDATE "CRDATE"
#define VAR_TOPMQ_QUE_COL_CRTIME "CRTIME"
#define VAR_TOPMQ_QUE_COL_DEFPRTY "DEFPRTY"
#define VAR_TOPMQ_QUE_COL_INITQ "INITQ"
#define VAR_TOPMQ_QUE_COL_MAXDEPTH "MAXDEPTH"
#define VAR_TOPMQ_QUE_COL_MAXMSGL "MAXMSGL"
#define VAR_TOPMQ_QUE_COL_TRIGER "TRIGER"
#define VAR_TOPMQ_QUE_COL_TRIGDATA "TRIGDATA"
#define VAR_TOPMQ_QUE_COL_TRIGTYPE "TRIGTYPE"
#define VAR_TOPMQ_QUE_COL_TRIGDEPTH "TRIGDEPTH"
#define VAR_TOPMQ_QUE_COL_EXPIRE "EXPIRE"
#define VAR_TOPMQ_QUE_COL_USAGE "USAGE"
#define VAR_TOPMQ_QUE_COL_XMITQ "XMITQ"
#define VAR_TOPMQ_QUE_COL_REMOTEQ "REMOTEQ"
#define VAR_TOPMQ_QUE_COL_REMOTEQM "REMOTEQM"
#define VAR_TOPMQ_QUE_COL_IPCKEY "IPCKEY"
#define VAR_TOPMQ_QUE_COL_MSGDIR "MSGDIR"

/*���У�״̬*/
#define VAR_TOPMQ_QUE_COL_CURDEPTH "CURDEPTH"
#define VAR_TOPMQ_QUE_COL_QID "QID"
#define VAR_TOPMQ_QUE_COL_OPENED "OPENED"

/*ͨ��������������������*/
#define VAR_TOPMQ_CHL_COL_NAME "NAME"
#define VAR_TOPMQ_CHL_COL_TYPE "TYPE"
#define VAR_TOPMQ_CHL_COL_ALTDATE "ALTDATE"
#define VAR_TOPMQ_CHL_COL_ALTTIME "ALTTIME"
#define VAR_TOPMQ_CHL_COL_CRDATE "CRDATE"
#define VAR_TOPMQ_CHL_COL_CRTIME "CRTIME"
#define VAR_TOPMQ_CHL_COL_CONNAME "CONNAME"
#define VAR_TOPMQ_CHL_COL_CHLTYPE "CHLTYPE"
#define VAR_TOPMQ_CHL_COL_TRPTYPE "TRPTYPE"
#define VAR_TOPMQ_CHL_COL_DISCINT "DISCINT"
#define VAR_TOPMQ_CHL_COL_HBINT "HBINT"
#define VAR_TOPMQ_CHL_COL_LONGRTY "LONGRTY"
#define VAR_TOPMQ_CHL_COL_LONGTMR "LONGTMR"
#define VAR_TOPMQ_CHL_COL_SHORTRTY "SHORTRTY"
#define VAR_TOPMQ_CHL_COL_SHORTTMR "SHORTTMR"
#define VAR_TOPMQ_CHL_COL_MAXMSGL "MAXMSGL"
#define VAR_TOPMQ_CHL_COL_QMNAME "QMNAME"
#define VAR_TOPMQ_CHL_COL_SEQWRAP "SEQWRAP"
#define VAR_TOPMQ_CHL_COL_SSLCAUTH "SSLCAUTH"
#define VAR_TOPMQ_CHL_COL_SSLCIPH "SSLCIPH"
#define VAR_TOPMQ_CHL_COL_USERID "USERID"
#define VAR_TOPMQ_CHL_COL_XMITQ "XMITQ"
#define VAR_TOPMQ_CHL_COL_LOCLADDR "LOCLADDR"

/*ͨ����״̬*/
#define VAR_TOPMQ_CHL_COL_PID "PID"
#define VAR_TOPMQ_CHL_COL_STATUS "STATUS"
#define VAR_TOPMQ_CHL_COL_LOCALIP "LOCALIP"
#define VAR_TOPMQ_CHL_COL_LOCALPORT "LOCALPORT"
#define VAR_TOPMQ_CHL_COL_REMOTEIP "REMOTEIP"
#define VAR_TOPMQ_CHL_COL_REMOTEPORT "REMOTEPORT"


/*������������������������*/
#define VAR_TOPMQ_LSR_COL_NAME "NAME"
#define VAR_TOPMQ_LSR_COL_TYPE "TYPE"
#define VAR_TOPMQ_LSR_COL_ALTDATE "ALTDATE"
#define VAR_TOPMQ_LSR_COL_ALTTIME "ALTTIME"
#define VAR_TOPMQ_LSR_COL_CRDATE "CRDATE"
#define VAR_TOPMQ_LSR_COL_CRTIME "CRTIME"
#define VAR_TOPMQ_LSR_COL_LONGRTY "LONGRTY"
#define VAR_TOPMQ_LSR_COL_LONGTMR "LONGTMR"
#define VAR_TOPMQ_LSR_COL_SHORTRTY "SHORTRTY"
#define VAR_TOPMQ_LSR_COL_SHORTTMR "SHORTTMR"
#define VAR_TOPMQ_LSR_COL_PORT "PORT"
#define VAR_TOPMQ_LSR_COL_IPADDR "IPADDR"
#define VAR_TOPMQ_LSR_COL_USESSL "USESSL"
#define VAR_TOPMQ_LSR_COL_QMNAME "QMNAME"

/*ͨ����״̬*/
#define VAR_TOPMQ_LSR_COL_PID "PID"
#define VAR_TOPMQ_LSR_COL_STATUS "STATUS"


/*----------------------------------------------------*/
/*�������Գ�������*/
/*----------------------------------------------------*/
/*���й�����*/
#define VAR_TOPMQM_QMGR_TYPE_NR "NORMAL" /*��ͨ*/

/*����*/
#define VAR_TOPMQM_QUE_TYPE_QL "QL" /*���ض���*/
#define VAR_TOPMQM_QUE_TYPE_QR "QR" /*Զ�̶���*/

#define VAR_TOPMQM_QUE_OPEN_YES "YES" /*���д�*/
#define VAR_TOPMQM_QUE_OPEN_NO "NO"   /*���йر�*/
            
#define VAR_TOPMQM_QUE_TRIGER_ENABLE "ENABLE" /*���ô�����*/
#define VAR_TOPMQM_QUE_TRIGER_DISABLE "DISABLE" /*�����ô�����*/
#define VAR_TOPMQM_QUE_TRIGTYPE_FIRST "FIRST" /*�״δ���*/
#define VAR_TOPMQM_QUE_TRIGTYPE_EVERY "EVERY" /*ÿ�δ���*/
#define VAR_TOPMQM_QUE_TRIGTYPE_DEPTH "DEPTH" /*���е�һ����ȴ���*/
            
#define VAR_TOPMQM_QUE_USAGE_NORMAL "NORMAL" /*��ͨ����*/
#define VAR_TOPMQM_QUE_USAGE_SYSTEM "SYSTEM" /*ϵͳ����*/
#define VAR_TOPMQM_QUE_USAGE_XMIT "XMIT" /*�������*/
            
#define VAR_TOPMQM_QUE_STATUS_OPENED "OPENED" /*���б���*/
#define VAR_TOPMQM_QUE_STATUS_NOTOPENED "NOTOPENED" /*����û�б���*/

/*ͨ��*/            
#define VAR_TOPMQM_CHL_TYPE_NORMAL "NORMAL" /*��ͨͨ��*/
#define VAR_TOPMQM_CHL_TYPE_SYSTEM "SYSTEM" /*ϵͳͨ��*/
            
#define VAR_TOPMQM_CHL_CHLTYPE_SNDR "SNDR" /*ͨ��������*/
#define VAR_TOPMQM_CHL_CHLTYPE_RCVR "RCVR" /*ͨ��������*/
            
#define VAR_TOPMQM_CHL_TRPTYPE_TCP "TCP" /*TCPЭ��*/
            
#define VAR_TOPMQM_CHL_SSLCAUTH_ENABLE "ENABLE" /*����SSL��֤*/
#define VAR_TOPMQM_CHL_SSLCAUTH_DISABLE "DISABLE" /*������SSL��֤*/
#define VAR_TOPMQM_CHL_DEF_LADDR "0.0.0.0"
           
#define VAR_TOPMQM_CHL_STATUS_STOPED "STOPED" /*��ֹͣ*/
#define VAR_TOPMQM_CHL_STATUS_BINDING "BINDING" /*��*/
#define VAR_TOPMQM_CHL_STATUS_RUNING "RUNING" /*��������*/
#define VAR_TOPMQM_CHL_STATUS_RETRYING "RETRYING" /*����*/

/*������*/            
#define VAR_TOPMQM_LSR_TYPE_NORMAL "NORMAL" /*��ͨ������*/
            
#define VAR_TOPMQM_LSR_STATUS_STOPED "STOPED" /*��ֹͣ*/
#define VAR_TOPMQM_LSR_STATUS_BINDING "BINDING" /*��*/
#define VAR_TOPMQM_LSR_STATUS_RUNING "RUNING" /*��������*/

#define VAR_TOPMQM_LSR_DEF_LPORT 5151
#define VAR_TOPMQM_LSR_DEF_LADDR "0.0.0.0"
#define VAR_TOPMQM_LSR_USESSL_YES "YES" /*SSL*/
#define VAR_TOPMQM_LSR_USESSL_NO "NO" /*NO SSL*/
/*----------------------------------------------------*/
/*�����붨��*/
/*----------------------------------------------------*/
#define ERR_TOPMQ_OBJ_OK 0

#define ERR_TOPMQ_OBJ_BASE (-7000)
#define ERR_TOPMQ_OBJ_NOTFOUND (ERR_TOPMQ_OBJ_BASE-1)
#define ERR_TOPMQ_OBJ_OPEN (ERR_TOPMQ_OBJ_BASE-4)
#define ERR_TOPMQ_OBJ_FETCH (ERR_TOPMQ_OBJ_BASE-5)
#define ERR_TOPMQ_OBJ_CLOSE (ERR_TOPMQ_OBJ_BASE-6)
#define ERR_TOPMQ_OBJ_CONN (ERR_TOPMQ_OBJ_BASE-7)
#define ERR_TOPMQ_OBJ_DISCONN (ERR_TOPMQ_OBJ_BASE-8)
#define ERR_TOPMQ_OBJ_COMMIT (ERR_TOPMQ_OBJ_BASE-9)
#define ERR_TOPMQ_OBJ_ROLLBACK (ERR_TOPMQ_OBJ_BASE-10)
#define ERR_TOPMQ_OBJ_DECLARE (ERR_TOPMQ_OBJ_BASE-11)
#define ERR_TOPMQ_OBJ_ANALYSQL (ERR_TOPMQ_OBJ_BASE-12)
#define ERR_TOPMQ_OBJ_INIT (ERR_TOPMQ_OBJ_BASE-20)
#define ERR_TOPMQ_OBJ_PARAM (ERR_TOPMQ_OBJ_BASE-21)
#define ERR_TOPMQ_OBJ_HANDLE (ERR_TOPMQ_OBJ_BASE-22)
#define ERR_TOPMQ_OBJ_SPACE (ERR_TOPMQ_OBJ_BASE-23)
#define ERR_TOPMQ_OBJ_STAT (ERR_TOPMQ_OBJ_BASE-24)
#define ERR_TOPMQ_OBJ_EXIST (ERR_TOPMQ_OBJ_BASE-25)
#define ERR_TOPMQ_OBJ_UNKNOW (ERR_TOPMQ_OBJ_BASE-500)

/*---------------------------- Type define ------------------------------*/
typedef void * T_TMQ_OBJ_DB_HANDLE;
typedef void * T_TMQ_OBJ_CUR_HANDLE;

typedef struct {
    char sDbType[DLEN_TOPMQ_OBJ_DBTYPE_MAX];
} T_TOPMQ_OBJ_CREATE_CTX_OPT;
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif

/*context*/
int TMQ_ObjCreateCtx(T_TOPMQ_OBJ_CREATE_CTX_OPT *ptOpt);

/*-----------------------------------------------------------*/
/*object database interface*/
/*-----------------------------------------------------------*/
int TMQ_ObjDBCreate(char *psName, int iOptions);
int TMQ_ObjDBDelete(char *psName, int iOptions);
int TMQ_ObjDBOpen(char *psName, int iOptions);
int TMQ_ObjDBClose(char *psName, int iOptions);

T_TMQ_OBJ_DB_HANDLE TMQ_ObjDBConn(char *psName, int iOptions);
int TMQ_ObjDBDisConn(T_TMQ_OBJ_DB_HANDLE hDB, int iOptions);

/*for test*/
int TMQ_ObjDBIsExist(char *psName);
int TMQ_ObjDBIsOpen(char *psName);

/*-----------------------------------------------------------*/
/*object interface*/
/*-----------------------------------------------------------*/
int TMQ_ObjAdd(T_TMQ_OBJ_DB_HANDLE hDB, char *psObjType, char *psName, int iAttrNum, char *psAttrNames[], char *psAttrs[], int iOptions);
int TMQ_ObjDel(T_TMQ_OBJ_DB_HANDLE hDB, char *psObjType, char *psName, int iOptions);

int TMQ_ObjSetAttr(T_TMQ_OBJ_DB_HANDLE hDB, char *psObjType, char *psName, int iAttrNum, char *psAttrNames[], char *psAttrs[]);
int TMQ_ObjGetAttr(T_TMQ_OBJ_DB_HANDLE hDB, char *psObjType, char *psName, int iAttrNum, char *psAttrNames[], char *psAttrs[]);

int TMQ_ObjSetAttrV(T_TMQ_OBJ_DB_HANDLE hDB, char *psObjType, char *psName, int iAttrNum, ...);
int TMQ_ObjGetAttrV(T_TMQ_OBJ_DB_HANDLE hDB, char *psObjType, char *psName, int iAttrNum, ...);

T_TMQ_OBJ_CUR_HANDLE TMQ_ObjCurOpen(T_TMQ_OBJ_DB_HANDLE hDB, char *psObjType, char *psName);
int TMQ_ObjCurFetch(T_TMQ_OBJ_DB_HANDLE hDB, T_TMQ_OBJ_CUR_HANDLE hCur, int iAttrNum, char *psAttrNames[], char *psAttrs[]);
int TMQ_ObjCurUpdate(T_TMQ_OBJ_DB_HANDLE hDB, T_TMQ_OBJ_CUR_HANDLE hCur, int iAttrNum, char *psAttrNames[], char *psAttrs[]);
int TMQ_ObjCurClose(T_TMQ_OBJ_DB_HANDLE hDB, T_TMQ_OBJ_CUR_HANDLE hCur);

/*for test*/
int TMQ_ObjIsExist(T_TMQ_OBJ_DB_HANDLE hDB, char *psObjType, char *psName);

/*-----------------------------------------------------------*/
/*error interface*/
/*-----------------------------------------------------------*/
char * TMQ_ObjGetError(void);
int TMQ_ObjGetRCode(void);

/*-----------------------------------------------------------*/
/**/
/*-----------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif /*_TOPMQ_OBJECT_H_20110601203041_*/
/*-----------------------------  End ------------------------------------*/
