/*
 *
 * 
 * script anly.
 * 
 * 
 * FileName: topmq_script.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 */
#ifndef _TOPMQ_SCRIPT_H_20110601194504_
#define _TOPMQ_SCRIPT_H_20110601194504_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/
#define DLEN_TOPMQ_SC_ANALYZE_OPERPARAM_NUM_MAX 100
#define DLEN_TOPMQ_SC_ANALYZE_SC_LEN_MAX 10240
#define DLEN_TOPMQ_SC_ANALYZE_OPER_NAME 32
/*---------------------------- Type define ------------------------------*/
typedef struct {
    int iCode;
    char sName[DLEN_TOPMQ_SC_ANALYZE_OPER_NAME];
    char sFullName[DLEN_TOPMQ_SC_ANALYZE_OPER_NAME];
} T_TOPMQ_SC_OPERATOR_CODE;

typedef struct {
    char *psParamName;
    char *psParamValue;
} T_TOPMQ_SC_OPERPARAM;

typedef struct {
    int iOperCode;
    int iParamCnt;
    T_TOPMQ_SC_OPERPARAM tOperParams[DLEN_TOPMQ_SC_ANALYZE_OPERPARAM_NUM_MAX];
    char psSc[DLEN_TOPMQ_SC_ANALYZE_SC_LEN_MAX];
} T_TOPMQ_SC_OPERS;
/*---------------------- Global function declaration --------------------*/

#ifdef __cplusplus
extern "C" {
#endif
int TMQ_SCAnalyze(char *psInput, T_TOPMQ_SC_OPERATOR_CODE *ptOperCode, int iOperCodeNum, T_TOPMQ_SC_OPERS *ptAnlYRes, char *psDesc);

#ifdef __cplusplus
}
#endif

#endif /*_TOPMQ_SCRIPT_H_20110601194504_*/
/*-----------------------------  End ------------------------------------*/
