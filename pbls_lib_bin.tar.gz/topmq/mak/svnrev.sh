#!/bin/sh

SELF=`basename "$0" | sed 's/\(.*\)\..*/\1/'`

usage()
{
    echo "  Usage: $SELF [-p] [-l filelist] [-f file] <-w workhome> <-o outfile>"
    exit 1 
}

while getopts w:o:l:f:p OPTION; do
    case $OPTION in
        w) WORK_HOME=$OPTARG ;;
        o) OUTFILE=$OPTARG ;;
        l) FILELIST=$OPTARG ;;
        f) CFILE=$OPTARG ;;
        p) PRINTF="YES" ;;
        ?) usage ;;
    esac
done
shift `expr $OPTIND - 1`

if [ -z "$OUTFILE" ]; then
    usage
fi

if [ ! -f "$OUTFILE" ]; then
    REV="0"
else
    REV=`cat $OUTFILE`
fi

if [ ! -z "$PRINTF" ]; then
    if [ "$REV" -eq "0" ]; then
        echo "__FILE_REV__"
    else
        echo "\"\$Rev: $REV \$\""
    fi
    exit 0
fi

if [ ! -z "$FILELIST" -a -f "$FILELIST" ]; then
    file=`cat $FILELIST | sed 's/^.*\.o://g;s/\\\\//g;' | tr ' ' '\n' | grep "$WORK_HOME"`
    rm -rf $FILELIST
fi

if [ ! -z "$file" -o ! -z "$CFILE" ]; then
    NEWREV=`env LIBPATH=. LANG=C LC_ALL=C svn info $file $CFILE 2>/dev/null | grep "Last Changed Rev" | awk '{print $4}' | sort -n -r | sed -n 1p`
    if [ -z "$NEWREV" ]; then
        echo "$REV" > $OUTFILE
    else
        if [ "$NEWREV" -gt "$REV" ]; then
            echo "$NEWREV" > $OUTFILE
        else
            echo "$REV" > $OUTFILE
        fi
    fi
fi
