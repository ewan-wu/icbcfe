delete from ICBC_ROUTE;
INSERT INTO "ICBC_ROUTE" VALUES ('1', '2001', '2002', 'icbclocswt->icbcoutswt', 'icbclocswt', 'icbcoutswt', '02', '1', null, null, null, null, null);
INSERT INTO "ICBC_ROUTE" VALUES ('1', '2002', '2021', 'icbcoutswt->icbcoutcomm', 'icbcoutswt', 'icbcoutcomm', '01', '1', null, null, null, null, null);
INSERT INTO "ICBC_ROUTE" VALUES ('1', '2003', '2021', 'icbcinswt->icbcoutcomm', 'icbcinswt', 'icbcoutcomm', '01', '1', null, null, null, null, null);
INSERT INTO "ICBC_ROUTE" VALUES ('2', '2021', '2003', 'icbcincomm->icbcinswt', 'icbcincomm', 'icbcinswt', '02', '1', null, null, null, null, null);
INSERT INTO "ICBC_ROUTE" VALUES ('2', '2003', '2001', 'icbcinswt->icbclocswt', 'icbcinswt', 'icbclocswt', '02', '1', null, null, null, null, null);
INSERT INTO "ICBC_ROUTE" VALUES ('2', '2002', '2001', 'icbcoutswt->icbclocswt', 'icbcoutswt', 'icbclocswt', '02', '1', null, null, null, null, null);
COMMIT;
