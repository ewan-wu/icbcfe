delete from ICBC_ROUTE_LOC;
INSERT INTO "ICBC_ROUTE_LOC" VALUES ('1', '1', '7', '1', '1', null, null, null, null, null);
COMMIT;
