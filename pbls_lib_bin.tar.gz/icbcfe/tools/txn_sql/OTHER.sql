delete from ICBC_BIZSQL_CFG where SQL_ID='ICBC_GEN_ID';
insert into ICBC_BIZSQL_CFG (SQL_ID, SQL_STRING, SQL_DESC)
values ('ICBC_GEN_ID', 'select to_char(sysdate, ''yyyymmdd'') || lpad(ICBC_ID_SEQ.NEXTVAL,8,''0'') as "api.ID" from dual', 'GEN ICBC ID');

delete from ICBC_BIZSQL_CFG where SQL_ID='ICBC_INSERT_FILE';
insert into ICBC_BIZSQL_CFG (SQL_ID, SQL_STRING, SQL_DESC)
values ('ICBC_INSERT_FILE', 'insert into ICBC_FILE_TXN (ID, FILE_TYPE, FILE_NAME, RCV_TIME) values (:"api.ID", case :"var.inmsgid" when ''NFOCDTLZ'' then ''1'' when ''B_DLTY01'' then ''2'' end, :"gvar.inmsg_accs0", TO_CHAR(SYSDATE,''YYYYMMDDHH24MISS'')', 'ICBC_INSERT_FILE');

delete from ICBC_BIZSQL_CFG where SQL_ID='ICBC_GEN_REFERNCE_SQL';
insert into ICBC_BIZSQL_CFG (SQL_ID, SQL_STRING, SQL_DESC)
values ('ICBC_GEN_REFERNCE_SQL', 'select ''501290000012'' || to_char(sysdate, ''yyyymmdd'') || lpad(ICBC_ID_SEQ.NEXTVAL,8,''0'') as "api.REFERNCE" from dual', 'GEN ICBC REFERNCE');

delete from ICBC_BIZFLOW_CFG where FLOW_ID='ICBC_GEN_REFERNCE';
insert into ICBC_BIZFLOW_CFG (FLOW_ID, FLOW_QUEUE, FLOW_TYPE, SQL_ID, SUC_SQLCODE, NOR_QUIT_FLAG, FLOW_DESC, STATUS)
values ('ICBC_GEN_REFERNCE', 10, '1', 'ICBC_GEN_REFERNCE_SQL', '0', '0', 'Gen Icbc Refernce', '1');

delete from ICBC_BIZSQL_CFG where SQL_ID='ICBC_OUT_MAKE_PKG_HEAD';
insert into ICBC_BIZSQL_CFG (SQL_ID, SQL_STRING, SQL_DESC)
values ('ICBC_OUT_MAKE_PKG_HEAD', 'select :"inmsg.Txnno" as "outmsg.Txnno", :"inmsg.Id" as "outmsg.PkgId", :"inmsg.PkgFmt" as "outmsg.PkgFmt" from dual', 'MAKE PKG HEAD');

delete from ICBC_BIZSQL_CFG where SQL_ID='MAKE_IN_MESSAGE';
insert into ICBC_BIZSQL_CFG (SQL_ID, SQL_STRING, SQL_DESC)
values ('MAKE_IN_MESSAGE', 'select :"inmsg.Txnno" as "outmsg.Txnno",:"inmsg.PkgFmt" as "outmsg.PkgFmt", :"api.ID" as "outmsg.Id", substr(:"inmsg.Txnno", 2, 5) as "outmsg.PkgNo",:"api.ORG_ID" as "outmsg.Oid", substr(:"inmsg.Txnno", 2, 5) as "outmsg.OPkgNo" from dual', 'MAKE INNER BANK MESSAGE');

delete from ICBC_BIZSQL_CFG where SQL_ID='MAKE_OUT_ERR_MESSAGE';
insert into ICBC_BIZSQL_CFG (SQL_ID, SQL_STRING, SQL_DESC)
values ('MAKE_OUT_ERR_MESSAGE', 'select ''00000000'' as "errmsg.Txnno",:"inmsg.PkgFmt" as "errmsg.PkgFmt", :"inmsg.ID" as "errmsg.Id", ''00000'' as "errmsg.PkgNo",:"inmsg.ID" as "errmsg.Oid", :"inmsg.PkgNo" as "errmsg.OPkgNo" from dual', 'MAKE INNER BANK ERROR MESSAGE');

delete from ICBC_BIZSQL_CFG where SQL_ID='MAKE_RECV_ERR_MESSAGE';
insert into ICBC_BIZSQL_CFG (SQL_ID, SQL_STRING, SQL_DESC)
values ('MAKE_RECV_ERR_MESSAGE', 'select ''00000000'' as "outmsg.Txnno",:"inmsg.PkgFmt" as "outmsg.PkgFmt", :"inmsg.PkgId" as "outmsg.Id", ''00000'' as "outmsg.PkgNo", :"inmsg.PkgId" as "outmsg.Oid", substr(:"inmsg.Txnno", 2, 5) as "outmsg.OPkgNo" from dual', 'MAKE INNER BANK ERROR MESSAGE');

delete from ICBC_BIZSQL_CFG where SQL_ID='MAKE_IN_ERR_MESSAGE';
insert into ICBC_BIZSQL_CFG (SQL_ID, SQL_STRING, SQL_DESC)
values ('MAKE_IN_ERR_MESSAGE', 'select ''00000000'' as "outmsg.Txnno",:"inmsg.PkgFmt" as "outmsg.PkgFmt", :"api.ORG_ID" as "outmsg.Id", ''00000'' as "outmsg.PkgNo", :"api.ORG_ID" as "outmsg.Oid", substr(:"inmsg.Txnno", 2, 5) as "outmsg.OPkgNo" from dual', 'MAKE INNER BANK MESSAGE');

delete from ICBC_BIZSQL_CFG where SQL_ID='ICBC_40004_REQ_RESEND_OUT_MAKE_PKG';
insert into ICBC_BIZSQL_CFG (SQL_ID, SQL_STRING, SQL_DESC)
values ('ICBC_40004_REQ_RESEND_OUT_MAKE_PKG', 'select ''14000411'' as "outmsg.Txnno", :"inmsg.PkgId" as "outmsg.PkgId", :"inmsg.PkgFmt" as "outmsg.PkgFmt", VERSION as "outmsg.VERSION",REFERNCE as "outmsg.REFERNCE",BUSINESS_CODE as "outmsg.BUSINESS_CODE",TRADE_SOURCE as "outmsg.TRADE_SOURCE",S_INSTITUTION_ID as "outmsg.S_INSTITUTION_ID",S_INSTITUTION_NAME as "outmsg.S_INSTITUTION_NAME",S_BRANCH_ID as "outmsg.S_BRANCH_ID",S_BRANCH_NAME as "outmsg.S_BRANCH_NAME",S_SUB_BRANCH_ID as "outmsg.S_SUB_BRANCH_ID",S_SUB_BRANCH_NAME as "outmsg.S_SUB_BRANCH_NAME",R_INSTITUTION_ID as "outmsg.R_INSTITUTION_ID",R_INSTITUTION_NAME as "outmsg.R_INSTITUTION_NAME",R_BRANCH_ID as "outmsg.R_BRANCH_ID",R_BRANCH_NAME as "outmsg.R_BRANCH_NAME",R_SUB_BRANCH_ID as "outmsg.R_SUB_BRANCH_ID",R_SUB_BRANCH_NAME as "outmsg.R_SUB_BRANCH_NAME",TRADE_DATE as "outmsg.TRADE_DATE",TRADE_TIME as "outmsg.TRADE_TIME",CODE as "outmsg.CODE",INFO as "outmsg.INFO",MAC as "outmsg.MAC",BUSIDATE as "outmsg.BUSIDATE",INIT_FLAG as "outmsg.INIT_FLAG",ROW_REQ as "outmsg.ROW_REQ",BEGINDATE as "outmsg.BEGINDATE",ENDDATE as "outmsg.ENDDATE",LOWLIMIT as "outmsg.LOWLIMIT",HIGHLIMIT as "outmsg.HIGHLIMIT",HZBANKNO as "outmsg.HZBANKNO",HZBANKBIC as "outmsg.HZBANKBIC",ACCNO as "outmsg.ACCNO",CURRTYPE as "outmsg.CURRTYPE", :"inmsg.BACKUP43" as "outmsg.SORTFIELD", :"inmsg.BACKUP43" as "outmsg.BKCHAR1",BKCHAR2 as "outmsg.BKCHAR2",BKCHAR3 as "outmsg.BKCHAR3" from ICBC_40004_REQ_TXN where ID =:"api.ORG_ID"', 'ICBC 40004 MAKE RESEND MESSAGE');
