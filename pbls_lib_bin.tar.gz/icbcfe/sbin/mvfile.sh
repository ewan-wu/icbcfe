today=`date +%Y-%m-%d`
yesterday=`TZ=aaa24 date +%Y%m%d`
echo [`date`]startmvfile...>>getfile.log
mv ${HOME}/icbcfe/file/tmp/NFOCDTLZ_${today}.bin ${HOME}/icbcfe/file/recv/.
mv ${HOME}/icbcfe/file/tmp/NFOCDTLZ_${yesterday}.bin ${HOME}/icbcfe/file/recv/.
mv ${HOME}/icbcfe/file/tmp/B_DLTY01_${today}.bin  ${HOME}/icbcfe/file/recv/.
mv ${HOME}/icbcfe/file/tmp/B_DLTY01_${yesterday}.bin  ${HOME}/icbcfe/file/recv/.
#mv ${HOME}/icbcfe/file/tmp/NFOCDTLZ_20110831.bin ${HOME}/icbcfe/file/recv/NFOCDTLZ_20110831.bin
#mv ${HOME}/icbcfe/file/tmp/B_DLTY01_20110831.bin  ${HOME}/icbcfe/file/recv/B_DLTY01_20110831.bin
echo [`date`]endmvNFNFDTLfile!>>getfile.log
