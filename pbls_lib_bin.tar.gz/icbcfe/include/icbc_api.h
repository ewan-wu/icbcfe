/*
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.  
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT 
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF 
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  icbc api define.
 *
 *  $Id$
 *
 * FileName: ccb_api.h 
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 *  2010/08/12         zy                       Create.
 *
 */

#ifndef _ICBC_API_H_20100812111930_
#define _ICBC_API_H_20100812111930_

/*------------------------ Include files ------------------------*/

#if 0
#pragma mark -
#pragma mark < Macro define >
#endif
/*--------------------- Macro define ----------------------------*/
#define ICBC_API_OK 0

#define ICBC_API_ERR_BASE       -1000
#define ICBC_API_ERR_PARAM      (ICBC_API_ERR_BASE - 1)
#define ICBC_API_NOT_INIT       (ICBC_API_ERR_BASE - 2)
#define ICBC_API_NOT_BEGIN      (ICBC_API_ERR_BASE - 3)

/*ҵ������ش���*/
#define ICBC_API_ERR_STATUS     (ICBC_API_ERR_BASE - 200)             /*״̬����*/
#define ICBC_API_ERR_ID         (ICBC_API_ERR_BASE - 201)             /*ID����*/
#define ICBC_API_ERR_SMPNO      (ICBC_API_ERR_BASE - 202)             /*IbpsNo����*/
#define ICBC_API_ERR_BIZTYPE    (ICBC_API_ERR_BASE - 203)             /*ҵ�����Ͳ���ȷ*/
#define ICBC_API_ERR_TXTYPE     (ICBC_API_ERR_BASE - 204)             /*�������Ͳ���ȷ*/
#define ICBC_API_ERR_INDOPER    (ICBC_API_ERR_BASE - 205)             /*��Ч����*/
#define ICBC_API_ERR_INDTRTYPE  (ICBC_API_ERR_BASE - 206)             /*��Ч�������ʱ��*/

/*ϵͳ����*/
#define ICBC_API_ERR_CREATQ     (ICBC_API_ERR_BASE - 300)              /*������Ϣ����ʧ��*/
#define ICBC_API_ERR_SNDMSG     (ICBC_API_ERR_BASE - 301)              /*������Ϣʧ��*/
#define ICBC_API_ERR_GETMSG     (ICBC_API_ERR_BASE - 302)              /*������Ϣʧ��*/
#define ICBC_API_ERR_GETID      (ICBC_API_ERR_BASE - 303)              /*������ID����*/
#define ICBC_API_ERR_GETGLBVAR  (ICBC_API_ERR_BASE - 304)              /*����ȫ�ֲ���ʧ��*/

/* Len Define */
#define DLEN_ICBC_ID 16
#define DLEN_ICBC_PKGNO 5
#define DLEN_ICBC_DATE 8
#define DLEN_ICBC_BIZ_EXTDATA 32

#if 0
#pragma mark -
#pragma mark < Type define >
#endif
/*--------------------- Type define -----------------------------*/
typedef struct {
    char sId[DLEN_ICBC_ID];                    /*��¼ID*/
    char sPkgNo[DLEN_ICBC_PKGNO];              /*���ı��*/
    char sWorkDate[DLEN_ICBC_DATE];            /*��������*/
    char sOId[DLEN_ICBC_ID];                   /*ԭ��¼ID*/
    char sOPkgNo[DLEN_ICBC_PKGNO];             /*ԭ���ı��*/
    char sOWorkDate[DLEN_ICBC_DATE];           /*ԭ��������*/
    char cResndFlg;                           /*����1 ����Ϊ����������*/
    char sExtData[DLEN_ICBC_BIZ_EXTDATA];      /*��չ�ֶ�*/
} T_ICBC_API_IPCMSG;


#if 0
#pragma mark -
#pragma mark < Global functions declaration >
#endif
/*--------------------- Global function declaration -------------*/
#ifdef __cplusplus
extern "C" {
#endif
    
    int ICBC_API_INIT(char *psLogFile, int nSrvId);
    int ICBC_API_END();
    
    int ICBC_CALL_API(char *psOprId);
    int ICBC_CALL_API_BEGIN();
    int ICBC_CALL_API_END();
    
    int ICBC_API_RECV(T_ICBC_API_IPCMSG *ptIpcMsg);
    int ICBC_API_SEND(T_ICBC_API_IPCMSG *ptIpcMsg);
    
    int ICBC_API_SET_VALUE(char *psTag, char *psValue, int nLen);
    int ICBC_API_GET_VALUE(char *psTag, char *psValue, int nLen);
    
    int ICBC_API_SET_VALUE_INT(char *psTag, int nValue);
    int ICBC_API_GET_VALUE_INT(char *psTag);
    
    int ICBC_API_SET_VALUE_LONG(char *psTag, long nValue);
    long ICBC_API_GET_VALUE_LONG(char *psTag);
    
    double ICBC_API_SET_VALUE_DOUBLE(char *psTag, double dValue);
    double ICBC_API_GET_VALUE_DOUBLE(char *psTag);
    
#ifdef __cplusplus
}
#endif
/*--------------------- Global variable -------------------------*/

#endif /* _ICBC_API_H_20100812111930_ */
/*--------------------- End -------------------------------------*/
