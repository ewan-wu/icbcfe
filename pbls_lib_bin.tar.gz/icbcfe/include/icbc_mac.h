/*
 * Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.
 * All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 * SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 * BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM
 * IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 * SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 * Mac Function Wrap
 *
 * $Id$
 *
 * FileName: icbc_mac.h
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 * 2011/06/01        YY                        Create.
 */
#ifndef _ICBC_MAC_H_20110601152308_
#define _ICBC_MAC_H_20110601152308_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/
#define	ICBC_MAC_BUFFER_LENTH	512

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/
#ifdef __cplusplus
extern "C" {
#endif

int icbcMacGen(char sKey[32+1], char *sData, char sMac[16+1]);

int icbcMacAutoInit  (char *sTable, char *sKey, char *sKeyAlgo);
int icbcMacAutoGen   (char *sMacPkgno);
int icbcMacAutoVerify(char *sMacPkgno);

#ifdef __cplusplus
}
#endif

#endif /*_ICBC_MAC_H_20110601152308_*/
/*-----------------------------  End ------------------------------------*/
