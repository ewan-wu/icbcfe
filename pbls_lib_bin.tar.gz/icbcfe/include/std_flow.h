/*
 * Copyright 2010, Shanghai Huateng Software Systems Co., Ltd.
 * All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 * SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 * BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM
 * IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 * SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 * 
 * flow control functions.
 * 
 * $Id$
 * 
 * FileName: flow.h
 * 
 *  <Date>        <Author>       <Auditor>     <Desc>
 * 2010/07/19        YY                        Create.
 */
#ifndef _STD_FLOW_H_20100719105856_
#define _STD_FLOW_H_20100719105856_
/*--------------------------- Include files -----------------------------*/

/*--------------------------- Macro define ------------------------------*/

/*---------------------------- Type define ------------------------------*/

/*---------------------- Global function declaration --------------------*/
#ifdef __cplusplus
extern "C" {
#endif
/**
 * flowInit
 *
 * @param sPrefix: ����ǰ׺ ����:"TB_"
 *
 * @return 0:�ɹ�
 *       !=0:����
 *
 */
int	flowInit(char *sPrefix);
/**
 * flowCheckStatus
 *
 * @param sId: ʶ�����
 * @param sStatus: ��ǰ״̬
 * @param *piRet: ����ֵ��1-��ǰ״̬�Ϸ� 0-��ǰ״̬���Ϸ�
 *
 * @return 0:�ɹ�
 *       !=0:����
 *
 */
int	flowCheckStatus(char *sId, char *sStatus, int *piRet);
/**
 * flowInit
 *
 * @param sId: ʶ�����
 * @param iBranch: ��֧����
 * @param sStartStatus: ��ǰ״̬(��ʼ״̬)
 * @param sStatus: ��һ״̬
 *
 * @return 0:�ɹ�
 *       !=0:����
 *
 */
int	flowGetNextStatus(char *sId, int iBranch, char *sStartStatus, char *sStatus);

#ifdef __cplusplus
}
#endif

#endif /*_STD_FLOW_H_20100719105856_*/
/*-----------------------------  End ------------------------------------*/
