/*
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.  
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT 
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF 
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  Proc ICBC Trans 40004.
 *
 *  $Id$
 *
 * FileName: txn_40004_proc.c 
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 *  2011/04/25         zy                       Create.
 *
 */

/*------------------------ Include files ------------------------*/
#include "bizflow.h"
#include "log_info.h"
#include "poc_object.h"
#include "biz_helper.h"
#include "icbc_mac.h"

#if 0
#pragma mark -
#pragma mark < Macro define >
#endif
/*--------------------- Macro define ----------------------------*/
#define DLEN_ID 16

#define DB_PROC( sql ) \
do { \
    int nRet = BizFlowExecSqlById( (sql) ); \
    if ( nRet != FUNC_OK ) { \
        logInfo(LOG_ERR, "sql Proc[" sql "] err[%d]", nRet); \
        return (FUNC_ERR); \
    } \
}while (0);
    
#if 0
#pragma mark -
#pragma mark < Type define >
#endif
/*--------------------- Type define -----------------------------*/

/*--------------------- Local function declaration --------------*/
static int Proc40004MakePkg();
static int Proc40004Detail();
static int Proc40004Message();

/*--------------------- Global variable -------------------------*/

#if 0
#pragma mark -
#pragma mark < Global functions >
#endif
/*--------------------- Global functions ------------------------*/
int txn_40004_proc()
{
    int nRet;
    
    nRet = Proc40004Message();
    if ( nRet != FUNC_OK ) {
        return ( nRet );
    }
    
    nRet = Proc40004Detail();
    if ( nRet != FUNC_OK ) {
        return ( nRet );
    }
    
    nRet = Proc40004MakePkg();
    if ( nRet != FUNC_OK ) {
        return (nRet);
    }
    
    return (FUNC_OK);
}

#if 0
#pragma mark -
#pragma mark < Local functions >
#endif
/*--------------------- Local functions -------------------------*/
/**
 * Proc40004Message
 * Proc 40004 Respinse Message
 * If Has Response Just return 
 * If Not Insert into DB
 *
 * @param #: Void
 *
 * @return >0  : ok
 *         <0  : err
 */
static int Proc40004Message()
{
    /* Get 40004 Request Db Info */
    DB_PROC("ICBC_40004_RSP_IN_GET_ID");
    
    /* Check Is The Frist Response */
    char sId[DLEN_ID + 1];
    memset(sId, '\0', sizeof(sId));
    POC_GetValueS("api.ID", sId, DLEN_ID);
    if ( '\0' != sId[0] ) {
        return (FUNC_OK);
    }
    
    /* Make New Response, Gen New Response ID */
    DB_PROC("ICBC_GEN_ID");
    
    /* Insert Message Into Response Info */
    DB_PROC("ICBC_40004_RSP_IN_INSERT");

    return (FUNC_OK);
}

/**
 * Proc40004Detail
 * Proc 40004 Detail Messag Info
 * Inset Detil Messag Into Database
 *
 * @param #: void
 *
 * @return >0  : ok
 *         <0  : err
 */
static int Proc40004Detail()
{
    /* Get Index */
    DB_PROC("ICBC_40004_RSP_GET_DETAIL_INDEX");
    
    /* Insert Detail Info Into Db */
    int nDetailNum = POC_GetValueInt32("inmsg.RETNUM");
    int nDetailIndex = POC_GetValueInt32("api.RETNUM");

    logInfo(LOG_BUG, "Detail Num[%d]", nDetailNum);
    if ( nDetailNum >= 1 ) {
        logInfo(LOG_BUG, " Add Index[%d]", nDetailIndex+1);
        POC_SetValueInt32("api.SEQUENCE", nDetailIndex+1);
        DB_PROC("ICBC_40004_RSP_DETAIL_IN1_INSERT");
    }

    if ( nDetailNum >= 2 ) {
        logInfo(LOG_BUG, " Add Index[%d]", nDetailIndex+2);
        POC_SetValueInt32("api.SEQUENCE", nDetailIndex+2);
        DB_PROC("ICBC_40004_RSP_DETAIL_IN2_INSERT")
    } 
    
    if ( nDetailNum >= 3 ) {
        logInfo(LOG_BUG, " Add Index[%d]", nDetailIndex+3);
        POC_SetValueInt32("api.SEQUENCE", nDetailIndex+3);
        DB_PROC("ICBC_40004_RSP_DETAIL_IN3_INSERT")
    }
    
    return (FUNC_OK);
}

/**
 * Proc40004MakePkg
 * Make 40004 Next Message
 * If Detail Num < 4, End request make inner message
 * Eles, Make Next request Message
 *
 * @param #: void
 *
 * @return >0  : ok
 *         <0  : err
 */
static int Proc40004MakePkg()
{
    POC_SetValueS("var.outmsg_flag", "1", -1);
    int nDeatilNum = POC_GetValueInt32("inmsg.RETNUM");
    
    if ( nDeatilNum < 4 ) { /* End Rqeust */
        POC_SetValueS("var.outmsgid", "T_ICBC_API_IPCMSG", -1);
        if ( BIZ_HelperCvtInit("outmsg", "OUT:var.outmsgid:gvar.outmsg_buf") < 0 ) {
            logInfo(LOG_ERR, "outmsg New T_ICBC_API_IPCMSG err!!");
            return (-1);
        }
        
        /* update response */
        DB_PROC("ICBC_40004_RSP_IN_END_UPDATE");
        
        /* update request */
        DB_PROC("ICBC_40004_REQ_IN_END_UPDATE");
        
        /* MAKE INNER BANK */
        DB_PROC("MAKE_IN_MESSAGE");
    } else { /* Hsa More Detail */
        POC_SetValueS("var.outmsgid", "T_ICBC_40004_REQ", -1);
        if ( BIZ_HelperCvtInit("outmsg", "OUT:var.outmsgid:gvar.outmsg_buf") < 0 ) {
            logInfo(LOG_ERR, "outmsg New T_ICBC_40004_REQ err!!");
            return (-1);
        }
        
        /* Update Next Status */
        DB_PROC("ICBC_40004_RSP_IN_NEXT_UPDATE");
        
        /* Update Next Request Status */
        DB_PROC("ICBC_40004_REQ_IN_NEXT_UPDATE");
        
        /* Make Pkg */
        DB_PROC("ICBC_40004_REQ_RESEND_OUT_MAKE_PKG");
        
        int nRet = icbcMacAutoGen("40004_REQ");
        if ( nRet != 0 ) {
            logInfo(LOG_ERR, "Gen 40004 REQ MAC Err[%d]", nRet);
            return (nRet);
        }
    }
    
    return (FUNC_OK);
}

/*--------------------- End -------------------------------------*/
