/*
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  For Proc icbc batch.
 *
 *  $Id$
 *
 * FileName: txn_batch_proc.c
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 *  2011/05/27         zy                       Create.
 *
 */

/*------------------------ Include files ------------------------*/
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bizflow.h"
#include "log_info.h"
#include "poc_object.h"
#include "biz_helper.h"

#if 0
#pragma mark -
#pragma mark < Macro define >
#endif
/*--------------------- Macro define ----------------------------*/
#define DLEN_FILE_NAME 512
#define DLEN_BUFFER    2046
#define DLEN_DB_PROC   64

#define DB_PROC( sql ) \
do { \
    int nRet = BizFlowExecSqlById( (sql) ); \
    if ( nRet != FUNC_OK ) { \
        logInfo(LOG_ERR, "sql Proc[%s] err[%d]", (sql), nRet); \
        return (FUNC_ERR); \
    } \
}while (0)

#if 0
#pragma mark -
#pragma mark < Type define >
#endif
/*--------------------- Type define -----------------------------*/

/*--------------------- Local function declaration --------------*/

/*--------------------- Global variable -------------------------*/
char gsBuffer[DLEN_BUFFER+1];

#if 0
#pragma mark -
#pragma mark < Global functions >
#endif
/*--------------------- Global functions ------------------------*/
int txn_batch_proc(char *psMsgId, char *psProcId, char *psMakeId)
{
    int nRet;

    /* Grt File Info */
    char sFileName[DLEN_FILE_NAME+1];
    memset(sFileName, '\0', sizeof(sFileName));
    POC_GetValueS("gvar.inmsg_accs0", sFileName, DLEN_FILE_NAME);
    FILE *ptFp = fopen(sFileName, "r");
    if ( NULL == ptFp ) {
        logInfo(LOG_ERR, "Open File[%s] err[%s]", sFileName, strerror(errno));
        return ( FUNC_ERR );
    }

    /* Set Msg Id */
    POC_SetValueS("var.inmsgid", psMsgId, -1);

    /* Gen a New Id */
    DB_PROC("ICBC_GEN_ID");
    DB_PROC("ICBC_INSERT_FILE");

    /* Parse File */
    int nLoop = 0;
    while ( 1 ) {
        /* Get Buffer */
        memset(gsBuffer, '\0', sizeof(gsBuffer));
        if ( NULL == fgets(gsBuffer, sizeof(gsBuffer), ptFp) ) {
            break;
        }
        logInfo(LOG_BUG, "Msg[%s] proc[%s] loop[%d] ... ", psMsgId, psProcId, ++nLoop);

        /* remove enter */
        int nLen = strlen(gsBuffer);
        for ( ; nLen >= 0; --nLen) {
            if ( '\n' != gsBuffer[nLen] && '\r' != gsBuffer[nLen] ) {
                break;
            }

            gsBuffer[nLen] = '\0';
        }

        /* Parse One Loop */
        POC_SetValueS("gsvar.line_buf", gsBuffer, nLen);
        nRet = BIZ_HelperCvtInit("inmsg", "IN:var.inmsgid:gsvar.line_buf");
        if ( nRet != FUNC_OK ) {
            logInfo(LOG_ERR, "BIZ_HelperCvtInit init Msg[%s] err[%d]!!", psMsgId, nRet);
             logInfo(LOG_ERR, "Msg[%s]", gsBuffer);
            fclose(ptFp);
            return ( nRet );
        }

        /* Set Sequence */
        POC_SetValueInt32("api.SEQUENCE", nLoop);

        /* Do Proc */
        nRet = GenFlowProc(psProcId);
        if ( nRet != FUNC_OK ) {
            logInfo(LOG_ERR, "Porc [%s] err[%d]", psProcId, nRet);
            fclose(ptFp);
            return ( nRet );
        }

        /* Free Temp Info */
        nRet = POC_ObjectDel("inmsg", 0);
        if ( nRet != FUNC_OK ) {
            logInfo(LOG_ERR, "POC_ObjectDel [inmsg] err[%d]!!", nRet);
            fclose(ptFp);
            return ( nRet );
        }
    }

    logInfo(LOG_BUG, "Msg[%s] proc all recode[%d]", psMsgId, nLoop);
    fclose(ptFp);

    /* Make In Message */
    DB_PROC(psMakeId);

    return ( FUNC_OK );
}

#if 0
#pragma mark -
#pragma mark < Local functions >
#endif
/*--------------------- Local functions -------------------------*/

/*--------------------- End -------------------------------------*/
