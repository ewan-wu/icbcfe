/*
 * Copyright 2010, Shanghai Huateng Software Systems Co., Ltd.
 * All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 * SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 * BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM
 * IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 * SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 * Plugin Common Bridge Error Handle
 *
 * $Id$
 *
 * FileName: plug_combdg.c
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 * 2010/12/15      Chao.Shen                    Create.
 */
/*--------------------------- Include files -----------------------------*/
#include    <stdio.h>
#include    <stdlib.h>
#include    <string.h>

#include    "plug_bridge.h"

#include    "glb_ipc.h"
#include    "msg_rpt.h"

/*--------------------------- Macro define ------------------------------*/
#define COMM_BDG_PROC_SRV "porcsvr"
#define COMM_BDG_ERRSVR "errsvr"
#define COMM_BDG_TXNNO  "txnno"
#define COMM_BDG_MSGLEN "msglen"
#define COMM_BDG_MSGOFFSET "msgoffset"

#define COMM_CVT_OUT_FMT    "01"
#define COMM_CVT_IN_FMT     "02"

#define _TINY_BUF_LEN   32
#define _MINI_BUF_LEN   256
#define _LARGE_BUF_LEN  1024
#define _HUGE_BUF_LEN   10240

#define _               f_ptRTCoreCtx->pfnLogPrint
#define evtPost(s,i,o)  EventMgrPostEvent(f_ptPlugVar->iId, (s), (i), (o), 0)

/*---------------------------- Type define ------------------------------*/

/*---------------------- Local function declaration ---------------------*/
EVENTMAP_PLUG_MGR_DEFINE

static int commInitHdlr  (int iPlugId, int iEventId,
                          void *pInData, void *pOutData);
static int commErrorHdlr (int iPlugId, int iEventId,
                          void *pInData, void *pOutData);
static int commDefaltHdlr(int iPlugId, int iEventId,
                          void *pInData, void *pOutData);

/*-------------------------  Global variable ----------------------------*/
static T_RTCORE_CONTEXT     *f_ptRTCoreCtx;
static T_PLUG_MGR_PLUG_VAR  *f_ptPlugVar;

static int  f_iPorcSrv;
static int  f_iErrSvr;
static int  f_iMsgLen;
static int  f_iMsgOffset;
static char f_sTxnNo[_MINI_BUF_LEN];

/*-------------------------  Global functions ---------------------------*/
int
comPlugLoad(T_PLUG_MGR_PLUG_VAR *ptPlugVar)
{
    ptPlugVar->pfnEventHdl = NAME_PLUG_MGR_EVENTHANLER;
    f_ptPlugVar = ptPlugVar;
    f_ptRTCoreCtx = ptPlugVar->ptRTCoreCtx;

    return ERR_PLUG_MGR_OK;
}

/*-------------------------  Local functions ----------------------------*/
EVENTMAP_PLUG_MGR_BEGIN
EVENTMAP_PLUG_MGR_HANDLER (EVENT_PLUG_MGR_PLUG_INIT, commInitHdlr  )
EVENTMAP_PLUG_MGR_HANDLER (BDG_ERR_READ,             commDefaltHdlr )
EVENTMAP_PLUG_MGR_HANDLER (BDG_ERR_SERVER,           commDefaltHdlr )
EVENTMAP_PLUG_MGR_HANDLER (BDG_ERR_ROUTE,            commDefaltHdlr )
EVENTMAP_PLUG_MGR_HANDLER (BDG_ERR_CONVERT,          commErrorHdlr )
EVENTMAP_PLUG_MGR_HANDLER (BDG_ERR_WRITE,            commErrorHdlr )
EVENTMAP_PLUG_MGR_HANDLER (BDG_ERR_SEND,             commErrorHdlr )
EVENTMAP_PLUG_MGR_HANDLER_DEFAULT (                  commDefaltHdlr)
EVENTMAP_PLUG_MGR_END

static int
commInitHdlr(int iPlugId, int iEventId, void *pInData, void *pOutData)
{
    int iRet = 0;

    f_iErrSvr = CfgOperGetInt(f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj,
                              COMM_BDG_ERRSVR, -1, f_ptRTCoreCtx->sCfgFile);
    if (f_iErrSvr < 0) {
        _(LOG_ERR, "CfgOperGetInt() error: "
          "sSection[%s] sObj[%s] sKey[%s] sFile[%s]",
          f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj, COMM_BDG_ERRSVR,
          f_ptRTCoreCtx->sCfgFile);
        return ERR_PLUG_MGR_CFG;
    }
    
    f_iPorcSrv = CfgOperGetInt(f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj,
                              COMM_BDG_PROC_SRV, -1, f_ptRTCoreCtx->sCfgFile);
    if (f_iErrSvr < 0) {
        _(LOG_ERR, "CfgOperGetInt() error: "
          "sSection[%s] sObj[%s] sKey[%s] sFile[%s]",
          f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj, COMM_BDG_PROC_SRV,
          f_ptRTCoreCtx->sCfgFile);
        return ERR_PLUG_MGR_CFG;
    }

    f_iMsgLen = CfgOperGetInt(f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj,
                              COMM_BDG_MSGLEN, -1, f_ptRTCoreCtx->sCfgFile);
    if (f_iErrSvr < 0) {
        _(LOG_ERR, "CfgOperGetInt() error: "
          "sSection[%s] sObj[%s] sKey[%s] sFile[%s]",
          f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj, COMM_BDG_MSGLEN,
          f_ptRTCoreCtx->sCfgFile);
        return ERR_PLUG_MGR_CFG;
    }

    f_iMsgOffset = CfgOperGetInt(f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj,
                              COMM_BDG_MSGOFFSET, -1, f_ptRTCoreCtx->sCfgFile);
    if (f_iErrSvr < 0) {
        _(LOG_ERR, "CfgOperGetInt() error: "
          "sSection[%s] sObj[%s] sKey[%s] sFile[%s]",
          f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj, COMM_BDG_MSGOFFSET,
          f_ptRTCoreCtx->sCfgFile);
        return ERR_PLUG_MGR_CFG;
    }

    iRet = CfgOperGetStr(f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj,
                         COMM_BDG_TXNNO, "", f_sTxnNo, _MINI_BUF_LEN, f_ptRTCoreCtx->sCfgFile);
    if (iRet != 0) {
        _(LOG_ERR, "CfgOperGetStr() error: "
          "sSection[%s] sObj[%s] sKey[%s] sFile[%s]",
          f_ptPlugVar->sCfgSection, f_ptPlugVar->sObj, COMM_BDG_TXNNO,
          f_ptRTCoreCtx->sCfgFile);
        return ERR_PLUG_MGR_CFG;
    }

    _(LOG_NOR, "Initialize Plug Comm Bridge Error Handler Success:f_iPorcSrv[%d] f_iErrSvr[%d], f_iMsgLen[%d], f_sTxnNo[%s]",
      f_iPorcSrv, f_iErrSvr, f_iMsgLen, f_sTxnNo);

    return ERR_EVENT_MGR_OK;
}

static int
commDefaltHdlr(int iPlugId, int iEventId, void *pInData, void *pOutData)
{
    _(LOG_BUG, "commDefaltHdlr iPlugId[%d] iEventId[%d]", iPlugId, iEventId);
    return ERR_EVENT_MGR_OK;
}

static int commErrorHdlr(int iPlugId, int iEventId, void *pInData, void *pOutData)
{
    T_BDG_ENV *ptBdg = (T_BDG_ENV *)pInData;
    int       iRet;

    _(LOG_BUG, "plug_combdg commErrorHdlr start ... ");
    if ( ptBdg->tRun.iSrcSvrId == f_iPorcSrv ) {
        if ( ptBdg->tRun.iInLen < f_iMsgLen ) {
            _(LOG_BUG, "unknow message[%.*s] not send", ptBdg->tRun.iInLen, ptBdg->tRun.pIn);
            return ERR_EVENT_MGR_OK;
        }
        memcpy(((char *)ptBdg->tRun.pIn)+f_iMsgOffset, f_sTxnNo, strlen(f_sTxnNo));
        
        T_PLUG_IPC_MSGQUEUE_EVENTDATA tSendErrMsg;
        memset(&(tSendErrMsg), '\0', sizeof(T_PLUG_IPC_MSGQUEUE_EVENTDATA));
        tSendErrMsg.pMsgBody = (char *)ptBdg->tRun.pIn;
        tSendErrMsg.tMsgMd.iDestSvrId = f_iErrSvr;
        tSendErrMsg.iMsgLen = f_iMsgLen;
        iRet = evtPost(EVENT_PLUG_IPC_MSGQUE_NEWMSG, &(tSendErrMsg), NULL);
        if ( iRet != ERR_EVENT_MGR_OK ) {
            _(LOG_ERR, "evtPost() error[%d]: iEventId[%d]", iRet, EVENT_PLUG_IPC_MSGQUE_NEWMSG);
            return ERR_EVENT_MGR_OK;
        }
    }
    
    _(LOG_BUG, "plug_combdg commErrorHdlr end");
    return ERR_EVENT_MGR_OK;
}

/*-----------------------------  End ------------------------------------*/
