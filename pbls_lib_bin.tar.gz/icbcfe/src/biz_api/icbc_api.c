/*
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.  
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT 
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF 
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  API FOR CCB.
 *
 *  $Id$
 *
 * FileName: ccb_api.c 
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 *  2011/01/13         zy                       Create.
 *
 */

/*------------------------ Include files ------------------------*/
#include "icbc_api.h"
#include "log_info.h"
#include "bizflow.h"
#include "apicomm.h"
#include "ipc_msgqueue.h"
#include "ipc_msgque_datasource.h"
#include "ipc_msgque_topmq.h"

#if 0
#pragma mark -
#pragma mark < Macro define >
#endif
/*--------------------- Macro define ----------------------------*/
#define CHECK_RET( p, r) \
do { \
    if ( NULL == (p) ) { \
        logInfo(LOG_ERR, #p" is NULL !!"); \
        return ( (r) ); \
    } \
} while(0);

#define SESSION_START() \
gnSessionFlag = '1';

#define SESSION_CHECK() \
if ( gnSessionFlag != '1' ) { \
    return ( ICBC_API_NOT_BEGIN ); \
}

#define SESSION_END() \
gnSessionFlag = '0';

#define INIT_OK() \
gnInitFalg = '1';

#define INIT_END() \
gnInitFalg = '0';

#define INIT_CHECK() \
if ( gnInitFalg != '1' ) { \
return ( ICBC_API_NOT_INIT ); \
}

#define ICBC_IPC_PKGFMT_SWT_PBC "02"

#if 0
#pragma mark -
#pragma mark < Type define >
#endif
/*--------------------- Type define -----------------------------*/
typedef struct {
    T_GLB_IPCHDR tGlbIpcHdr;
    T_ICBC_API_IPCMSG tApiIpcMsg;
} T_ICBC_API_MSG;

/*--------------------- Local function declaration --------------*/
static int IpcQueueInit(int nSvrId);

/* For DataSource: just decaler */
int ipcMsgQueCreateItf4Ora(T_IPC_MSGQ_DATASOURCE_CTX *ptCtx, T_IPC_MSGQ_DATASOURCE *ptDataSource);
int ipcMsgQueRelease4Ora();

/*--------------------- Global variable -------------------------*/
static char gnInitFalg = '0';
static char gnSessionFlag = '0';

static T_IPC_MSGQ_DATASOURCE gtDataSource;

#if 0
#pragma mark -
#pragma mark < Global functions >
#endif
/*--------------------- Global functions ------------------------*/
/**
 * ICBC_INQ_INIT
 * Init All Info
 * init log
 * init biz flow
 * init Common Api
 *
 * @param psLogFile: Log FIle name
 *
 * @return >0  : ok
 *         <0  : err
 */
int ICBC_API_INIT(char *psLogFile, int nSrvId)
{
    int nRet;
    
    /* Use Old way init log file name */
    if ( NULL != psLogFile ) {
        logSetFile(psLogFile);
    }
    
    /* Init Biz Flow: Add Fix:"ICBC_" Set Enc Off:"0" */
    stdInitBizFlow("ICBC_", "0");
    
    /* Init Common Api */
    common_api_init();
    
    /* Init Server */
    nRet = IpcQueueInit(nSrvId);
    if ( nRet != ICBC_API_OK ) {
        logInfo(LOG_ERR, "IpcQueueInit SrvId[%d] err[%d]!!", nSrvId, nRet);
        return ( nRet );
    }
    
    INIT_OK();
    return ( ICBC_API_OK );
}

/**
 * ICBC_API_END
 * End of CCB API
 * end of common aoi
 *
 * @param #: void 
 *
 * @return >0  : ok
 *         <0  : err
 */
int ICBC_API_END()
{
    INIT_CHECK();
    
    /* Exit Common Api */
    common_api_exit();
    
    INIT_END();
    
    return ( ICBC_API_OK );
}

/**
 * ICBC_API
 * invork common_api
 *
 * @param psFlowId: Flow Id
 *
 * @return >0  : ok
 *         <0  : err
 */
int ICBC_CALL_API(char *psFlowId)
{
    INIT_CHECK();
    SESSION_CHECK();
    return ( common_api(psFlowId) );
}

/**
 * ICBC_API_OUT_MADE_BEGIN
 * invork commom_api_out_made_begin
 *
 * @param #: void
 *
 * @return >0  : ok
 *         <0  : err
 */
int ICBC_CALL_API_BEGIN()
{
    INIT_CHECK();
    
    int nRet = commom_api_begin();
    if ( nRet != ICBC_API_OK ) {
        return (nRet);
    }
    
    SESSION_START();
    
    return ( ICBC_API_OK );
}

/**
 * ICBC_API_OUT_MADE_END
 * invork commom_api_out_made_end
 *
 * @param #: void
 *
 * @return >0  : ok
 *         <0  : err
 */
int ICBC_CALL_API_END()
{
    INIT_CHECK();
    SESSION_CHECK();
    
    int nRet = commom_api_end();
    if ( nRet != ICBC_API_OK ) {
        return (nRet);
    }
    
    SESSION_END();
    
    return ( ICBC_API_OK );
}

/**
 * ICBC_API_RECV
 * CCB Recv Api
 *
 * @param pnSrcSrvId: return src server Id
 * @param ptIpcMsg: return Ipc Message
 *
 * @return >0  : ok
 *         <0  : err
 */
int ICBC_API_RECV(T_ICBC_API_IPCMSG *ptIpcMsg)
{
    INIT_CHECK();
    CHECK_RET(ptIpcMsg, ICBC_API_ERR_PARAM);
    
    /* Get */
    T_IPC_MSGQ_MD tIpcMsgqMd;
    T_ICBC_API_MSG tApiMsg;
    
    memset(&(tApiMsg), '\0', sizeof(tApiMsg));
    memset(&(tIpcMsgqMd), '\0', sizeof(tIpcMsgqMd));
    int nLen = sizeof(tApiMsg);
    
    int nRet = ipcMsgQGet(&(tApiMsg), &(nLen), &(tIpcMsgqMd));
    if ( nRet < 0 ) {
        logInfo(LOG_ERR, "TOPMQGET error[%d]", nRet);
        return ( ICBC_API_ERR_GETMSG );
    }
    
    /* Ret */
    logDebug((char *)&tApiMsg, sizeof(tApiMsg));
    memcpy(ptIpcMsg, &(tApiMsg.tApiIpcMsg), sizeof(T_ICBC_API_IPCMSG));
    
    return ( ICBC_API_OK );
}

/**
 * ICBC_API_SEND
 * CCB Api For Sedn
 *
 * @param nSrvId: srv Id
 * @param nSrcSrvId: source server Id
 * @param ptIpcMsg: Ipc Message
 *
 * @return >0  : ok
 *         <0  : err
 */
int ICBC_API_SEND(T_ICBC_API_IPCMSG *ptIpcMsg)
{
    INIT_CHECK();
    CHECK_RET(ptIpcMsg, ICBC_API_ERR_PARAM);
    
    /* Send */
    T_ICBC_API_MSG tApiMsg;
    memset(&(tApiMsg), '\0', sizeof(tApiMsg));
    sprintf(tApiMsg.tGlbIpcHdr.sTxnno, "1%.5s11", ptIpcMsg->sPkgNo);
    memcpy(tApiMsg.tGlbIpcHdr.sPkgFmt, ICBC_IPC_PKGFMT_SWT_PBC, DLEN_GLB_PKGFMT);
    memcpy(&(tApiMsg.tApiIpcMsg), ptIpcMsg, sizeof(T_ICBC_API_IPCMSG));
    logDebug((char *)&tApiMsg, sizeof(tApiMsg));

    T_IPC_MSGQ_MD tIpcMsgqMd;
    memset(&(tIpcMsgqMd), '\0', sizeof(tIpcMsgqMd));
    int nRet = ipcMsgQPut(&tApiMsg, sizeof(tApiMsg), &(tIpcMsgqMd));
    if( nRet < 0 ) {
        logInfo(LOG_ERR, "TOPMQPUT error[%d]", nRet);
        return (ICBC_API_ERR_SNDMSG);
    }
    
    return ( ICBC_API_OK );
}

/**
 * ICBC_API_SET_VALUE
 * invorkt API_SetValue
 *
 * @param psTag: Tag Name
 * @param psValue: Value
 * @param nLen: value Len
 *
 * @return >0  : ok
 *         <0  : err
 */
int ICBC_API_SET_VALUE(char *psTag, char *psValue, int nLen)
{
    INIT_CHECK();
    SESSION_CHECK();
    
    return ( API_SetValue(psTag, psValue, nLen) );
}

/**
 * ICBC_API_GET_VALUE
 * invork API_GetValue
 *
 * @param psTag: tag Name
 * @param psvalue: Value
 * @param nLen: Value Len
 *
 * @return >0  : ok
 *         <0  : err
 */
int ICBC_API_GET_VALUE(char *psTag, char *psValue, int nLen)
{
    INIT_CHECK();
    SESSION_CHECK();
    
    return ( API_GetValue(psTag, psValue, nLen) );
}

/**
 * ICBC_API_SET_VALUE_INT
 * invork POC_SetValueInt32
 *
 * @param psTag: Tag Name
 * @param nValue: Tag Value(int)
 *
 * @return >0  : ok
 *         <0  : err
 */
int ICBC_API_SET_VALUE_INT(char *psTag, int nValue)
{
    INIT_CHECK();
    SESSION_CHECK();
    
    return ( POC_SetValueInt32(psTag, nValue) );
}

/**
 * ICBC_API_GET_VALUE
 * invork API_GetValue
 *
 * @param psTag: tag Name
 *
 * @return >0  : ok
 *         <0  : err
 */
int ICBC_API_GET_VALUE_INT(char *psTag)
{
    INIT_CHECK();
    SESSION_CHECK();
    
    return ( POC_GetValueInt32(psTag) );
}

/**
 * ICBC_API_SET_VALUE_INT
 * invork POC_SetValueInt32
 *
 * @param psTag: Tag Name
 * @param nValue: Tag Value(int)
 *
 * @return >0  : ok
 *         <0  : err
 */
int ICBC_API_SET_VALUE_LONG(char *psTag, long nValue)
{
    INIT_CHECK();
    SESSION_CHECK();

    return ( POC_SetValueInt64(psTag, nValue) );
}

/**
 * ICBC_API_GET_VALUE
 * invork API_GetValue
 *
 * @param psTag: tag Name
 *
 * @return >0  : ok
 *         <0  : err
 */
long ICBC_API_GET_VALUE_LONG(char *psTag)
{
    INIT_CHECK();
    SESSION_CHECK();
    
    return ( POC_GetValueInt64(psTag) );
}

/**
 * ICBC_API_GET_VALUE_DOUBLE
 * invork POC_GetValueDouble 
 *
 * @param psTag: Tag Name
 *
 * @return >0  : ok
 *         NULL: err
 */
double ICBC_API_GET_VALUE_DOUBLE(char *psTag)
{
    INIT_CHECK();
    SESSION_CHECK();
    
    return (  POC_GetValueDouble(psTag) );
}

/**
 * ICBC_API_SET_VALUE_DOUBLE
 * invork POC_SetValueDouble
 *
 * @param psTag: Tag Name
 * @param dValue: Double Value
 *
 * @return >0  : ok
 *         NULL: err
 */
double ICBC_API_SET_VALUE_DOUBLE(char *psTag, double dValue)
{
    INIT_CHECK();
    SESSION_CHECK();
    
    return ( POC_SetValueDouble(psTag, dValue) );
}

#if 0
#pragma mark -
#pragma mark < Local functions >
#endif
/*--------------------- Local functions -------------------------*/
/**
 * IpcQueueInit
 * Ipc Queue Init
 * Defautl DB ORA
 * Defautl TopMq
 *
 * @param nSvrId: svr Id
 *
 * @return >0  : ok
 *         <0  : err
 */
static int IpcQueueInit(int nSvrId)
{
    int nRet;
    
    /* Make DataSource */
   T_IPC_MSGQ_DATASOURCE_CTX tDataSourceCtx;
    memset(&(tDataSourceCtx), '\0', sizeof(tDataSourceCtx));
    strcpy(tDataSourceCtx.sCfgLine, "icbc_msqdef");
    tDataSourceCtx.pfnLogPrint = logInfo;
    
    memset(&(gtDataSource), '\0', sizeof(gtDataSource));
    nRet = ipcMsgQueCreateItf4Db(&tDataSourceCtx, &gtDataSource);
    if ( nRet != ERR_IPC_MSGQ_DATASOURCE_OK ) {
        logInfo(LOG_ERR, "f_pfnDataCreateItf nRet[%d]", nRet);
        return ( nRet );
    }
    
    /* Create Msgq Ctx */
    T_IPC_MSGQ_CTX tIpcMsgqCtx;
    memset(&(tIpcMsgqCtx), '\0', sizeof(tIpcMsgqCtx));
    tIpcMsgqCtx.iWait = 100;
    tIpcMsgqCtx.iBufMaxSize = 10000;
    tIpcMsgqCtx.ptDataSoure = &gtDataSource;
    tIpcMsgqCtx.pfnLogPrint = logInfo;
    nRet = ipcMsgQCreateCtx(&tIpcMsgqCtx);
    if ( nRet != ICBC_API_OK ) {
        logInfo(LOG_ERR, "ipcMsgQCreateCtx nRet[%d]", nRet);
        return ( nRet );
    }
    
    /* Add topmq*/
    T_IPC_MSGQ_ITF tMsgQItf;
    memset(&(tMsgQItf), '\0', sizeof(tMsgQItf));
    tMsgQItf.pfnCreateCtx = ipcMsgQTopMqCreateCtx;
    tMsgQItf.pfnInit = ipcMsgQTopMqInit;
    tMsgQItf.pfnPut = ipcMsgQTopMqPut;
    tMsgQItf.pfnGet = ipcMsgQTopMqGet;
    tMsgQItf.pfnCfm = ipcMsgQTopMqCfm;
    tMsgQItf.pfnFinal = ipcMsgQTopMqFinalize;
    
    nRet = ipcMsgQAddItf(0, &tMsgQItf);
    if ( nRet != ERR_IPC_MSGQ_OK ) {
        logInfo(LOG_ERR, "ipcMsgQAddItf topmq nRet[%d]", nRet);
        return ( nRet );
    }
    
    /* Init */
    nRet = ipcMsgQInit(nSvrId);
    if ( nRet != ICBC_API_OK ) {
        logInfo(LOG_ERR, "ipcMsgQInit SrvIdd[%d] err[%d]!!", nSvrId, nRet);
        return ( nRet );
    }
    
    return ( ICBC_API_OK );
}

/*--------------------- End -------------------------------------*/
