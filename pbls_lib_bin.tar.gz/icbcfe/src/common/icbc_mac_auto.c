/*
 * Copyright 2010, Shanghai Huateng Software Systems Co., Ltd.
 * All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 * SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 * BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM
 * IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 * SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 * Mac Function Wrap
 *
 * $Id$
 *
 * FileName: icbc_mac_auto.c
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 * 2011/06/01        YY                        Create.
 */
/*--------------------------- Include files -----------------------------*/
#include	"icbc_mac.h"

#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>

#include	"log_info.h"
#include	"poc_object.h"
#include	"top_dbs.h"
#include	"topcry.h"
#include	"util_str.h"

/*--------------------------- Macro define ------------------------------*/
#define	_TINY_BUF_LEN	32
#define	_SMALL_BUF_LEN	256
#define	_LARGE_BUF_LEN	1024
#define	_HUGE_BUF_LEN	10240

#define	setnull(x)		memset(&(x), 0, sizeof(x))
#define	max(x,y)		((x) > (y) ? (x) : (y))
#define	min(x,y)		((x) < (y) ? (x) : (y))

#define	_					logInfo
#define	myGetValueS(t,v)	((v)[POC_GetValueS((t), (v), sizeof(v) - 1)] = '\0')

#define	ICBC_MAC_KEY_LENGTH	32

#define	ICBC_MAC_TYPE_LIST	    '1'
#define	ICBC_MAC_TYPE_FIX_LEN	'2'

#define	ICBC_MAC_TAG_MAC_IN		"inmsg.MAC"
#define	ICBC_MAC_TAG_MAC_OUT	"outmsg.MAC"
#define	ICBC_MAC_TAG_FLAG		"api.MAC_FLAG"

/*---------------------------- Type define ------------------------------*/

/*---------------------- Local function declaration ---------------------*/
static int icbcMacAutoGenInner(char *sObject, char sMac[16+1]);
static int icbcMacAutoAdd(char *sMacTag, int nMaxLen, char *sMacString, int *piMacSize);

/*-------------------------  Global variable ----------------------------*/
static char	f_sSql[_LARGE_BUF_LEN];
static char	f_sKey[CRY_BASE64_LEN(ICBC_MAC_KEY_LENGTH)];

/*-------------------------  Global functions ---------------------------*/
int icbcMacAutoInit(char *sTable, char *sKey, char *sKeyAlgo)
{
	int	iRet;

	snprintf(f_sSql, sizeof(f_sSql),
	         "select mac_tag, mac_type, mac_option "
	           "from %s "
	          "where mac_key = :key "
	          "order by mac_index ",
	         sTable);

	strMem2Str(f_sKey, sizeof(f_sKey), sKey, -1);

	iRet = cryWrapDecrypt(atoi(sKeyAlgo), f_sKey, sizeof(f_sKey));
	if (iRet < 0) {
		_(LOG_ERR,
		  "cryWrapDecrypt() error on [%d], iMethod[%d] sBuf[%s] iBufLen[%d]",
		  iRet, atoi(sKeyAlgo), f_sKey, sizeof(f_sKey));
		return -1;
	}

	return 0;
}

int icbcMacAutoGen(char *sMacPkgno)
{
	char	sMac[16+1];
	int		iRet;

	iRet = icbcMacAutoGenInner(sMacPkgno, sMac);
	if (iRet < 0) {
		_(LOG_ERR, "icbcMacAutoGenInner() error on [%d], sMacPkgno[%s]",
		  iRet, sMacPkgno);
		return -1;
	}

	if (iRet == 0) {
		iRet = POC_SetValueS(ICBC_MAC_TAG_MAC_OUT, sMac, strlen(sMac));
		if (iRet < 0) {
			_(LOG_ERR, "POC_SetValueS() error on [%d], sTag[%s]",
			  iRet, ICBC_MAC_TAG_MAC_OUT);
			return -1;
		}
	}

	return 0;
}

int icbcMacAutoVerify(char *sMacPkgno)
{
	char	sMac[16+1], sOrigMac[16+1];
	int		iFlag, iRet;

	iRet = icbcMacAutoGenInner(sMacPkgno, sMac);
	if (iRet < 0) {
		_(LOG_ERR, "icbcMacAutoGenInner() error on [%d], sMacPkgno[%s]",
		  iRet, sMacPkgno);
		return -1;
	}

	if (iRet == 0) {
		myGetValueS(ICBC_MAC_TAG_MAC_IN, sOrigMac);
		iFlag = memcmp(sMac, sOrigMac, 8) ? 0 : 1;

		_(LOG_TRC, "sOrigMac[%s] sMac[%s] iFlag[%d]", sOrigMac, sMac, iFlag);

		iRet = POC_SetValueInt32(ICBC_MAC_TAG_FLAG, iFlag);
		if (iRet < 0) {
			_(LOG_ERR, "POC_SetValueInt32() error on [%d], sTag[%s]",
			  iRet, ICBC_MAC_TAG_FLAG);
			return -2;
		}
	}

	return 0;
}

/*-------------------------  Local functions ----------------------------*/
static int icbcMacAutoGenInner(char *sMacPkgno, char sMac[16+1])
{
	T_TOP_DBS_STMT	hStmt;
	int				iRet;

	iRet = dbsOpenV(&hStmt, f_sSql, sMacPkgno);
	if (iRet != ERR_TOP_DBS_OK) {
		_(LOG_ERR, "dbsOpenV() error on [%d], sSql[%s] sMacPkgno[%s]",
		  iRet, f_sSql, sMacPkgno);
		return -1;
	}

	char	sMacString[_LARGE_BUF_LEN];
	int		iMacSize;

	sMacString[0] = '\0';
	iMacSize = sizeof(sMacString) - 1;

	char	sMacTag[_SMALL_BUF_LEN];
	char	sMacType[_TINY_BUF_LEN];
	char	sMacOption[_SMALL_BUF_LEN];
	int		iFlag = 0;

	while ((iRet = dbsFetchV(hStmt, sMacTag, sMacType, sMacOption))
	       == ERR_TOP_DBS_OK) {
		iFlag = 1;

		switch (sMacType[0]) {
			case ICBC_MAC_TYPE_LIST: {
				char	*pMaxCnt;
				int		iLen, iCnt, i;

				pMaxCnt = strchr(sMacOption, '|');
				if (!pMaxCnt) {
					_(LOG_ERR, "strchr() error, sMacOption[%s]", sMacOption);
					dbsCloseV(hStmt);
					return -4;
				}
				*pMaxCnt++ = '\0';

				_(LOG_TRC, "sMacCntTag[%s] iMaxCnt[%s]", sMacOption, pMaxCnt);

				iLen = strlen(sMacTag);
				iCnt = POC_GetValueInt32(sMacOption);
				if (iCnt > atoi(pMaxCnt)) iCnt = atoi(pMaxCnt);

				for (i = 0; i < iCnt; i++) {
					snprintf(sMacTag + iLen, sizeof(sMacTag) - iLen, "%d", i);
					icbcMacAutoAdd(sMacTag, 0, sMacString, &iMacSize);
				}

				break;
			}

            case ICBC_MAC_TYPE_FIX_LEN: {
				int iLen = atoi(sMacOption);
	            icbcMacAutoAdd(sMacTag, iLen, sMacString, &iMacSize);
                break;
			}

			default: {
				icbcMacAutoAdd(sMacTag, 0, sMacString, &iMacSize);
				break;
			}
		}
	}
	if (iRet != ERR_TOP_DBS_NOTFOUND) {
		_(LOG_ERR, "dbsFetchV() error on [%d], sSql[%s]", iRet, f_sSql);
		dbsCloseV(hStmt);
		return -2;
	}

	dbsCloseV(hStmt);

	if (!iFlag) {
		sMac[0] = '\0';
		return 1;
	}

	iRet = icbcMacGen(f_sKey, sMacString, sMac);
	if (iRet < 0) {
		_(LOG_ERR, "icbcMacGen() error on [%d], sMacString[%s]",
		  iRet, sMacString);
		return -3;
	}

	return 0;
}

static int icbcMacAutoAdd(char *sMacTag, int iLen, char *sMacString, int *piMacSize)
{
	char	sMacOne[_SMALL_BUF_LEN];

	myGetValueS(sMacTag, sMacOne);
 	
	int nRealLen = strlen(sMacOne);
	if ( iLen < 0 ) {
	    for ( --nRealLen; nRealLen > 0 ; --nRealLen ) {
			if ( sMacOne[nRealLen] != ' ' ) {
				++nRealLen;
                break;
			}
			sMacOne[nRealLen] = '\0';
		}
	} else if ( (iLen > 0) && (iLen != nRealLen) ) {
        if ( iLen < nRealLen ) {
			sMacOne[iLen] = '\0';
		} else {
			sprintf(sMacOne+nRealLen, "%*s", iLen-nRealLen, "");
		}
        nRealLen = iLen;
	}

	_(LOG_TRC, "sMacTag[%s] sMacOne[%s]", sMacTag, sMacOne);

	strncat(sMacString, sMacOne, *piMacSize);
	*piMacSize -= nRealLen;
	if (*piMacSize < 0) *piMacSize = 0;

	return 0;
}

/*-----------------------------  End ------------------------------------*/
