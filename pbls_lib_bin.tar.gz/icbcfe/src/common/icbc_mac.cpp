/*
 * Copyright 2010, Shanghai Huateng Software Systems Co., Ltd.
 * All Rights Reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 * SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT
 * BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM
 * IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF
 * SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 * Mac Function Wrap
 *
 * $Id$
 *
 * FileName: icbc_mac.cpp
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 * 2011/06/01        YY                        Create.
 */
/*--------------------------- Include files -----------------------------*/
#include	"icbc_mac.h"

#include	<string>
#include	<exception>
#include	<cstdio>

#include	<botan/botan.h>

#include	"log_info.h"

using namespace std;
using namespace Botan;

/*--------------------------- Macro define ------------------------------*/
#define	_TINY_BUF_LEN	32
#define	_SMALL_BUF_LEN	256
#define	_LARGE_BUF_LEN	1024
#define	_HUGE_BUF_LEN	10240

#define	setnull(x)		memset(&(x), 0, sizeof(x))
#define	max(x,y)		((x) > (y) ? (x) : (y))
#define	min(x,y)		((x) < (y) ? (x) : (y))
#define	_				logInfo

/*---------------------------- Type define ------------------------------*/

/*---------------------- Local function declaration ---------------------*/

/*-------------------------  Global variable ----------------------------*/

/*-------------------------  Global functions ---------------------------*/
int icbcMacGen(char sKey[32+1], char *sData, char sMac[16+1])
{
	int		iLen;
	byte	bBuffer[ICBC_MAC_BUFFER_LENTH] = {0, };

	_(LOG_TRC, "sKey[%s] sData[%s]", sKey, sData);

	iLen = strlen(sData);
	if (iLen > sizeof(bBuffer)) {
		_(LOG_ERR, "Inner Buffer is not enough, iDataLen[%d] iBufferSize[%d]",
		  iLen, sizeof(bBuffer));
		return -1;
	}
	memcpy(bBuffer, sData, iLen);

	try {
		string				tKey(sKey);
		SecureVector<byte>	tResult;
/*
		Pipe	tPipeNoPad(new MAC_Filter("X9.19-MAC", tKey));
		tPipeNoPad.process_msg(bBuffer, iLenNoPad);
		tResult = tPipeNoPad.read_all();

		_(LOG_TRC, "ANSI X9.19 MAC = [%02X%02X%02X%02X%02X%02X%02X%02X]",
		  tResult[0], tResult[1], tResult[2], tResult[3],
		  tResult[4], tResult[5], tResult[6], tResult[7]);
*/
		Pipe	tPipe(new MAC_Filter("X9.19-MAC", tKey));
		tPipe.process_msg(bBuffer, iLen);
		tResult = tPipe.read_all();

		sprintf(sMac, "%02X%02X%02X%02X%02X%02X%02X%02X",
		        tResult[0], tResult[1], tResult[2], tResult[3],
		        tResult[4], tResult[5], tResult[6], tResult[7]);

		_(LOG_TRC, "ISO9797 Padding Method 2 MAC = [%s]", sMac);

	} catch(exception& e) {
		_(LOG_ERR, "Exception caught: %s", e.what());
		return -2;
	}

	return 0;
}

/*-------------------------  Local functions ----------------------------*/

/*-----------------------------  End ------------------------------------*/
