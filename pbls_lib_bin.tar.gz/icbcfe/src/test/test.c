/*
 *  Copyright 2009, Shanghai Huateng Software Systems Co., Ltd.  
 *  All right reserved.
 *
 *  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF SHANGHAI HUATENG
 *  SOFTWARE SYSTEMS CO., LTD.  THE CONTENTS OF THIS FILE MAY NOT 
 *  BE DISCLOSED TO THIRD PARTIES, COPIED OR DUPLICATED IN ANY FORM,
 *  IN WHOLE OR IN PART, WITHOUT THE PRIOR WRITTEN PERMISSION OF 
 *  SHANGHAI HUATENG SOFTWARE SYSTEMS CO., LTD.
 *
 *  <#(FILE DESC)#>.
 *
 *  $Id$
 *
 * FileName: bizflow.pc 
 *
 *  <Date>        <Author>       <Auditor>     <Desc>
 *  2011/05/10         zy                       Create.
 *
 */

/*------------------------ Include files ------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "log_info.h"
#include "icbc_api.h"
#include "glb_dbs.h"

#if 0
#pragma mark -
#pragma mark < Macro define >
#endif
/*--------------------- Macro define ----------------------------*/

#if 0
#pragma mark -
#pragma mark < Type define >
#endif
/*--------------------- Type define -----------------------------*/

/*--------------------- Local function declaration --------------*/

/*--------------------- Global variable -------------------------*/

#if 0
#pragma mark -
#pragma mark < Global functions >
#endif
/*--------------------- Global functions ------------------------*/
int main(int argc, char *argv[])
{
    int nRet = dbsConnect("orauser/orauser");
    if ( nRet != 0 ) {
        printf("dbsConnect err, sqlcode[%d]!!\n", nRet);
        exit(0);
    }

    nRet = ICBC_API_INIT(NULL, 2001);
    if ( nRet != 0 ) {
        logInfo(LOG_ERR, "CCB_API_INIT err!!");
        return (-1);
    }

    T_ICBC_API_IPCMSG tCcbApiIpcMsg;
    memset(&(tCcbApiIpcMsg), '\0', sizeof(tCcbApiIpcMsg));
    if ( argc == 2 ) {
        memcpy(tCcbApiIpcMsg.sId, argv[1], sizeof(tCcbApiIpcMsg.sId));
        memcpy(tCcbApiIpcMsg.sPkgNo, argv[2], sizeof(tCcbApiIpcMsg.sPkgNo));
    } else {
        memcpy(tCcbApiIpcMsg.sId, "1111111111111111", sizeof(tCcbApiIpcMsg.sId));
        memcpy(tCcbApiIpcMsg.sPkgNo, "10004", sizeof(tCcbApiIpcMsg.sPkgNo));
    }

    nRet = ICBC_API_SEND(&(tCcbApiIpcMsg));
    if ( nRet != 0 ) {
        logInfo(LOG_ERR, "CCB_API_SEND err!!");
        return (-1);
    }

    ICBC_API_END();

    return (0);	
}

#if 0
#pragma mark -
#pragma mark < Local functions >
#endif
/*--------------------- Local functions -------------------------*/

/*--------------------- End -------------------------------------*/

